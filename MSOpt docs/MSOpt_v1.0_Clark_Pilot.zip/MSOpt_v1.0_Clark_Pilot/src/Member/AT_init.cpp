// __START__

#include "AT_init.hpp"
#include "AT_tm.hpp"
#include "AT_lp.hpp"
#include "AT_GRASP.hpp"

/**
 * @brief initializes a user-defined LP interface to BCP
 *
 * @param p BCP LP problem object
 *
 * @return user-defined LP interface to BCP
 */
BCP_lp_user * AT_init::lp_init( BCP_lp_prob& p ) {
    //Initialize the user-defined LP interface to BCP
    std::cout << "in lp_init()" << endl;

    return new AT_lp;
}

/**
 * @brief
 *
 * @param p
 * @param argnum
 * @param arglist
 *
 * @return
 */
BCP_tm_user * AT_init::tm_init( BCP_tm_prob& p, const int argnum,
                                const char * const * arglist ) {

    //Initialize the user-defined TM interface to BCP
    std::cout << "in tm_init()" << endl;
    AT_tm* tm = new AT_tm;

    //Read in the TM and LP parameters from the arg ParamFile: parameter file
    std::cout << "read in the TM and LP parameters" << endl;
    tm->tm_par.read_from_arglist( argnum, arglist );
    tm->lp_par.read_from_arglist( argnum, arglist );
    std::cout << "end reading" << endl;

    //Construct the AT data object
    tm->at = new AT( );
    (*(tm->at)).AT_main( );
    tm->epsilon = new double[(*(tm->at)).Num_Lot + 1];
    tm->delta = new double[(*(tm->at)).Num_Lot + 1];
    for ( int l = 1; l <= (*(tm->at)).Num_Lot; l++ ) {
        //(*tm).epsilon[l]=0.1*l;
        //(*tm).delta[l]=-1000;
        (*tm).epsilon[l] = 0.0;
        (*tm).delta[l] = 0.0;
        //cout<<"l="<<l<<",epsilon="<<(*tm).epsilon[l]<<",delta="<<(*tm).delta[l]<<endl;
    }
    return tm;
}

// __END__
