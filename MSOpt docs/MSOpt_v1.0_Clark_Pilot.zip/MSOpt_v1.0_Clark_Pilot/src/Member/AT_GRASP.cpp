// __START__
/**
 * @file AT_GRASP.cpp
 * @ingroup GRASP
 * 
 * @brief GRASP algorithm...
 *
 * Detailed description of file...
 * 
 */

// AT.cpp : Defines the entry point for the console application.
// ----------------------------------------------
#include <iostream>
#include <sstream>
#include <cstring>
#include <string>
#include <fstream>
#include <math.h>
#include <algorithm>
#include <vector>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <iomanip>
#include <cassert>
#include "combination.hpp"
#include "AT_GRASP.hpp"


using namespace std;


/**
 * @brief constructor of the AT class
 */
AT::AT( )
{
    // constructor of the AT class
    // initialize the parameters
    Max_Num_Tooling = 0;
    Max_Num_Tooling_Family = 0;
    Max_Num_Machine = 0;
    Max_Num_Lot = 0;
    Max_Num_Device = 0;
    Max_Num_Temperature = 0;
    Max_Num_Tooling_Configure = 0;
    Num_Tooling = 0;
    Num_Tooling_Family = 0;
    Num_Machine = 0;
    Num_Machine_Group = 0;
    Num_Lot = 0;
    Num_Device = 0;
    Num_Keydevice = 0;
    Num_Package = 0;
    Num_Temperature = 0;
    x_limit = 0;
    y_limit = 0;
    Num_LP_solved = 0;
    Num_Simulated = 0;
    Num_Discarded = 0;
    strcpy( General_Snapshot_time.str, "" );
}


/**
 * @brief destructor of the AT class
 */
AT::~AT( )
{
    // destructor of the AT class
    for ( int id = 1; id <= ( int ) MF.size( ); id++ ) {
        delete[]MF[id - 1];
    }
    MF.clear( );
    for ( int id = 1; id <= ( int ) MI.size( ); id++ ) {
        delete[]MI[id - 1];
    }
    MI.clear( );
    for ( int id = 1; id <= ( int ) TF.size( ); id++ ) {
        delete[]TF[id - 1];
    }
    TF.clear( );
    for ( int id = 1; id <= ( int ) TI.size( ); id++ ) {
        delete[]TI[id - 1];
    }
    TI.clear( );
    for ( int id = 1; id <= ( int ) LOT.size( ); id++ ) {
        delete[]LOT[id - 1];
    }
    LOT.clear( );
    for ( int id = 1; id <= ( int ) DEV.size( ); id++ ) {
        delete[]DEV[id - 1];
    }
    DEV.clear( );
    for ( int id = 1; id <= ( int ) PKG.size( ); id++ ) {
        delete[]PKG[id - 1];
    }
    PKG.clear( );
    delete[]PIN_PKG_penalty;
    delete[]H;
    delete[]effective_starting_time;
    delete[]Tooling_Setup_Time;
    delete[]n_l_chips;
    delete[]n_k_minchips;
    delete[]n_p_minchips;
    delete[]n_kp_minchips;
    delete[]w_l;
    delete[]rate;
    delete[]eps;
    delete[]penalty;
    delete[]PKG_penalty;
    delete[]device_PKG;
    delete[]device_PIN;
    delete[]lots_device;
    delete[]lot_logpoint;
    delete[]lot_operation;
    delete[]machine_mg;
    delete[]machine_sim;
    delete[]tooling_tf;
    delete[]L_i;
    delete[]M_l;
    delete[]S_i;
    delete[]Lambda_i;
    delete[]M_lambda;
    delete[]p_device;
    delete[]package_qty;
    delete[]keydevice_qty;
    delete[]n_t_n_tooling;
    delete[]a_st;
    delete[]L_i_d;
    delete[]index_vector_flag;
}


/**
 * @brief main entry point of the GRASP algorithm
 * 
 * @return 
 */
int
AT::AT_main( )
{
    // the main entry point of the GRASP algorithm
    time_t t_prog_start; // keep a record of the program starting time
    time( &t_prog_start );
    cout << "The starting time is " << ctime( &t_prog_start ) << endl;

    // test();
    // read the configuration file "input.txt"
    char temp[1000], pdes[500];

    ifstream f_input( "Data/input.txt" );
    f_input.getline( temp, 1000, '\n' );
    int k = 0, l = 0;

    k = strtok2( pdes, temp, l, ' ' ); // get Max_Num_Tooling
    Max_Num_Tooling = atoi( pdes );
    f_input.getline( temp, 1000, '\n' ); // get Max_Num_Tooling_Family
    l = 0;
    k = strtok2( pdes, temp, l, ' ' );
    Max_Num_Tooling_Family = atoi( pdes );
    f_input.getline( temp, 1000, '\n' ); // get Max_Num_Machine
    l = 0;
    k = strtok2( pdes, temp, l, ' ' );
    Max_Num_Machine = atoi( pdes );
    f_input.getline( temp, 1000, '\n' ); // get Max_Num_Lot
    l = 0;
    k = strtok2( pdes, temp, l, ' ' );
    Max_Num_Lot = atoi( pdes );
    f_input.getline( temp, 1000, '\n' ); // get Max_Num_Device
    l = 0;
    k = strtok2( pdes, temp, l, ' ' );
    Max_Num_Device = atoi( pdes );
    f_input.getline( temp, 1000, '\n' ); // get Max_Num_Temperature
    l = 0;
    k = strtok2( pdes, temp, l, ' ' );
    Max_Num_Temperature = atoi( pdes );
    f_input.getline( temp, 1000, '\n' ); // get Max_Num_Tooling_Configure
    l = 0;
    k = strtok2( pdes, temp, l, ' ' );
    Max_Num_Tooling_Configure = atoi( pdes );
    f_input.getline( temp, 1000, '\n' ); // get Generate_Option
    l = 0;
    k = strtok2( pdes, temp, l, ' ' );
    Generate_Option = atoi( pdes );
    f_input.getline( temp, 1000, '\n' ); // get Load_Unload_Time
    l = 0;
    k = strtok2( pdes, temp, l, ' ' );
    Load_Unload_Time = ( double ) atof( pdes );
    f_input.getline( temp, 1000, '\n' ); // get Run_Option
    l = 0;
    k = strtok2( pdes, temp, l, ' ' );
    Run_Option = atoi( pdes );
    f_input.getline( temp, 1000, '\n' ); // get LP_IP
    l = 0;
    k = strtok2( pdes, temp, l, ' ' );
    LP_IP = atoi( pdes );
    f_input.getline( temp, 1000, '\n' ); // get new_old_model
    l = 0;
    k = strtok2( pdes, temp, l, ' ' );
    new_old_model = atoi( pdes );
	/*
	f_input.getline( temp, 1000, '\n' ); // get pkg_setup_time
    l = 0;
    k = strtok2( pdes, temp, l, ' ' );
    pkg_setup_time = atoi( pdes );
	*/
    // --------------------------------------------------------------------------
    cout << "----------------- Important parameters -----------------" << endl;
    cout << "Max_Num_Tooling=" << Max_Num_Tooling << endl;
    cout << "Max_Num_Tooling_Family=" << Max_Num_Tooling_Family << endl;
    cout << "Max_Num_Machine=" << Max_Num_Machine << endl;
    cout << "Max_Num_Lot=" << Max_Num_Lot << endl;
    cout << "Max_Num_Device=" << Max_Num_Device << endl;
    cout << "Max_Num_Temperature=" << Max_Num_Temperature << endl;
    cout << "Max_Num_Tooling_Configure=" << Max_Num_Tooling_Configure << endl;

    // -------------------------------------------------initialize the data member
    H = new double[Max_Num_Machine];
    effective_starting_time = new double[Max_Num_Machine];

    for ( int j = 0; j <= Max_Num_Machine - 1; j++ ) {
        H[j] = 0.0;
        effective_starting_time[j] = 0.0;
    }
    Tooling_Setup_Time = new double[Max_Num_Tooling_Family];

    for ( int j = 0; j <= Max_Num_Tooling_Family - 1; j++ ) {
        Tooling_Setup_Time[j] = 0;
    } // initilaize the Tooling_Setup_Time[]
    n_l_chips = new int[Max_Num_Lot];
    n_k_minchips = new int[Max_Num_Device];
    n_p_minchips = new int[Max_Num_Device];
    n_kp_minchips = new int[Max_Num_Device];
    w_l = new double[Max_Num_Lot];
    rate = new double[Max_Num_Tooling_Configure];
    eps = new double[Max_Num_Tooling_Configure];
    penalty = new double[Max_Num_Device];
    PKG_penalty = new double[Max_Num_Device];
    device_PKG = new int[Max_Num_Device];
    device_PIN = new int[Max_Num_Device];
    lots_device = new int[Max_Num_Lot];
    lot_logpoint = new int[Max_Num_Lot];
    lot_operation = new int[Max_Num_Lot];
    machine_mg = new int[Max_Num_Machine];
    machine_sim = new int[Max_Num_Machine];
    tooling_tf = new int[Max_Num_Tooling];

    L_i = new vec_int[Max_Num_Machine];
    M_l = new vec_int[Max_Num_Lot];
    S_i = new vec_tc[Max_Num_Machine];
    Lambda_i = new vec_int[Max_Num_Machine];
    M_lambda = new vec_int[Max_Num_Tooling_Configure];
    p_device = new vec_int[Max_Num_Device];
    package_qty = new int[Max_Num_Device];
    keydevice_qty = new int[Max_Num_Device];
    n_t_n_tooling = new int[Max_Num_Tooling_Family * Max_Num_Temperature];
    a_st = new int[Max_Num_Tooling_Configure * Max_Num_Tooling_Family];

    L_i_d = new vec_int[Max_Num_Machine * Max_Num_Device];
    index_vector_flag = new int[Max_Num_Machine];


    // --------------------------------------------------------------------------
    // generate the case from input files
    f_input.getline( temp, 1000, '\n' );
    f_input.getline( temp, 1000, '\n' ); // Max_Iter
    l = 0;
    k = strtok2( pdes, temp, l, ' ' );
    Max_Iter = atoi( pdes );
    f_input.getline( temp, 1000, '\n' ); // skip Num_Lot
    f_input.getline( temp, 1000, '\n' ); // skip Num_Machine
    f_input.getline( temp, 1000, '\n' ); // skip num_mg
    f_input.getline( temp, 1000, '\n' ); // skip Num_Tooling
    f_input.getline( temp, 1000, '\n' ); // skip Num_Tooling_Family
    f_input.getline( temp, 1000, '\n' ); // skip Num_Device
    f_input.getline( temp, 1000, '\n' ); // skip Num_Keydevice
    f_input.getline( temp, 1000, '\n' ); // skip Num_Package
    f_input.getline( temp, 1000, '\n' ); // skip Num_Temperature
    f_input.getline( temp, 1000, '\n' ); // SIM_option
    l = 0;
    k = strtok2( pdes, temp, l, ' ' );
    SIM_option = atoi( pdes );
    f_input.getline( temp, 1000, '\n' ); // PhaseII_option
    l = 0;
    k = strtok2( pdes, temp, l, ' ' );
    PhaseII_option = atoi( pdes );
    create_case_from_files( );
    f_input.close( );
    time_t end_time; // keep a record the end time
    time( &end_time );
    cout << "The end time is " << ctime( &end_time ) << endl;
    double diff = difftime( end_time, t_prog_start );

    cout << "It has been running for " << diff << " seconds." << endl;
    fstream fcout( "Output/resultsummery.txt", ios::out | ios::app );
    fcout << "The end time is " << ctime( &end_time ) << endl;
    fcout << "The code has been running for " << diff << " seconds totally." << endl;
    fcout.close( );
    exit( 0 );
}


/**
 * @brief 
 */
void
AT::readFiles( )
{
    // this is the major function to read the files and process tha data
    char temp[1000];
    char pdes[100];

    fstream f_log( "Output/log_error.txt", ios::out | ios::app );

    // read machines.csv
    ifstream f_machines( "Data/machines.csv" );
    f_machines.getline( temp, 1000, '\n' );
    f_machines.getline( temp, 1000, '\n' );
    Num_Machine = 0;
    Num_Machine_Group = 0;
    Num_Temperature = 0;
    trim( temp );
    while ( !f_machines.eof( ) && strlen( temp ) > 0 ) {
        int l = 0, k = 0;

        for ( int i = 1; i <= 50; i++ ) {
            pdes[i] = ' ';
        }
        k = strtok2( pdes, temp, l, ',' ); // get machine family name
        trim( pdes );
        if ( strlen( pdes ) > 0 ) {
            char *mf_name = new char[50];

            strcpy( mf_name, pdes );
            l = k;
            k = strtok2( pdes, temp, l, ',' ); // get machine instance name
            trim( pdes );
            char *mi_name = new char[50];

            strcpy( mi_name, pdes );
            l = strtok2( pdes, temp, k, ',' );
            k = strtok2( pdes, temp, l, ',' ); // certification
            trim( pdes );
            int certification = atoi( pdes );

            if ( strlen( mi_name ) > 0 && strlen( pdes ) > 0 && certification > 0 ) {
                bool MF_name_exist = false;
                bool MI_name_exist = false;
                for ( int id = 1; id <= ( int ) MF.size( ); id++ ) {
                    if ( !strcmp( MF[id - 1], mf_name ) ) { // if name already exists in MF
                        delete[]mf_name;
                        MF_name_exist = true;
                        break;
                    }
                }
                for ( int id = 1; id <= ( int ) MI.size( ); id++ ) {
                    if ( !strcmp( MI[id - 1], mi_name ) ) { // if name already exists in MI
                        f_log << "In the machines.csv, " << mi_name << " appeared more than once. Only the last one would be used,and skip others." << endl;
                        delete[]mi_name;
                        MI_name_exist = true;
                        break;
                    }
                }
                if ( !MF_name_exist ) { // name does not exist in MF
                    MF.push_back( mf_name );

                    // NOTE: don't need to delete [] mf_name;
                }
                if ( !MI_name_exist ) { // name does not exist in MI
                    MI.push_back( mi_name );

                    // NOTE: don't need to delete [] mi_name;
                }
            } else {
                delete[]mf_name;
                delete[]mi_name;
            }
        }
        f_machines.getline( temp, 1000, '\n' );
        trim( temp );
    } // end of while(!f_machines.eof() && strlen(temp)>0){
    ofstream f_MF( "Debug/debug_machine_family_name.txt" );

    for ( int id = 1; id <= ( int ) MF.size( ); id++ ) {
        f_MF << "id=" << id << ",name=" << MF[id - 1] << endl;
    }
    f_MF.close( );
    f_MF.clear( );
    ofstream f_MI( "Debug/debug_machine_name.txt" );

    for ( int id = 1; id <= ( int ) MI.size( ); id++ ) {
        f_MI << "id=" << id << ",name=" << MI[id - 1] << endl;
    }
    f_MI.close( );
    f_MI.clear( );
    Num_Machine_Group = ( int ) MF.size( );

    // -----------------------------------------------------------------
    Machine_vector.resize( ( int ) MI.size( ) );
    f_machines.close( );
    f_machines.clear( );
    f_machines.open( "Data/machines.csv" );
    f_machines.getline( temp, 1000, '\n' );
    f_machines.getline( temp, 1000, '\n' );
    trim( temp );
    int l = 0, k = 0;
    int row_no = 2;

    while ( !f_machines.eof( ) && strlen( temp ) > 0 ) {
        memset( pdes, 0, sizeof (pdes) );
        l = 0;
        k = 0;
        k = strtok2( pdes, temp, l, ',' ); // put mf in pdes
        trim( pdes );
        struct Machine one_mc;

        if ( strlen( pdes ) > 0 ) { // if mf is not empty
            int mg = 0;

            for ( int id = 1; id <= ( int ) MF.size( ); id++ ) {
                if ( !strcmp( MF[id - 1], pdes ) ) {
                    mg = id;
                    break;
                };
            }
            if ( mg == 0 ) {
                f_log << "The " << row_no << "th row in machines.csv:Information incomplete. This machine instance is skipped." << endl;
                memset( temp, 0, sizeof (temp) );
                f_machines.getline( temp, 1000, '\n' );
                row_no++;
            } else {
                one_mc.mg = mg;

                l = strtok2( pdes, temp, k, ',' ); // mi name
                trim( pdes );
                if ( strlen( pdes ) <= 0 ) { // if mi is  empty
                    f_log << "The " << row_no << "th row in machines.csv:Machine_Instance is empty.The machine instance is skipped." << endl;
                    memset( temp, 0, sizeof (temp) );
                    f_machines.getline( temp, 1000, '\n' );
                    row_no++;

                    // f_log.close();
                } else {
                    int mi = 0;

                    for ( int id = 1; id <= ( int ) MI.size( ); id++ ) {
                        if ( !strcmp( MI[id - 1], pdes ) ) {
                            mi = id;
                            break;
                        };
                    }

                    if ( mi < 1 ) {
                        f_log << "The " << row_no << "th row in machines.csv:Information incomplete.This machine instance is skipped." << endl;
                        memset( temp, 0, sizeof (temp) );
                        f_machines.getline( temp, 1000, '\n' );
                        row_no++;

                        // abort();
                    } else {
                        one_mc.id = mi;
                        k = strtok2( pdes, temp, l, ',' ); // mf_name
                        trim( pdes );
                        strcpy( one_mc.name, MI[one_mc.id - 1] );

                        memset( pdes, 0, sizeof (pdes) );
                        l = strtok2( pdes, temp, k, ',' ); // certification
                        trim( pdes );

                        if ( strlen( pdes ) <= 0 ) { // if the cerrification is empty
                            f_log << "The " << row_no << "th row in machines.csv: the certification is empty.This machine instance is skipped." << endl;
                            memset( temp, 0, sizeof (temp) );
                            f_machines.getline( temp, 1000, '\n' );
                            row_no++;
                        } else {
                            int temperature = atoi( pdes );

                            if ( temperature > Num_Temperature ) {
                                Num_Temperature = temperature;
                            }
                            if ( temperature <= 0 ) {
                                f_log << "The " << row_no << "th row in machines.csv: the certification is non-positive.This machine instance is skipped." << endl;
                                memset( temp, 0, sizeof (temp) );
                                f_machines.getline( temp, 1000, '\n' );
                                row_no++;
                            } else {
                                one_mc.temperature_vector.push_back( temperature );
                                if ( !f_machines.eof( ) ) {
                                    char mf_name[50];
                                    char mi_name[50];
                                    char mf_name2[50];


                                    do {
                                        memset( temp, 0, sizeof (temp) );
                                        f_machines.getline( temp, 1000, '\n' );
                                        row_no++;
                                        if ( !f_machines.eof( ) ) {
                                            memset( pdes, 0, sizeof (pdes) );
                                            l = 0;
                                            k = 0;
                                            k = strtok2( pdes, temp, l, ',' ); // mf
                                            trim( pdes );
                                            strcpy( mf_name, pdes );
                                            l = strtok2( pdes, temp, k, ',' ); // mi
                                            trim( pdes );
                                            strcpy( mi_name, pdes );
                                            k = strtok2( pdes, temp, l, ',' ); // mf_name
                                            trim( pdes );
                                            strcpy( mf_name2, pdes );
                                            if ( mg > 0 && strlen( mf_name ) <= 0 && strlen( mi_name ) <= 0 && strlen( mf_name2 ) <= 0 ) {

                                                // memset(pdes,0,sizeof(pdes));
                                                l = 0;
                                                k = 0;
                                                l = strtok2( pdes, temp, k, ',' );
                                                k = strtok2( pdes, temp, l, ',' );
                                                l = strtok2( pdes, temp, k, ',' );
                                                k = strtok2( pdes, temp, l, ',' );
                                                trim( pdes );
                                                if ( strlen( pdes ) <= 0 ) { // if the certification is empty
                                                    f_log << "The " << row_no
                                                            << "th row in machines.csv: the certification is empty.This row was supposed to be one of multiple certifications for machine instance. This row (not the machine instance)is skipped." << endl;
                                                } else {
                                                    int temperature = atoi( pdes );

                                                    if ( temperature > Num_Temperature ) {
                                                        Num_Temperature = temperature;
                                                    }
                                                    if ( temperature <= 0 ) {
                                                        f_log << "The "
                                                                << row_no
                                                                << "th row in machines.csv: the certification is non-positive.This row was supposed to be one of multiple certifications for machine instance.This row (not the machine instance)is skipped."
                                                                << endl;
                                                    } else {
                                                        one_mc.temperature_vector.push_back( temperature );
                                                    }
                                                }
                                            }
                                        }
                                    } while ( !f_machines.eof( ) && strlen( temp ) > 0 && strlen( mf_name ) <= 0 && strlen( mi_name ) <= 0 && strlen( mf_name2 ) <= 0 );
                                }
                                Machine_vector[one_mc.id - 1] = one_mc;
                            }
                        }
                    }
                }
            }
        } else {
            f_log << "The " << row_no << "th row in machines.csv: Machine_Family is empty.The machine instance is skipped." << endl;
            memset( temp, 0, sizeof (temp) );
            f_machines.getline( temp, 1000, '\n' );
            row_no++;
        }
    }
    f_machines.close( );
    Num_Machine = ( int ) MI.size( );
    show_Machine_vector( );

    // read tooling.csv
    cout << "read file Data/tooling.csv" << endl;
    ifstream f_tooling( "Data/tooling.csv" );
    f_tooling.getline( temp, 1000, '\n' );
    f_tooling.getline( temp, 1000, '\n' );
    row_no = 2;
    Num_Tooling = 0;
    Num_Tooling_Family = 0;
    trim( temp );
    while ( !f_tooling.eof( ) && strlen( temp ) > 0 ) {
        int l = 0, k = 0;

        for ( int i = 1; i <= 50; i++ ) {
            pdes[i] = ' ';
        }
        k = strtok2( pdes, temp, l, ',' ); // get tooling family name
        trim( pdes );
        if ( strlen( pdes ) <= 0 ) {
            f_tooling.getline( temp, 1000, '\n' );
            trim( temp );
            row_no++;
        } else {
            char *tf_name = new char[50];

            strcpy( tf_name, pdes );
            l = k;
            k = strtok2( pdes, temp, l, ',' ); // get tooling instance
            trim( pdes );
            char *ti_name = new char[50];

            strcpy( ti_name, pdes );
            l = strtok2( pdes, temp, k, ',' ); // Tooling_Family_Name
            k = strtok2( pdes, temp, l, ',' ); // Certification
            trim( pdes );
            int certification = atoi( pdes );

            if ( strlen( ti_name ) > 0 && certification > 0 ) {
                bool TF_name_exist = false;
                bool TI_name_exist = false;
                for ( int id = 1; id <= ( int ) TF.size( ); id++ ) {
                    if ( !strcmp( TF[id - 1], tf_name ) ) { // the tf_name already exists in TF
                        delete[]tf_name;
                        TF_name_exist = true;
                        break;
                    }
                }
                for ( int id = 1; id <= ( int ) TI.size( ); id++ ) {
                    if ( !strcmp( TI[id - 1], ti_name ) ) { // the ti_name already exists in TF
                        f_log << "In the tooling.csv, " << ti_name << " appeared more than once. Only the last one would be used,and skip others." << endl;
                        delete[]ti_name;
                        TI_name_exist = true;
                        break;
                    }
                }
                if ( !TF_name_exist ) {
                    TF.push_back( tf_name );

                    // Note:Cannot delete [] tf_name.TF is the vector of pointers, not the arrays. So the memory space with the pointer can not be deleted until TF[] is not used any more
                }
                if ( !TI_name_exist ) {
                    TI.push_back( ti_name );

                    // Note:Cannot delete [] ti_name;
                }
            } else {
                delete[]tf_name;
                delete[]ti_name;
            }
            f_tooling.getline( temp, 1000, '\n' );
            trim( temp );
            row_no++;
        }
    }

    // The following statement is used to deal with empty tooling in the route.csv file
    if ( 1 ) {
        char *name = new char[50];

        strcpy( name, "No_Tooling" );
        TF.push_back( name );
        for ( int i = 1; i <= Num_Machine; i++ ) {
            stringstream ss;
            ss << name << "-" << i;
            char *name2 = new char[50];

            strcpy( name2, (ss.str( )).c_str( ) );
            TI.push_back( name2 );
        }
    }

    ofstream f_TF( "Debug/debug_tooling_family_name.txt" );

    for ( int id = 1; id <= ( int ) TF.size( ); id++ ) {
        f_TF << "id=" << id << ",name=" << TF[id - 1] << endl;
    }
    f_TF.close( );
    f_TF.clear( );
    ofstream f_TI( "Debug/debug_tooling_name.txt" );

    for ( int id = 1; id <= ( int ) TI.size( ); id++ ) {
        f_TI << "id=" << id << ",name=" << TI[id - 1] << endl;
    }
    f_TI.close( );
    f_TI.clear( );
    Num_Tooling_Family = ( int ) TF.size( );
    f_tooling.close( );
    f_tooling.clear( );
    f_tooling.open( "Data/tooling.csv" );

    // ------------------------------------------------------------
    f_tooling.getline( temp, 1000, '\n' );
    f_tooling.getline( temp, 1000, '\n' );
    trim( temp );
    row_no = 2;
    Tooling_vector.resize( ( int ) TI.size( ) );
    Num_Tooling = ( int ) TI.size( );
    while ( !f_tooling.eof( ) && strlen( temp ) > 0 ) {
        memset( pdes, 0, sizeof (pdes) );
        l = 0;
        k = 0;
        k = strtok2( pdes, temp, l, ',' ); // TF
        trim( pdes );
        struct Tooling one_tool;

        if ( strlen( pdes ) <= 0 ) {
            f_log << "The " << row_no << "th row in tooling.csv: Tool_Family is empty.The tooling instance is skipped." << endl;
            memset( temp, 0, sizeof (temp) );
            f_tooling.getline( temp, 1000, '\n' );
            row_no++;
        } else {
            int tf = 0;

            for ( int id = 1; id <= ( int ) TF.size( ); id++ ) {
                if ( !strcmp( TF[id - 1], pdes ) ) {
                    tf = id;
                    break;
                }
            }
            if ( tf == 0 ) {
                f_log << "The " << row_no << "th row in tooling.csv: Information incomplete.The tooling instance is skipped." << endl;
                memset( temp, 0, sizeof (temp) );
                f_tooling.getline( temp, 1000, '\n' );

                // memset(pdes,0,sizeof(pdes));
                row_no++;
            } else {
                one_tool.tf = tf;
                l = strtok2( pdes, temp, k, ',' ); // get tooling instance
                trim( pdes );
                if ( strlen( pdes ) <= 0 ) { // ti
                    f_log << "The " << row_no << "th row in tooling.csv: Tooling_Instance is empty.The tooling instance is skipped." << endl;
                    memset( temp, 0, sizeof (temp) );
                    f_tooling.getline( temp, 1000, '\n' );
                    row_no++;
                } else {
                    int ti = 0;

                    for ( int id = 1; id <= ( int ) TI.size( ); id++ ) {
                        if ( !strcmp( TI[id - 1], pdes ) ) {
                            ti = id;
                            break;
                        }
                    }
                    if ( ti == 0 ) {
                        f_log << "The " << row_no << "th row in tooling.csv: Information incomplete. The tooling instance is skipped." << endl;
                        memset( temp, 0, sizeof (temp) );
                        f_tooling.getline( temp, 1000, '\n' );
                        row_no++;
                    } else {
                        one_tool.id = ti;
                        k = strtok2( pdes, temp, l, ',' ); // get tooling family name
                        trim( pdes );
                        strcpy( one_tool.name, TI[one_tool.id - 1] );
                        l = strtok2( pdes, temp, k, ',' ); // certification
                        trim( pdes );
                        if ( strlen( pdes ) <= 0 ) { // for certification
                            f_log << "The " << row_no << "th row in tooling.csv: Certification is empty. The tooling instance is skipped." << endl;
                            memset( temp, 0, sizeof (temp) );
                            f_tooling.getline( temp, 1000, '\n' );
                            row_no++;
                        } else {
                            int temperature = atoi( pdes );

                            if ( temperature > Num_Temperature ) {
                                Num_Temperature = temperature;
                            }
                            if ( temperature <= 0 ) {
                                f_log << "The " << row_no << "th row in tooling.csv: Certification is non-positive. The tooling instance is skipped." << endl;
                                memset( temp, 0, sizeof (temp) );
                                f_tooling.getline( temp, 1000, '\n' );
                                row_no++;
                            } else {
                                one_tool.temperature_vector.push_back( temperature );
                                if ( !f_tooling.eof( ) ) {
                                    char tf_name[50];
                                    char ti_name[50];
                                    char tf_name2[50];


                                    do {
                                        memset( temp, 0, sizeof (temp) );
                                        f_tooling.getline( temp, 1000, '\n' );
                                        row_no++;
                                        if ( !f_tooling.eof( ) ) {
                                            l = 0;
                                            k = 0;
                                            k = strtok2( pdes, temp, l, ',' ); // tf
                                            trim( pdes );
                                            strcpy( tf_name, pdes );
                                            l = strtok2( pdes, temp, k, ',' ); // ti
                                            trim( pdes );
                                            strcpy( ti_name, pdes );
                                            k = strtok2( pdes, temp, l, ',' ); // tf_name
                                            trim( pdes );
                                            strcpy( tf_name2, pdes );
                                            l = strtok2( pdes, temp, k, ',' ); // certification
                                            trim( pdes );
                                            if ( tf > 0 && strlen( tf_name ) <= 0 && strlen( ti_name ) <= 0 && strlen( tf_name2 ) <= 0 ) {
                                                if ( strlen( pdes ) <= 0 ) {
                                                    f_log << "The " << row_no << "th row in tooling.csv: Certification is empty.It may be one of multiple certifications of one tooling. The row is skipped but not the tooling instance." << endl;
                                                } else {
                                                    int temperature = atoi( pdes );

                                                    if ( temperature > Num_Temperature ) {
                                                        Num_Temperature = temperature;
                                                    }
                                                    if ( temperature > 0 ) {
                                                        one_tool.temperature_vector.push_back( temperature );
                                                    } else {
                                                        f_log << "The "
                                                                << row_no << "th row in tooling.csv: Certification is non-positive.It may be one of multiple certifications of one tooling. The row is skipped but not the tooling instance." << endl;
                                                    }
                                                }
                                            }
                                        }
                                    } while ( !f_tooling.eof( ) && strlen( temp ) > 0 && strlen( tf_name ) <= 0 && strlen( ti_name ) <= 0 && strlen( tf_name2 ) <= 0 );
                                }
                                if ( tf > 0 ) {
                                    cout << "	" << Num_Tooling << "	" << TI[one_tool.id - 1] << endl;
                                    Tooling_vector[one_tool.id - 1] = one_tool;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    f_tooling.close( );

    // the following statement is to deal with the empty tooling requirement
    for ( int i = 1; i <= Num_Machine; i++ ) {
        struct Tooling one_tool;
        int tf = -100;

        for ( int id = 1; id <= ( int ) TF.size( ); id++ ) {
            if ( !strcmp( TF[id - 1], "No_Tooling" ) ) {
                tf = id;
                break;
            }
        }
        one_tool.tf = tf;
        int ti = 0;

        stringstream ss;
        ss << "No_Tooling-" << i;
        char name[50];

        strcpy( name, (ss.str( )).c_str( ) );
        for ( int id = 1; id <= ( int ) TI.size( ); id++ ) {
            if ( !strcmp( TI[id - 1], name ) ) {
                ti = id;
                break;
            }
        }
        one_tool.id = ti;
        strcpy( one_tool.name, TI[one_tool.id - 1] );
        for ( int tau = 1; tau <= Num_Temperature; tau++ ) {
            one_tool.temperature_vector.push_back( tau );
        }
        Tooling_vector[one_tool.id - 1] = one_tool;
    }
    // /// 
    show_Tooling_vector( );

    // ----------------------------------------------------------------------------------get Tooling_Setup_Time[]
    vector < bool > whether_exist_vector; // record whether a TF exist in toolingfamily_setuptime.csv
    whether_exist_vector.resize( ( int ) TF.size( ) );
    for ( int i = 1; i <= ( int ) whether_exist_vector.size( ); i++ ) {
        whether_exist_vector[i - 1] = false;
    }
    ifstream f_setup( "Data/toolingfamily_setuptime.csv" );
    cout << "get Tooling_Setup_Time[]" << endl;
    f_setup.getline( temp, 1000, '\n' );
    f_setup.getline( temp, 1000, '\n' );
    row_no = 2;
    trim( temp );
    while ( !f_setup.eof( ) && strlen( temp ) > 0 ) {
        int l = 0, k = 0;

        k = strtok2( pdes, temp, l, ',' ); // get the tf name
        trim( pdes );
        if ( strlen( pdes ) <= 0 ) {
            f_log << "The " << row_no << "th row in toolingfamily_setuptime.csv: Tooling_Family is empty. The row is skipped." << endl;
        } else {
            int tf_id = -100;

            for ( int j = 1; j <= ( int ) TF.size( ); j++ ) { // get the tf id in TF[]
                if ( !strcmp( TF[j - 1], pdes ) ) {
                    tf_id = j;
                    break;
                }
            }
            if ( tf_id > 0 ) { // if the tf exists in the tooling.csv file as well
                whether_exist_vector[tf_id - 1] = true;
                l = k;
                k = strtok2( pdes, temp, l, ',' ); // get the setup time
                trim( pdes );
                Tooling_Setup_Time[tf_id] = ( double ) atof( pdes );
                double setup_time = ( double ) atof( pdes );

                if ( setup_time <= 0 ) {
                    f_log << "The " << row_no << "th row in toolingfamily_setuptime.csv: Setup_time is non-positive.It is still used." << endl;
                }
            }// It is possible that tf_id<0, that is, the tf cannot be found in TF. In that case, just skip the current record.
            else {
                f_log << "The " << row_no << "th row in toolingfamily_setuptime.csv: No corresponding tool family. The row is skipped." << endl;
            }
        }
        f_setup.getline( temp, 1000, '\n' );
        trim( temp );
        row_no++;
    }
    f_setup.close( );
    f_setup.clear( );

    // the following statement is to deal with empty tooling requirement
    if ( 1 ) {
        int tf_id = -100;

        for ( int j = 1; j <= ( int ) TF.size( ); j++ ) { // get the tf id in TF[]
            if ( !strcmp( TF[j - 1], "No_Tooling" ) ) {
                tf_id = j;
                break;
            }
        }
        Tooling_Setup_Time[tf_id] = 0.0; // there is no setup time for empty tooling
        whether_exist_vector[tf_id - 1] = true;
    }

    // /
    for ( int i = 1; i <= ( int ) whether_exist_vector.size( ); i++ ) {
        if ( whether_exist_vector[i - 1] == false ) {
            f_log << "The tooling family " << TF[i - 1] << " exsits in tooling.csv but not in toolingfamily_setuptime.csv. The setuptime for this tooling family is taken as " << Tooling_Setup_Time[i] << endl;
        }
    }
    ofstream f_debugsetup( "Debug/debug_tf_setuptime.txt" );
    for ( int j = 1; j <= ( int ) TF.size( ); j++ ) {
        f_debugsetup << TF[j - 1] << "," << Tooling_Setup_Time[j] << endl;
    }
    f_debugsetup.close( );
    f_debugsetup.clear( );

    // ------------------data consistency checking for route.csv
    ofstream f_debugroute( "Debug/route.csv" );
    ifstream f_dataroute( "Data/route.csv" );

    // struct route_check one_route_check; // used to check whether wip has corresponding route.

    // The following is not used anymore
    // vector<string> device_vector;// used to check whether wip has corresponding route.
    vector < route_check > route_check_vector;
    char one_device[50];


    // struct route one_route;      // used to record a route
    // vector<route> route_vector;  // record all the route kept in Debug/route.csv. Used to do data consisitency for initialsetup.csv and initial lots in wip.csv
    f_dataroute.getline( temp, 1000, '\n' );
    trim( temp );
    f_debugroute << temp << endl;
    f_dataroute.getline( temp, 1000, '\n' );
    trim( temp );
    row_no = 2;
    while ( !f_dataroute.eof( ) && strlen( temp ) > 0 ) {
        l = 0;
        k = 0;
        k = strtok2( pdes, temp, l, ',' ); // Route_name
        l = k;
        trim( pdes );
        if ( strlen( pdes ) <= 0 ) {
            f_log << "The " << row_no << "th row in route.csv: RouteName is empty. The row is still used." << endl;
        }
        k = strtok2( pdes, temp, l, ',' ); // logpoint
        l = k;
        trim( pdes );

        int logpoint = atoi( pdes );

        if ( strlen( pdes ) <= 0 ) {
            f_log << "The " << row_no << "th row in route.csv: Logpoint is empty. The row is skipped." << endl;
            f_dataroute.getline( temp, 1000, '\n' );
            trim( temp );
            row_no++;
        } else {
            k = strtok2( pdes, temp, l, ',' ); // operation
            l = k;
            trim( pdes );
            int operation = atoi( pdes );

            if ( strlen( pdes ) <= 0 ) {
                f_log << "The " << row_no << "th row in route.csv: Operation is empty. The row is skipped." << endl;
                f_dataroute.getline( temp, 1000, '\n' );
                trim( temp );
                row_no++;
            } else {
                l = 0;
                k = 0;
                for ( int i = 1; i <= 6; i++ ) { // Device
                    k = strtok2( pdes, temp, l, ',' );
                    l = k;
                }
                trim( pdes );
                char device_name[50];

                strcpy( device_name, pdes );
                if ( strlen( pdes ) <= 0 ) {
                    f_log << "The " << row_no << "th row in route.csv: Device is empty. The row is skipped." << endl;
                    f_dataroute.getline( temp, 1000, '\n' );
                    trim( temp );
                    row_no++;
                } else {
                    memset( one_device, 0, sizeof (one_device) );
                    strcpy( one_device, pdes ); // get device name;
                    l = 0;
                    k = 0;
                    for ( int i = 1; i <= 11; i++ ) { // PPH;
                        k = strtok2( pdes, temp, l, ',' );
                        l = k;
                    }
                    trim( pdes );
                    int pph = atoi( pdes );

                    if ( pph <= 0 ) {
                        f_log << "The " << row_no << "th row in route.csv: PPH is non-positive. The row is skipped." << endl;
                        f_dataroute.getline( temp, 1000, '\n' );
                        trim( temp );
                        row_no++;
                    } else {
                        l = 0;
                        k = 0;
                        for ( int i = 1; i <= 12; i++ ) { // Machine_Family; NOT allow for empty machine_family now
                            k = strtok2( pdes, temp, l, ',' );
                            l = k;
                        }
                        trim( pdes );
                        char machine_family[50];

                        if ( strlen( pdes ) <= 0 ) {
                            f_log << "The " << row_no << "th row in route.csv: Machine_Family is empty. The row is skipped." << endl;

                            // strcpy(machine_family,MF[0]);
                            f_dataroute.getline( temp, 1000, '\n' );
                            trim( temp );
                            row_no++;
                        } else {

                            // char machine_family[50];
                            // else
                            // {
                            strcpy( machine_family, pdes );

                            // }
                            int mf_id = -1;

                            for ( int i = 1; i <= ( int ) MF.size( ); i++ ) {
                                if ( strcmp( machine_family, MF[i - 1] ) == 0 ) {
                                    mf_id = i;
                                }
                            }
                            if ( mf_id <= 0 ) {
                                f_log << "The " << row_no << "th row in route.csv: Machine_Family is not found in machines.csv. The row is skipped." << endl;
                                f_dataroute.getline( temp, 1000, '\n' );
                                trim( temp );
                                row_no++;
                            } else {
                                l = 0;
                                k = 0;
                                for ( int i = 1; i <= 13; i++ ) { // Tooling_Family;Note:the Tooling_Family can be empty.
                                    k = strtok2( pdes, temp, l, ',' );
                                    l = k;
                                }
                                trim( pdes );
                                char tool_family[50];

                                if ( strlen( pdes ) <= 0 ) {
                                    f_log << "The " << row_no << "th row in route.csv: Tooling_Family is empty. The row is still used." << endl;

                                    strcpy( tool_family, "No_Tooling" );
                                } else {
                                    strcpy( tool_family, pdes );
                                }
                                int tf_id = -1;

                                for ( int i = 1; i <= ( int ) TF.size( ); i++ ) {
                                    if ( strcmp( tool_family, TF[i - 1] ) == 0 ) {
                                        tf_id = i;
                                    }
                                }
                                if ( tf_id <= 0 ) {
                                    f_log << "The " << row_no << "th row in route.csv: Tooling_Family is not found in tooling.csv. The row is skipped." << endl;
                                    f_dataroute.getline( temp, 1000, '\n' );
                                    trim( temp );
                                    row_no++;
                                } else {
                                    l = 0;
                                    k = 0;
                                    for ( int i = 1; i <= 15; i++ ) { // Certification
                                        k = strtok2( pdes, temp, l, ',' );
                                        l = k;
                                    }
                                    trim( pdes );
                                    int certification = atoi( pdes );

                                    if ( certification <= 0 ) {
                                        f_log << "The " << row_no << "th row in route.csv: Certification is non-positive. The row is skipped." << endl;
                                        f_dataroute.getline( temp, 1000, '\n' );
                                        trim( temp );
                                        row_no++;
                                    } else {

                                        /*vector<string>::iterator p_find=find(device_vector.begin(),device_vector.end(),one_device);
                                           if(p_find==device_vector.end())
                                           {
                                           device_vector.push_back(one_device);
                                           } */
                                        struct route_check one_route_check;

                                        one_route_check.logpoint = logpoint;
                                        one_route_check.operation = operation;
                                        strcpy( one_route_check.device, one_device );
                                        route_check_vector.push_back( one_route_check );

                                        /*
                                           struct route one_route;
                                           one_route.row_no=row_no;
                                           one_route.log_point=log_point;
                                           one_route.mf_id=mf_id;
                                           one_route.tf_id=tf_id;
                                           one_route.certification=certification;
                                           strcpy(one_route.device_name,device_name);
                                           route_vector.push_back(one_route);
                                         */
                                        f_debugroute << temp << endl;
                                        f_dataroute.getline( temp, 1000, '\n' );
                                        trim( temp );
                                        row_no++;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    f_debugroute.close( );
    f_debugroute.clear( );
    f_dataroute.close( );
    f_dataroute.clear( );

    // ----------------------------------------------------------------------------------get LOT
    // Do data checking first. If any critical field is blank, skip the lot.
    // Modifed by Zhufeng, August 12, 2012, removing "End"
    ofstream f_debugwip( "Debug/wip.csv" );
    ifstream f_wip( "Data/wip.csv" );

    // f_wip.getline(temp,1000,'\n');
    f_wip.getline( temp, 1000, '\n' );
    trim( temp );
    f_debugwip << temp << endl;
    f_wip.getline( temp, 1000, '\n' );
    trim( temp );
    row_no = 2;

    // first check whether the snapshot time is in correct format
    if ( !f_wip.eof( ) && strlen( temp ) > 0 ) {
        l = 0;
        k = 0;
        for ( int i = 1; i <= 14; i++ ) {
            k = strtok2( pdes, temp, l, ',' );
            l = k;
        }
        trim( pdes ); // get the General Snapshot time
        int snapshot_time_length = strlen( pdes );

        if ( strlen( pdes ) <= 0 ) {
            f_log << "The " << row_no << "th row in wip.csv: SNAPSHOT_TIME is empty. This may couse some errors." << endl;
        } else {
            k = 0;
            l = 0;
            char pdes2[50];

            memset( pdes2, 0, sizeof (pdes2) );
            k = strtok2( pdes2, pdes, l, '/' ); // get MM
            l = k;
            if ( strlen( pdes2 ) <= 0 ) {
                f_log << "The " << row_no << "th row in wip.csv: the month in SNAPSHOT_TIME is empty. This may couse some errors." << endl;
            } else {
                int mm;

                mm = atoi( pdes2 );
                if ( mm <= 0 || mm > 12 ) {
                    f_log << "The " << row_no << "th row in wip.csv: the month in SNAPSHOT_TIME is wrong. This may couse some errors." << endl;
                }
                if ( l >= snapshot_time_length ) {
                    f_log << "The " << row_no << "th row in wip.csv: the SNAPSHOT_TIME is in wrong format or only have information about month. This may couse some errors." << endl;
                } else {
                    l = 0;
                    k = 0;
                    for ( int i = 1; i <= 2; i++ ) {
                        k = strtok2( pdes2, pdes, l, '/' ); // get day
                        l = k;
                    }
                    if ( strlen( pdes2 ) <= 0 ) {
                        f_log << "The " << row_no << "th row in wip.csv: the day in SNAPSHOT_TIME is empty. This may couse some errors." << endl;
                    } else {
                        int dd = atoi( pdes2 );

                        if ( dd < 0 || dd > 31 ) {
                            f_log << "The " << row_no << "th row in wip.csv: the day in SNAPSHOT_TIME is wrong. This may couse some errors." << endl;
                        }
                        if ( l >= snapshot_time_length ) {
                            f_log << "The " << row_no << "th row in wip.csv: the SNAPSHOT_TIME is in wrong format or only has onformation about month and day. This may couse some errors." << endl;
                        } else {
                            l = 0;
                            k = 0;
                            for ( int i = 1; i <= 2; i++ ) {
                                k = strtok2( pdes2, pdes, l, '/' );
                                l = k;
                            }
                            k = strtok2( pdes2, pdes, l, ' ', '/' ); // get YY
                            l = k;
                            trim( pdes2 );
                            if ( strlen( pdes2 ) <= 0 ) {
                                f_log << "The " << row_no << "th row in wip.csv: the year in SNAPSHOT_TIME is empty. This may couse some errors." << endl;
                            } else {
                                if ( l >= snapshot_time_length ) {
                                    f_log << "The " << row_no << "th row in wip.csv: the SNAPSHOT_TIME is in wrong format or lack information about hh:mm:ss. This may couse some errors." << endl;
                                } else {
                                    k = strtok2( pdes2, pdes, l, ':' ); // get hh
                                    trim( pdes2 );
                                    int hh_length = strlen( pdes2 );
                                    int hh = atoi( pdes2 );

                                    ;
                                    l = k;
                                    k = strtok2( pdes2, pdes, l, ':' ); // get mm
                                    trim( pdes2 );

                                    int mm_length = strlen( pdes2 );
                                    int mm = atoi( pdes2 );

                                    l = k;
                                    if ( l >= snapshot_time_length ) {
                                        f_log << "The " << row_no << "th row in wip.csv: the hh:mm:ss in SNAPSHOT_TIME is wrong or incomplete. This may couse some errors." << endl;
                                    } else {
                                        k = strtok2( pdes2, pdes, l, ' ' ); // get ss
                                        trim( pdes2 );
                                        int ss_length = strlen( pdes2 );
                                        int ss = atoi( pdes2 );

                                        if ( hh_length <= 0 || hh < 0 || hh > 24 || mm_length <= 0 || mm < 0 || mm >= 60 || ss_length <= 0 || ss < 0 || ss >= 60 ) {
                                            f_log << "The " << row_no << "th row in wip.csv: the hh:mm:ss in SNAPSHOT_TIME is wrong. This may couse some errors." << endl;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    while ( !f_wip.eof( ) && strlen( temp ) > 0 ) {
        l = 0;
        k = 0;
        k = strtok2( pdes, temp, l, ',' ); // LOT
        trim( pdes );
        l = k;
        if ( strlen( pdes ) <= 0 ) {
            f_wip.getline( temp, 1000, '\n' );
            f_log << "The " << row_no << "th row in wip.csv: LOT is empty. The row is skipped." << endl;
            row_no++;
        } else {
            k = strtok2( pdes, temp, l, ',' ); // DEVICE
            trim( pdes );
            l = k;
            if ( strlen( pdes ) <= 0 ) {
                f_wip.getline( temp, 1000, '\n' );
                f_log << "The " << row_no << "th row in wip.csv: DEVICE is empty. The row is skipped." << endl;
                row_no++;
            } else {
                strcpy( one_device, pdes );
                k = strtok2( pdes, temp, l, ',' ); // package
                l = k;
                trim( pdes );
                if ( strlen( pdes ) <= 0 ) {
                    f_wip.getline( temp, 1000, '\n' );
                    f_log << "The " << row_no << "th row in wip.csv: Package is empty. The row is skipped." << endl;
                    row_no++;
                } else {
                    k = strtok2( pdes, temp, l, ',' ); // Pin
                    l = k;
                    trim( pdes );
                    if ( strlen( pdes ) <= 0 ) {
                        f_wip.getline( temp, 1000, '\n' );
                        f_log << "The " << row_no << "th row in wip.csv: Pin is empty. The row is skipped." << endl;
                        row_no++;
                    } else {
                        k = strtok2( pdes, temp, l, ',' ); // CUR_QTY
                        l = k;
                        trim( pdes );
                        if ( strlen( pdes ) <= 0 ) {
                            f_wip.getline( temp, 1000, '\n' );
                            f_log << "The " << row_no << "th row in wip.csv: CUR_QTY is empty. The row is skipped." << endl;
                            row_no++;
                        } else {
                            k = strtok2( pdes, temp, l, ',' ); // weight
                            l = k;
                            trim( pdes );
                            if ( strlen( pdes ) <= 0 ) {
                                f_wip.getline( temp, 1000, '\n' );
                                f_log << "The " << row_no << "th row in wip.csv: Weight is empty. The row is skipped." << endl;
                                row_no++;
                            } else {
                                k = strtok2( pdes, temp, l, ',' ); // Lot_Name
                                l = k;
                                k = strtok2( pdes, temp, l, ',' ); // LPT
                                l = k;
                                trim( pdes );
                                int logpoint = atoi( pdes );

                                if ( strlen( pdes ) <= 0 ) {
                                    f_wip.getline( temp, 1000, '\n' );
                                    f_log << "The " << row_no << "th row in wip.csv: LPT is empty. The row is skipped." << endl;
                                    row_no++;
                                } else {
                                    k = strtok2( pdes, temp, l, ',' ); // OPN
                                    l = k;
                                    trim( pdes );
                                    int operation = atoi( pdes );

                                    if ( strlen( pdes ) <= 0 ) {
                                        f_wip.getline( temp, 1000, '\n' );
                                        f_log << "The " << row_no << "th row in wip.csv: OPN is empty. The row is skipped." << endl;
                                        row_no++;
                                    } else {
                                        vector < route_check >::iterator p_route = route_check_vector.begin( );
                                        while ( p_route != route_check_vector.end( ) ) {
                                            if ( (*p_route).logpoint != logpoint ) {
                                                p_route++;
                                            } else {
                                                if ( (*p_route).operation != operation ) {
                                                    p_route++;
                                                } else {
                                                    if ( strcmp( one_device, (*p_route).device ) ) {
                                                        p_route++;
                                                    } else {
                                                        break;
                                                    }
                                                }
                                            } // end of if((* p_route).logpoint!=logpoint)
                                        } // end of while( p_route != route_check_vector.end())
                                        if ( p_route == route_check_vector.end( ) ) { // does the wip have a route?
                                            f_wip.getline( temp, 1000, '\n' );
                                            f_log << "The " << row_no << "th row in wip.csv: The lot with Device, LPT,and OPN doesn't have a route in route.csv. The row is skipped." << endl;
                                            row_no++;
                                        } else {
                                            l = 0;
                                            k = 0;
                                            for ( int i = 1; i <= 14; i++ ) {
                                                k = strtok2( pdes, temp, l, ',' ); // SNAPSHOT_TIME
                                                l = k;
                                            }
                                            trim( pdes );
                                            if ( strlen( pdes ) <= 0 ) {
                                                f_wip.getline( temp, 1000, '\n' );
                                                f_log << "The " << row_no << "th row in wip.csv: SNAPSHOT_TIME is empty. The row is skipped." << endl;
                                                row_no++;
                                            } else {
                                                char start_time[50];
                                                char mi_initial[50];

                                                l = 0;
                                                k = 0;
                                                for ( int i = 1; i <= 13; i++ ) {
                                                    k = strtok2( pdes, temp, l, ',' ); // START_TIME
                                                    l = k;
                                                }
                                                trim( pdes );
                                                strcpy( start_time, pdes );
                                                l = 0;
                                                k = 0;
                                                for ( int i = 1; i <= 15; i++ ) {
                                                    k = strtok2( pdes, temp, l, ',' ); // Machine_Instance
                                                    l = k;
                                                }
                                                trim( pdes );
                                                strcpy( mi_initial, pdes );
                                                if ( (strlen( start_time ) <= 0 && strlen( mi_initial ) > 0) || (strlen( start_time ) > 0 && strlen( mi_initial ) <= 0) ) {
                                                    f_wip.getline( temp, 1000, '\n' );
                                                    f_log << "The " << row_no << "th row in wip.csv: This is an initial lot but the star_time or machine_instance is empty. The row is skipped." << endl;
                                                    row_no++;
                                                } else {
                                                    if ( strlen( mi_initial ) > 0 ) {

                                                        // initial lot
                                                        int machine_id = -1;

                                                        for ( int j = 1; j <= ( int ) MI.size( ); j++ ) {
                                                            if ( !strcmp( MI[j - 1], mi_initial ) ) {
                                                                machine_id = j;
                                                                break;
                                                            }
                                                        }
                                                        if ( machine_id < 0 ) { // if the machine_id is not included in <MI>,then simply discard the info of this line. Continue to the next line
                                                            f_log << "The " << row_no << "th row in wip.csv: This is an initial lot but the machine_instance is not found in machines.csv. The row is skipped." << endl;
                                                            row_no++;
                                                            f_wip.getline( temp, 1000, '\n' );
                                                        } else {
                                                            f_debugwip << temp << endl;
                                                            f_wip.getline( temp, 1000, '\n' );
                                                            row_no++;
                                                        }
                                                    } else {

                                                        // regular lot
                                                        f_debugwip << temp << endl;
                                                        f_wip.getline( temp, 1000, '\n' );
                                                        row_no++;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    f_debugwip.close( );
    f_debugwip.clear( );
    f_wip.close( );

    // read wip.csv
    for ( int l = 0; l < Max_Num_Lot; l++ ) {
        w_l[l] = 0.0;
    }
    f_wip.open( "Debug/wip.csv" );
    f_wip.getline( temp, 1000, '\n' );
    f_wip.getline( temp, 1000, '\n' );
    trim( temp );
    cout << "get LOT" << endl;
    Num_Lot = 0;
    Num_Device = 0;
    while ( !f_wip.eof( ) && strlen( temp ) > 0 ) {
        int l = 0, k = 0;


        // ------------------------------------------test if the lot is an initial lot
        for ( int j = 1; j <= 6; j++ ) {
            k = strtok2( pdes, temp, l, ',' );
            l = strtok2( pdes, temp, k, ',' );
        }
        k = strtok2( pdes, temp, l, ',' ); // get "Start_time"
        trim( pdes );

        // ---------------------------------------------------------------------------
        if ( strlen( pdes ) <= 0 ) { // if this field is blank, then it is a regular lot
            l = 0;
            k = strtok2( pdes, temp, l, ',' );
            trim( pdes );
            bool lot_exist = false;
            for ( int id = 1; id <= ( int ) LOT.size( ); id++ ) {
                if ( !strcmp( LOT[id - 1], pdes ) ) {
                    lot_exist = true;
                    break;
                }
            }
            if ( !lot_exist ) { // lot does not exist
                char *name = new char[50];

                strcpy( name, pdes );
                LOT.push_back( name );
            }
        }
        f_wip.getline( temp, 1000, '\n' );
        trim( temp );
    }
    Num_Lot = ( int ) LOT.size( );
    f_wip.close( );
    f_wip.clear( );
    f_wip.open( "Debug/wip.csv" );

    // ---------------------------------------------------------------------------------get DEV
    f_wip.getline( temp, 1000, '\n' );
    f_wip.getline( temp, 1000, '\n' );
    trim( temp );
    cout << "get DEV" << endl;
    while ( !f_wip.eof( ) && strlen( temp ) > 0 ) {
        int l = 0, k = 0;


        // ------------------------------------------test if the lot is an initial lot
        for ( int j = 1; j <= 6; j++ ) {
            k = strtok2( pdes, temp, l, ',' );
            l = strtok2( pdes, temp, k, ',' );
        }
        k = strtok2( pdes, temp, l, ',' ); // get "Start_time"
        trim( pdes );

        // ---------------------------------------------------------------------------
        if ( strlen( pdes ) <= 0 ) { // if this field is blank, then it is a regular lot
            l = 0;
            k = strtok2( pdes, temp, l, ',' );
            l = k;
            k = strtok2( pdes, temp, l, ',' ); // get the device info
            trim( pdes );
            bool dev_exist = false;
            for ( int id = 1; id <= ( int ) DEV.size( ); id++ ) {
                if ( !strcmp( DEV[id - 1], pdes ) ) {
                    dev_exist = true;
                    break;
                }
            }
            if ( !dev_exist ) { // dev does not exist
                char *name = new char[50];

                strcpy( name, pdes );
                DEV.push_back( name );
            }
        }
        f_wip.getline( temp, 1000, '\n' );
        trim( temp );
    }
    Num_Device = ( int ) DEV.size( );
    f_wip.close( );
    f_wip.clear( );

    // ----------------------------------------------------------------------------------get PKG
    int dummy_pkg_pos = -1;

    f_wip.open( "Debug/wip.csv" );
    f_wip.getline( temp, 1000, '\n' );
    f_wip.getline( temp, 1000, '\n' );
    trim( temp );
    cout << "get PKG" << endl;
    PKG.clear( );
    while ( !f_wip.eof( ) && strlen( temp ) > 0 ) {
        int l = 0, k = 0;


        // ------------------------------------------test if the lot is an initial lot
        for ( int j = 1; j <= 6; j++ ) {
            k = strtok2( pdes, temp, l, ',' );
            l = strtok2( pdes, temp, k, ',' );
        }
        k = strtok2( pdes, temp, l, ',' ); // get "Start_time"
        trim( pdes );

        // ---------------------------------------------------------------------------
        if ( strlen( pdes ) <= 0 ) { // if this field is blank, then it is a regular lot
            l = 0;
            k = strtok2( pdes, temp, l, ',' );
            l = k;
            k = strtok2( pdes, temp, l, ',' );
            l = k;
            k = strtok2( pdes, temp, l, ',' ); // get package info
            trim( pdes );
            bool pkg_exist = false;
            for ( int id = 1; id <= ( int ) PKG.size( ); id++ ) {
                if ( !strcmp( PKG[id - 1], pdes ) ) {
                    pkg_exist = true;
                    break;
                }
            }
            if ( !pkg_exist ) { // pkg does not exist
                char *name = new char[50];

                strcpy( name, pdes );
                PKG.push_back( name );
            }
        }
        f_wip.getline( temp, 1000, '\n' );
        trim( temp );
    }
    f_wip.close( );
    f_wip.clear( );

    // it is likely that some other devices will be introduced later (mainly come from other files)
    // however, there is no pkg and pin information for these devices
    // thus, append dummy pkg info for these devices here
    // Note:the pointer to "dummy_pkg" must be valid throught the whole program. So use new[] but not use delete[]
    char *dummyname = new char[50];

    strcpy( dummyname, "dummy_pkg" );
    PKG.push_back( dummyname );

    // PKG will be extended later, thus remember of position of the dummy_pkg
    dummy_pkg_pos = ( int ) PKG.size( );

    // ----------------------------------------------------------------------------------get device_PKG,device_PIN
    for ( int id = 0; id <= Max_Num_Device - 1; id++ ) {
        device_PKG[id] = -100;
        device_PIN[id] = -100;
    }
    cout << "get device_PKG[],device_PIN" << endl;
    f_wip.open( "Debug/wip.csv" );
    f_wip.getline( temp, 1000, '\n' );
    f_wip.getline( temp, 1000, '\n' );
    trim( temp );
    while ( !f_wip.eof( ) && strlen( temp ) > 0 ) {
        int l = 0, k = 0;


        // ------------------------------------------test if the lot is an initial lot
        for ( int j = 1; j <= 6; j++ ) {
            k = strtok2( pdes, temp, l, ',' );
            l = strtok2( pdes, temp, k, ',' );
        }
        k = strtok2( pdes, temp, l, ',' ); // get "Start_time"
        trim( pdes );

        // ---------------------------------------------------------------------------
        if ( strlen( pdes ) <= 0 ) { // if this field is blank, then it is a regular lot
            l = 0;
            k = strtok2( pdes, temp, l, ',' );
            l = k;
            k = strtok2( pdes, temp, l, ',' ); // get device info
            trim( pdes );
            int dev_id = -1;

            for ( int id = 1; id <= ( int ) DEV.size( ); id++ ) {
                if ( !strcmp( DEV[id - 1], pdes ) ) {
                    dev_id = id;
                    break;
                }
            }
            if ( dev_id < 1 ) {
                cout << "Wrong device id, abort" << endl;
                abort( );
            }
            l = k;
            k = strtok2( pdes, temp, l, ',' ); // get package info
            trim( pdes );
            int pkg_id = -1;

            for ( int id = 1; id <= ( int ) PKG.size( ); id++ ) {
                if ( !strcmp( PKG[id - 1], pdes ) ) {
                    pkg_id = id;
                    break;
                }
            }
            if ( pkg_id < 1 ) {

                // no pkg info for such device (it is possible this field is empty)
                // assign the current device to package dummy_pkg
                pkg_id = dummy_pkg_pos;
            }
            device_PKG[dev_id] = pkg_id;
            l = k;
            k = strtok2( pdes, temp, l, ',' ); // get PIN info
            trim( pdes );
            int pin = atoi( pdes );

            if ( device_PIN[dev_id] > 0 && device_PIN[dev_id] != pin ) {
                cout << "same device " << DEV[dev_id - 1] << " has different number of pins. abort" << endl;
                abort( );
            }
            device_PIN[dev_id] = pin; // it is possible that pin=0 when the field is empty
        }
        f_wip.getline( temp, 1000, '\n' );
        trim( temp );
    }

    // ----------------------------------------------------------------------------------get n_l_chips, lots_device and lot weight
    f_wip.close( );
    f_wip.clear( );
    f_wip.open( "Debug/wip.csv" );
    f_wip.getline( temp, 1000, '\n' );
    f_wip.getline( temp, 1000, '\n' );
    trim( temp );
    cout << "get n_l_chips[], lots_device[],and w_l[]" << endl;
    while ( !f_wip.eof( ) && strlen( temp ) > 0 ) {
        int l = 0, k = 0;


        // ------------------------------------------test if the lot is an initial lot
        for ( int j = 1; j <= 6; j++ ) {
            k = strtok2( pdes, temp, l, ',' );
            l = strtok2( pdes, temp, k, ',' );
        }
        k = strtok2( pdes, temp, l, ',' ); // get "Start_time"
        trim( pdes );

        // ---------------------------------------------------------------------------
        if ( strlen( pdes ) <= 0 ) { // if this field is blank, then it is a regular lot
            l = 0;
            k = strtok2( pdes, temp, l, ',' ); // get Lot name
            trim( pdes );

            // -----------
            int lot = 0;

            for ( int id = 1; id <= ( int ) LOT.size( ); id++ ) {
                if ( !strcmp( LOT[id - 1], pdes ) ) {
                    lot = id;
                    break;
                }
            }
            if ( lot < 1 ) {
                cout << "Wrong lot id" << endl;
                abort( );
            }
            l = strtok2( pdes, temp, k, ',' ); // get device name
            trim( pdes );

            // --------------
            int dev = 0;

            for ( int id = 1; id <= ( int ) DEV.size( ); id++ ) {
                if ( !strcmp( DEV[id - 1], pdes ) ) {
                    dev = id;
                    break;
                }
            }
            if ( dev < 1 ) {
                cout << "Wrong dev id" << endl;
                abort( );
            }

            // ---------------
            k = strtok2( pdes, temp, l, ',' ); // skip package
            l = strtok2( pdes, temp, k, ',' ); // skip pin
            k = strtok2( pdes, temp, l, ',' ); // get qty
            trim( pdes );
            n_l_chips[lot] = atoi( pdes );
            lots_device[lot] = dev;
            l = strtok2( pdes, temp, k, ',' ); // get lot weight
            trim( pdes );
            w_l[lot] = ( double ) atof( pdes );
            k = strtok2( pdes, temp, l, ',' ); // get lot name
            trim( pdes );
            struct ch_array one_ch_array;

            one_ch_array.id = lot;
            strcpy( one_ch_array.char_arry, pdes );
            lot_name.push_back( one_ch_array );
            l = strtok2( pdes, temp, k, ',' ); // get log point
            trim( pdes );
            int logpoint = atoi( pdes );

            lot_logpoint[lot] = logpoint;
            k = strtok2( pdes, temp, l, ',' ); // get operation
            trim( pdes );
            int operation = atoi( pdes );

            lot_operation[lot] = operation;
        }
        f_wip.getline( temp, 1000, '\n' );
        trim( temp );
    }
    f_wip.close( );
    f_wip.clear( );

    // ------------------------------------------------------------------------------get General_Snapshot_time
    f_wip.open( "Debug/wip.csv" );
    f_wip.getline( temp, 1000, '\n' );
    f_wip.getline( temp, 1000, '\n' );
    trim( temp );
    if ( 1 ) {
        int l = 0, k = 0;

        for ( int j = 1; j <= 7; j++ ) {
            k = strtok2( pdes, temp, l, ',' );
            l = strtok2( pdes, temp, k, ',' );
        }
        trim( pdes );
        str_to_date_time( pdes, General_Snapshot_time );
    }
    f_wip.close( );
    f_wip.clear( );
    output_date_time( General_Snapshot_time );

    // ------------------------------------------------------------------------------get the initial_running_lot
    f_wip.open( "Debug/wip.csv" );
    f_wip.getline( temp, 1000, '\n' );
    f_wip.getline( temp, 1000, '\n' );
    trim( temp );
    cout << "get the initial_running_lot" << endl;
    int line_num = 2;

    while ( !f_wip.eof( ) && strlen( temp ) > 0 ) {
        int l = 0, k = 0;


        // ------------------------------------------test if the lot is an initial lot
        for ( int j = 1; j <= 6; j++ ) {
            k = strtok2( pdes, temp, l, ',' );
            l = strtok2( pdes, temp, k, ',' );
        }
        k = strtok2( pdes, temp, l, ',' ); // get "Start_time"
        trim( pdes );

        // ---------------------------------------------------------------------------
        if ( strlen( pdes ) > 0 ) { // this field is not empty,thus the lot is running initially
            cout << temp << endl;
            struct initial_running_lot_item one_item;

            l = 0;
            k = strtok2( pdes, temp, l, ',' ); // get lot name
            trim( pdes );
            strcpy( one_item.lot_name, pdes );
            l = k;
            k = strtok2( pdes, temp, l, ',' ); // get device name
            trim( pdes );
            strcpy( one_item.dev_name, pdes );
            l = k;
            k = strtok2( pdes, temp, l, ',' ); // get pkg name
            trim( pdes );
            strcpy( one_item.PKG_name, pdes );
            l = k;
            k = strtok2( pdes, temp, l, ',' ); // get pin number
            trim( pdes );
            one_item.PIN_num = atoi( pdes );
            l = k;
            k = strtok2( pdes, temp, l, ',' ); // get quantity
            trim( pdes );
            one_item.n_l_chips = atoi( pdes );
            l = k;
            k = strtok2( pdes, temp, l, ',' ); // get lot weight
            trim( pdes );
            one_item.w_l = ( double ) atof( pdes );
            for ( int j = 1; j <= 7; j++ ) {
                l = k;
                k = strtok2( pdes, temp, l, ',' ); // get "Start_time"
            }
            trim( pdes );
            str_to_date_time( pdes, one_item.Start_time );
            l = k;
            k = strtok2( pdes, temp, l, ',' ); // get "Snapshot_time"
            trim( pdes );
            str_to_date_time( pdes, one_item.Snapshot_time );
            l = k;
            k = strtok2( pdes, temp, l, ',' ); // get machine name
            trim( pdes );
            strcpy( one_item.machine_name, pdes );
            int machine_id = -1;

            for ( int j = 1; j <= ( int ) MI.size( ); j++ ) {
                if ( !strcmp( MI[j - 1], one_item.machine_name ) ) {
                    machine_id = j;
                    break;
                }
            }
            if ( machine_id < 0 ) { // if the machine_id is not included in <MI>,then simply discard the info of this line. Continue to the next line
                cout << "Warnning message: in file wip.csv, the machine_instance " << one_item.machine_name << " corresponds to lot " << one_item.lot_name << " in line " << line_num << " does not exist in file machines.csv" << endl;
                f_wip.getline( temp, 1000, '\n' );
                line_num++;
                continue;
            }
            one_item.machine_id = machine_id;
            k = 0;
            l = 0;
            for ( int i = 1; i <= 8; i++ ) {
                k = strtok2( pdes, temp, l, ',' );
                l = k;
            }
            trim( pdes );
            one_item.logpoint = atoi( pdes );
            k = 0;
            l = 0;
            for ( int i = 1; i <= 9; i++ ) {
                k = strtok2( pdes, temp, l, ',' );
                l = k;
            }
            trim( pdes );
            one_item.operation = atoi( pdes );
            initial_running_lot.push_back( one_item );
        } // end_if
        f_wip.getline( temp, 1000, '\n' );
        trim( temp );
        line_num++;
    }
    f_wip.close( );
    f_wip.clear( );
    extend_initial_lot( initial_running_lot ); // this fuctin is called immedaite after <initial_running_lot> is ready to extend the arrays
    // -----------------------------------------------------------------------------------------------------------
    // read the keydevices.csv
    ifstream p_key( "Data/keydevices.csv" );
    p_key.getline( temp, 1000, '\n' );
    p_key.getline( temp, 1000, '\n' );

    // adde by Zhufeng
    row_no = 2;
    trim( temp );
    Num_Keydevice = 0;
    while ( !p_key.eof( ) && strlen( temp ) > 0 ) {
        int l = 0, k = 0;

        k = strtok2( pdes, temp, l, ',' );
        trim( pdes );
        if ( strlen( pdes ) <= 0 ) {
            f_log << "The " << row_no << "th row in keydevices.csv: The Key_Device is empty. Skip the row." << endl;
            p_key.getline( temp, 1000, '\n' );
            trim( temp );
            row_no++;
        } else {
            int dev = 0;

            for ( int id = 1; id <= ( int ) DEV.size( ); id++ ) {
                if ( !strcmp( DEV[id - 1], pdes ) ) {
                    dev = id;
                    break;
                }
            }
            if ( dev < 1 ) {
                cout << "Add device " << pdes << " to the set of devices DEV" << endl;
                f_log << "The " << row_no << "th row in keydevices.csv: The Key_Device is not found (or skipped )in wip.csv. Add device " << pdes << " to the set of devices DEV. It is still used." << endl;
                dev = Num_Device + 1;
                Num_Device++;
                char *name = new char[50];

                strcpy( name, pdes );
                DEV.push_back( name );

                // link the device just added to the dummy_pkg since there is no package info for the device
                device_PKG[Num_Device] = dummy_pkg_pos;
            }
            Key_Devices.push_back( dev );
            l = strtok2( pdes, temp, k, ',' );
            trim( pdes );
            int target = atoi( pdes );

            if ( target <= 0 ) {
                f_log << "The " << row_no << "th row in keydevices.csv: The Target is non-positive.It is still used." << endl;
            }
            n_k_minchips[dev] = atoi( pdes );
            Num_Keydevice++;
            p_key.getline( temp, 1000, '\n' );
            trim( temp );
            row_no++;
        }
    }
    p_key.close( );

    // ----------------------------------------this is originally for package.csv
    // however, since the definition for package is changed, we need to update this part for key_package
    // read the key_package.csv
    ifstream p_package( "Data/key_package.csv" );
    p_package.getline( temp, 1000, '\n' );
    p_package.getline( temp, 1000, '\n' );
    trim( temp );
    row_no = 2;
    Num_Key_PKG = 0;
    while ( !p_package.eof( ) && strlen( temp ) > 0 ) {
        int l = 0, k = 0;

        k = strtok2( pdes, temp, l, ',' );
        trim( pdes );
        if ( strlen( pdes ) <= 0 ) {
            f_log << "The " << row_no << "th row in key_package.csv: The Key_Package is empty. Skip the row." << endl;
            p_key.getline( temp, 1000, '\n' );
            trim( temp );
            row_no++;
        } else {
            int pkg = 0;

            for ( int id = 1; id <= ( int ) PKG.size( ); id++ ) {
                if ( !strcmp( PKG[id - 1], pdes ) ) {
                    pkg = id;
                    break;
                }
            }
            if ( pkg < 1 ) {
                cout << "Add package " << pdes << " to the set of PKG in reading key_package.csv" << endl;
                f_log << "The " << row_no << "th row in key_package.csv: The Key_Package is not found in wip.csv. Add package " << pdes << " to the set of PKG. It is still used." << endl;
                pkg = ( int ) PKG.size( ) + 1;
                char *name = new char[50];

                strcpy( name, pdes );
                PKG.push_back( name );
            }
            Key_PKG.push_back( pkg );
            l = strtok2( pdes, temp, k, ',' );
            trim( pdes );
            int target = atoi( pdes );

            if ( target <= 0 ) {
                f_log << "The " << row_no << "th row in key_package.csv: The Key_Package is non-positive.It is still used." << endl;
            }
            n_kp_minchips[pkg] = atoi( pdes );

            Num_Key_PKG++;
            p_package.getline( temp, 1000, '\n' );
            trim( temp );
            row_no++;
        }
    }
    p_package.close( );

    // -------------------------------------------------------------read key_pin_package.csv
    ifstream f_kpp( "Data/key_pin_package.csv" );
    f_kpp.getline( temp, 1000, '\n' );
    f_kpp.getline( temp, 1000, '\n' );
    trim( temp );
    row_no = 2;
    while ( !f_kpp.eof( ) && strlen( temp ) > 0 ) {

        // package,pin,target
        int l = 0, k = 0;

        k = strtok2( pdes, temp, l, ',' ); // package
        trim( pdes );
        if ( strlen( pdes ) <= 0 ) {
            f_log << "The " << row_no << "th row in key_pin_package.csv: The Key_Package is empty. Skip the row." << endl;
            p_key.getline( temp, 1000, '\n' );
            trim( temp );
            row_no++;
        } else {
            int pkg = 0, pin = 0;

            for ( int id = 1; id <= ( int ) PKG.size( ); id++ ) {
                if ( !strcmp( PKG[id - 1], pdes ) ) {
                    pkg = id;
                    break;
                }
            }
            if ( pkg < 1 ) {
                cout << "Add package " << pdes << " to the set of PKG in reading key_pin_package.csv" << endl;
                f_log << "The " << row_no << "th row in key_pin_package.csv: The Key_Package is not found in wip.csv. Add package " << pdes << " to the set of PKG. It is still used." << endl;
                pkg = ( int ) PKG.size( ) + 1;
                char *name = new char[50];

                strcpy( name, pdes );
                PKG.push_back( name );
            }
            l = k;
            k = strtok2( pdes, temp, l, ',' ); // pin
            trim( pdes );
            pin = atoi( pdes );
            l = k;
            k = strtok2( pdes, temp, l, ',' ); // target
            trim( pdes );
            int target = atoi( pdes );

            if ( pin <= 0 || target <= 0 ) {
                f_log << "The " << row_no << "th row in key_pin_package.csv: The Pin or the Target is non-positive.It is still used." << endl;
            }
            Key_PIN_PKG.push_back( make_pair( make_pair( pin, pkg ), target ) );
            f_kpp.getline( temp, 1000, '\n' );
            trim( temp );
            row_no++;
        } // end of /ifif(strlen(pdes)<=0)// package
    }
    f_kpp.close( );

    // -------------------------------------------------------------device_name
    for ( int i = 1; i <= Num_Device; i++ ) {
        struct ch_array one_dev;

        strcpy( one_dev.char_arry, DEV[i - 1] );
        one_dev.id = i;
        device_name.push_back( one_dev );
    }
    // -------------------------------------------------------------
    cout << "Num_Lot=" << Num_Lot << ",Num_Device=" << Num_Device << endl;
    for ( int d = 1; d <= Num_Device; d++ ) {
        struct device_item one_dev;

        one_dev.device = d;
        for ( int l = 1; l <= Num_Lot; l++ ) {
            if ( lots_device[l] == one_dev.device ) {
                one_dev.device_lots.push_back( l );
            }
        }
        Devices.push_back( one_dev );
    }
    show_Devices( );

    // ----------------------------------------------------------
    // ---------------------------------------------------------------
    // read the route.csv
    double min_weight = 1E+8;

    for ( int l = 1; l <= Num_Lot; l++ ) {
        if ( w_l[l] < min_weight && w_l[l] > 0 ) {
            min_weight = w_l[l];
        }
    }

    // Initialize eps
    for ( int i = 1; i <= Max_Num_Tooling_Configure; i++ ) {
        eps[i - 1] = 0;
    }
    ifstream f_route( "Debug/route.csv" );
    f_route.getline( temp, 1000, '\n' );
    f_route.getline( temp, 1000, '\n' );
    trim( temp );
    int count = 0;
    int count_gao = 0;

    while ( !f_route.eof( ) && strlen( temp ) > 0 ) {
        int l = 0, k = 0;

        for ( int i = 1; i <= 50; i++ ) {
            pdes[i] = ' ';
        }
        // get logpoint
        for ( int i = 1; i <= 2; i++ ) {
            k = strtok2( pdes, temp, l, ',' );
            l = k;
        }
        trim( pdes );
        int logpoint = atoi( pdes );

        l = 0;
        k = 0;
        for ( int i = 1; i <= 3; i++ ) {
            k = strtok2( pdes, temp, l, ',' );
            l = k;
        }
        trim( pdes );
        int operation = atoi( pdes );

        l = 0;
        k = 0;

        // get the 6th element of the line, which contains the device info
        for ( int n = 1; n <= 3; n++ ) {
            k = strtok2( pdes, temp, l, ',' );
            l = strtok2( pdes, temp, k, ',' );
        }
        trim( pdes );
        int dev = -1;

        for ( int id = 1; id <= ( int ) DEV.size( ); id++ ) { // get the device id in DEV vector
            if ( !strcmp( DEV[id - 1], pdes ) ) {
                dev = id;
                break;
            }
        }
        if ( dev < 0 ) {
            cout << "device " << pdes << " cannot be found in vector DEV" << endl;
        }
        if ( strlen( pdes ) >= 1 ) { // this is a new line of the route table
            struct tooling_configure one_tc;

            count++;
            k = strtok2( pdes, temp, l, ',' ); // get the package
            l = k;
            trim( pdes );
            one_tc.package = pdes;
            k = strtok2( pdes, temp, l, ',' ); // skip the pin
            l = k;
            trim( pdes );
            one_tc.logpoint = logpoint;
            one_tc.operation = operation;
            one_tc.device = dev; // it is possible that dev=-1 since the device in route.csv is not in wip.csv
            one_tc.id = count;
            k = strtok2( pdes, temp, l, ',' ); // get alternative
            trim( pdes );
            if ( strlen( pdes ) > 0 ) {
                eps[one_tc.id] = (min_weight - 0.1) / 2.0;
            } // this is an alternative route; o.w. eps=0;
            l = strtok2( pdes, temp, k, ',' ); // skip setup description
            k = strtok2( pdes, temp, l, ',' ); // get PPH
            trim( pdes );
            rate[one_tc.id] = ( double ) atof( pdes ); // NOTE:when clean S data the rate[] should be updated accordingly
            l = strtok2( pdes, temp, k, ',' ); // get machine family
            trim( pdes );
            int mg = -1;

            for ( int id = 1; id <= ( int ) MF.size( ); id++ ) { // get the machine family id in the MF vector
                if ( !strcmp( MF[id - 1], pdes ) ) {
                    mg = id;
                    break;
                }
            }
            one_tc.mg = mg; // it is possible that mg=-1
            k = strtok2( pdes, temp, l, ',' ); // get tooling family
            trim( pdes );

            // add the following statement such that pdes will never to empty
            // the empty field in the line is replaced by "No_Tooling"
            if ( strlen( pdes ) < 1 ) {
                strcpy( pdes, "No_Tooling" );
            }
            if ( strlen( pdes ) >= 1 ) { // non-empty
                int tf = -1;

                for ( int id = 1; id <= ( int ) TF.size( ); id++ ) { // get the tooling family id in the TF vector
                    if ( !strcmp( TF[id - 1], pdes ) ) {
                        tf = id;
                        break;
                    }
                }
                if ( tf > 0 ) { // with tooling requirement
                    eps[one_tc.id] += (min_weight - 0.1) / 4.0;
                }
                one_tc.tf.tools.push_back( tf );
                if ( tf > 0 ) {
                    l = strtok2( pdes, temp, k, ',' ); // get the number of tooling piece
                    trim( pdes );
                    int pos = one_tc.id * Max_Num_Tooling_Family + tf; // if tf=-1, then the pos will not be right

                    // a_st[one_tc.id][tf]=atoi(pdes);// !!NOTE:when clean S data a_st[][] need to be updated accordingly
                    a_st[pos] = atoi( pdes );
                } else {
                    l = strtok2( pdes, temp, k, ',' ); // skip the number of tooling piece
                }
                k = strtok2( pdes, temp, l, ',' ); // get certification
                trim( pdes );
                one_tc.temperature = atoi( pdes );
                S.push_back( one_tc );
            } else { // empty
                int tf = 0; // no tooling requirement

                one_tc.tf.tools.push_back( tf );
                l = strtok2( pdes, temp, k, ',' );
                trim( pdes );
                int pos = one_tc.id * Max_Num_Tooling_Family + tf;


                // a_st[one_tc.id][tf]=atoi(pdes);// !!NOTE:when clean S data ast[][] need to be updated accordingly
                a_st[pos] = atoi( pdes );
                k = strtok2( pdes, temp, l, ',' );
                trim( pdes );
                one_tc.temperature = atoi( pdes );
                S.push_back( one_tc );
            }
        } else { // need to append tooling families and pieces
            for ( int m = 1; m <= 3; m++ ) {
                k = strtok2( pdes, temp, l, ',' );
                l = strtok2( pdes, temp, k, ',' );
            }
            k = strtok2( pdes, temp, l, ',' ); // get additional tooling family
            trim( pdes );

            // now there should be non-empty tf, since this is an additional line for tooling info
            int tf = -1;

            for ( int id = 1; id <= ( int ) TF.size( ); id++ ) {
                if ( !strcmp( TF[id - 1], pdes ) ) {
                    tf = id;
                    break;
                }
            }

            // it is possible that tf=-1;
            vector < tooling_configure >::iterator p_TC = S.end( ) - 1;
            (*p_TC).tf.tools.push_back( tf );
            if ( tf > 0 ) {
                l = strtok2( pdes, temp, k, ',' ); // get number of pieces
                trim( pdes );
                int id = (*p_TC).id;
                int pos = id * Max_Num_Tooling_Family + tf; // if tf=-1, then the pos will not be right

                // a_st[id][tf]=atoi(pdes);// !!Note: when clean S data a_st[][] need to be updated
                a_st[pos] = atoi( pdes );
            }
        }
        f_route.getline( temp, 1000, '\n' );
        trim( temp );
    }
    f_route.close( );
    ofstream gao_fout( "Debug/debug_eps_1.txt" );
    gao_fout << "show eps[] --------------------------" << endl;
    gao_fout << "size of eps[]=" << sizeof (eps) << endl;
    gao_fout << " = " << sizeof (eps) / sizeof (eps[0]) << endl;
    vector < tooling_configure >::iterator p_S_1 = S.begin( );
    while ( p_S_1 != S.end( ) ) {
        int s = (*p_S_1).id;

        gao_fout << "s=" << s << ",eps=" << eps[s] << endl;
        p_S_1++;
    }
    gao_fout.close( );

    // end

    // ---------------------------------------------------------------------------------------The following part is used to clean <S>,rate[] and a_st[][]
    // still need to clean the S data,rate[] and a_st[][]
    // since it is possible that some device,machine family,tooling family are -1
    vector < int >route_to_remove; // this vector stores the routes to remove
    vector < int >reason_to_remove; // this vector stores the reason why the routes are remvoed 1->negative device; 2->negative mg; 3->negative temperature; 4->negative tf
    vector < pair < int, int > > old_new;

    for ( int id = 1; id <= ( int ) S.size( ); id++ ) {
        old_new.push_back( make_pair( id, id ) );
    }
    for ( int id = 1; id <= ( int ) S.size( ); id++ ) {
        bool remove_flag = false;
        int reason = 0;

        if ( S[id - 1].device < 1 ) {
            reason = 1;
            remove_flag = true;
        }
        if ( S[id - 1].mg < 1 ) {
            reason = 2;
            remove_flag = true;
        }
        if ( S[id - 1].temperature < 1 ) {
            reason = 3;
            remove_flag = true;
        }
        for ( int id2 = 1; id2 <= ( int ) S[id - 1].tf.tools.size( ); id2++ ) {
            int tf = S[id - 1].tf.tools[id2 - 1];

            if ( tf < 1 ) {
                reason = 4;
                remove_flag = true;
                break;
            }
        }
        if ( remove_flag ) { // need to remove the route
            route_to_remove.push_back( id );
            reason_to_remove.push_back( reason );
        }
    }
    cout << "route_to_remove" << endl;
    for ( int id = 1; id <= ( int ) route_to_remove.size( ); id++ ) {
        cout << route_to_remove[id - 1] << ",Reason code=" << reason_to_remove[id - 1] << ":";
        switch ( reason_to_remove[id - 1] ) {
            case 1:
                cout << "negative device" << endl;
                break;
            case 2:
                cout << "netagive machine family" << endl;
                break;
            case 3:
                cout << "negative temperature" << endl;
                break;
            case 4:
                cout << "negative tooling family" << endl;
                break;
            default:
                cout << "Wrong reason to remove the route,need to check this part" << endl;
                abort( );
        }
    }
    for ( int id = 1; id <= ( int ) S.size( ); id++ ) { // update old_new
        vii pfind = find( route_to_remove.begin( ), route_to_remove.end( ), id );

        if ( pfind != route_to_remove.end( ) ) { // route id is going to be removed
            old_new[id - 1].second = -1;
            for ( int id2 = id + 1; id2 <= ( int ) old_new.size( ); id2++ ) {
                old_new[id2 - 1].second = old_new[id2 - 1].second - 1;
            }
        }
    }
    // update eps[]
    double *eps_save = new double[Max_Num_Tooling_Configure];

    for ( int id = 1; id <= Max_Num_Tooling_Configure; id++ ) {
        eps_save[id - 1] = eps[id - 1];
    }
    // update a_st[][] and rate[]
    // save a copy of a_st[][] and rate[]
    // int a_st_save[Max_Num_Tooling_Configure][Max_Num_Tooling_Family];
    int *a_st_save = new int[Max_Num_Tooling_Configure * Max_Num_Tooling_Family];


    // double rate_save[Max_Num_Tooling_Configure];
    int *rate_save = new int[Max_Num_Tooling_Configure];

    for ( int id = 1; id <= Max_Num_Tooling_Configure; id++ ) {
        rate_save[id - 1] = rate[id - 1];
    }
    for ( int id = 1; id <= Max_Num_Tooling_Configure; id++ ) {
        for ( int id2 = 1; id2 <= Max_Num_Tooling_Family; id2++ ) {
            int pos = (id - 1) * Max_Num_Tooling_Family + id2 - 1;


            // a_st_save[id-1][id2-1]=a_st[id-1][id2-1];
            a_st_save[pos] = a_st[pos];
        }
    }

    for ( int id = 1; id <= ( int ) old_new.size( ); id++ ) {
        int old_id = old_new[id - 1].first;
        int new_id = old_new[id - 1].second;

        if ( old_id != new_id && new_id > 0 ) {
            rate[new_id] = rate_save[old_id];
            rate[old_id] = 0;
            eps[new_id] = eps_save[old_id];
            eps[old_id] = 0;

            for ( int id2 = 0; id2 <= Max_Num_Tooling_Family - 1; id2++ ) {

                a_st[new_id * Max_Num_Tooling_Family + id2] = a_st_save[old_id * Max_Num_Tooling_Family + id2];

                a_st[old_id * Max_Num_Tooling_Family + id2] = 0;
            }
        }
    }

    delete[]a_st_save;
    delete[]rate_save;
    delete[]eps_save;

    // remove the routes
    vector < tooling_configure >::iterator p_S = S.begin( );
    while ( p_S != S.end( ) ) {
        bool remove_flag = false;
        if ( (*p_S).device < 1 || (*p_S).mg < 1 || (*p_S).temperature < 1 ) {
            remove_flag = true;
        }
        for ( int id2 = 1; id2 <= ( int ) (*p_S).tf.tools.size( ); id2++ ) {
            int tf = (*p_S).tf.tools[id2 - 1];

            if ( tf < 1 ) {
                remove_flag = true;
                break;
            }
        }
        if ( remove_flag ) { // need to remove the route
            p_S = S.erase( p_S );
        }
        if ( !remove_flag ) {
            p_S++;
        }
    }
    for ( int id = 1; id <= ( int ) S.size( ); id++ ) {
        S[id - 1].id = id;
    }
    // --------
    show_S( );
    gao_fout.open( "Debug/debug_eps_2.txt" );
    gao_fout << "show eps[] --------------------------" << endl;
    gao_fout << "size of eps[]=" << sizeof (eps) << endl;
    gao_fout << " = " << sizeof (eps) / sizeof (eps[0]) << endl;
    vector < tooling_configure >::iterator p_S_2 = S.begin( );
    while ( p_S_2 != S.end( ) ) {
        int s = (*p_S_2).id;

        gao_fout << "s=" << s << ",eps=" << eps[s] << endl;
        p_S_2++;
    }
    gao_fout.close( );

    // end

    // -----------------------------------------------------------------------------
    // set up machine_mg[] and Machine_Groups
    vector < Machine >::iterator p_M = Machine_vector.begin( );
    while ( p_M != Machine_vector.end( ) ) {
        machine_mg[(*p_M).id] = (*p_M).mg;
        p_M++;
    }
    for ( int n = 1; n <= Num_Machine_Group; n++ ) {
        struct machine_set m_set;

        for ( int m = 1; m <= Num_Machine; m++ ) {
            if ( machine_mg[m] == n ) {
                m_set.machines.push_back( m );
            }
        }
        Machine_Groups.push_back( m_set );
    }
    show_mg( );

    // set up tooling_tf[] and Tooling_Families
    vector < Tooling >::iterator p_T = Tooling_vector.begin( );
    while ( p_T != Tooling_vector.end( ) ) {
        tooling_tf[(*p_T).id] = (*p_T).tf;
        p_T++;
    }
    for ( int tf = 1; tf <= Num_Tooling_Family; tf++ ) {
        struct tooling_set t_set;

        for ( int t = 1; t <= Num_Tooling; t++ ) {
            if ( tooling_tf[t] == tf ) {
                t_set.tools.push_back( t );
            }
        }
        Tooling_Families.push_back( t_set );
    }
    show_tf( );

    // ------------------------------------------------------------------------------create the temperature combination
    cout << "initialize Temperature_Set" << endl;
    temp_combination( );
    show_temp_comb( Temperature_Set );

    // ------------------------------------------------------------------------------get n_t_n_tooling[][]
    cout << "get n_t_n_tooling[][]" << endl;
    cout << "Num_Tooling_Family=" << Num_Tooling_Family << ",Temperature_Set.size()=" << ( int ) Temperature_Set.size( ) << endl;
    for ( int tf = 1; tf <= Num_Tooling_Family; tf++ ) {
        for ( int id = 1; id <= ( int ) Temperature_Set.size( ); id++ ) {
            int pos = tf * Max_Num_Temperature + id;


            // n_t_n_tooling[tf][id]=0;
            n_t_n_tooling[pos] = 0;
            for ( int id2 = 1; id2 <= ( int ) Tooling_vector.size( ); id2++ ) {

                if ( Tooling_vector[id2 - 1].tf == tf && compare_int_vec( Tooling_vector[id2 - 1].temperature_vector, Temperature_Set[id - 1].set_elements ) ) {
                    // n_t_n_tooling[tf][id]++;
                    n_t_n_tooling[pos]++;
                }
            }
        }
    }

    // ------------------------------------------------------------------------------
    // read the toolingfamily_temperature.csv for n_t_n_tooling[][]
    ofstream f_n_t_n( "Debug/debug_n_t_n_tooling.txt" );
    for ( int tf = 1; tf <= Num_Tooling_Family; tf++ ) {
        for ( int id = 1; id <= ( int ) Temperature_Set.size( ); id++ ) {
            int pos = tf * Max_Num_Temperature + id;

            f_n_t_n << "tf=" << tf << ",id=" << id << ",n_t_n_tooling[tf][id]=" << n_t_n_tooling[pos] << endl;
        }
    }
    f_n_t_n.close( );

    // ----------------------------------------------------------
    // initialize H[]
    for ( int i = 1; i <= Num_Machine; i++ ) {
        H[i] = 0.0;
    } // if a machine i is in machine.csv but not in machine_hours.csv, then set its machine time to zero
    // read the machine_hours.csv
    ifstream f_mach_hr( "Data/machine_hours.csv" );
    f_mach_hr.getline( temp, 1000, '\n' );
    f_mach_hr.getline( temp, 1000, '\n' );
    row_no = 2;
    trim( temp );
    while ( !f_mach_hr.eof( ) && strlen( temp ) > 0 ) {
        int k = 0, l = 0;

        k = strtok2( pdes, temp, l, ',' );
        trim( pdes );
        int mach = 0;

        for ( int id = 1; id <= ( int ) MI.size( ); id++ ) {
            if ( !strcmp( MI[id - 1], pdes ) ) {
                mach = id;
                break;
            }
        }
        if ( mach < 1 ) {
            cout << "machine instance " << pdes << " is not included in machines.csv, discard it" << endl;
            f_log << "The " << row_no << "th row in machine_hours.csv: machine instance " << pdes << " is not included in machines.csv. The row is skipped." << endl;
            row_no++;
            f_mach_hr.getline( temp, 1000, '\n' );
            continue;
        }
        l = strtok2( pdes, temp, k, ',' );
        trim( pdes );
        H[mach] = ( double ) atof( pdes );
        f_mach_hr.getline( temp, 1000, '\n' );
        row_no++;
        trim( temp );
    }
    f_mach_hr.close( );
    show_targets( );
    show_statistics( );

    // --------------------------------------------------------
}


/**
 * @brief 
 */
void
AT::initialize_S_i( )
{
    // initialize the data structure S_i
    for ( int i = 1; i <= Num_Machine; i++ ) {
        int mg = machine_mg[i];

        vector < Machine >::iterator p_M = Machine_vector.begin( ) + i - 1;
        vector < int >::iterator p_int = (*p_M).temperature_vector.begin( );

        vector < tooling_configure >::iterator p_S = S.begin( );
        while ( p_S != S.end( ) ) {
            p_int = find( (*p_M).temperature_vector.begin( ), (*p_M).temperature_vector.end( ), (*p_S).temperature );
            if ( (*p_S).mg == mg && p_int != (*p_M).temperature_vector.end( ) ) {
                struct tooling_configure one_tc;

                one_tc.mg = (*p_S).mg;
                one_tc.device = (*p_S).device;
                one_tc.id = (*p_S).id;
                one_tc.temperature = (*p_S).temperature;
                one_tc.package = (*p_S).package;
                one_tc.tf.tools.resize( ( int ) (*p_S).tf.tools.size( ) );
                copy( (*p_S).tf.tools.begin( ), (*p_S).tf.tools.end( ), one_tc.tf.tools.begin( ) );
                S_i[i].tc_vector.push_back( one_tc );
            }
            p_S++;
        }
    }
}


/**
 * @brief 
 */
void
AT::show_S_i( )
{
    // output the data structure S_i
    ofstream fout( "Debug/debug_S_i.txt" );
    fout << "show S_i ------------------------------------" << endl;
    for ( int i = 1; i <= Num_Machine; i++ ) {
        fout << "i=" << i << ",";
        vector < tooling_configure >::iterator p_S = S_i[i].tc_vector.begin( );
        while ( p_S != S_i[i].tc_vector.end( ) ) {
            fout << "id=" << (*p_S).id << ",device=" << (*p_S).device << ",mg=" << (*p_S).mg << ",temperature=" << (*p_S).temperature << ",package=" << (*p_S).package << ",tf:";
            vii p_int = (*p_S).tf.tools.begin( );
            while ( p_int != (*p_S).tf.tools.end( ) ) {
                fout << (*p_int) << ",";
                p_int++;
            }
            p_S++;
        }
        fout << endl;
    }
    fout.close( );
}


/**
 * @brief 
 * 
 * @param TS
 * @param i
 */
void
AT::get_S( vector < tooling_configure > &TS, int i )
{
    // get the routes that can use machine i
    int mg = machine_mg[i];

    vector < Machine >::iterator p_M = Machine_vector.begin( ) + i - 1;
    vector < int >::iterator p_int = (*p_M).temperature_vector.begin( );

    vector < tooling_configure >::iterator p_S = S.begin( );
    while ( p_S != S.end( ) ) {
        p_int = find( (*p_M).temperature_vector.begin( ), (*p_M).temperature_vector.end( ), (*p_S).temperature );
        if ( (*p_S).mg == mg && p_int != (*p_M).temperature_vector.end( ) ) {
            struct tooling_configure one_tc;

            one_tc.mg = (*p_S).mg;
            one_tc.device = (*p_S).device;
            one_tc.id = (*p_S).id;
            one_tc.temperature = (*p_S).temperature;
            one_tc.package = (*p_S).package;
            one_tc.tf.tools.resize( ( int ) (*p_S).tf.tools.size( ) );
            copy( (*p_S).tf.tools.begin( ), (*p_S).tf.tools.end( ), one_tc.tf.tools.begin( ) );
            one_tc.logpoint = (*p_S).logpoint;
            one_tc.operation = (*p_S).operation;
            TS.push_back( one_tc );
        }
        p_S++;
    }
}


/**
 * @brief get the routes that can use machine i to process lot l
 * 
 * @param TS
 * @param i
 * @param l
 */
void
AT::get_S( vector < tooling_configure > &TS, int i, int l )
{
    // get the routes that can use machine i to process lot l
    // ----------------------------------
    int mg = machine_mg[i];

    vector < Machine >::iterator p_M = Machine_vector.begin( ) + i - 1;
    vector < tooling_configure >::iterator p_S = S.begin( );
    int dev = lots_device[l];
    int logpoint = lot_logpoint[l];
    int operation = lot_operation[l];

    while ( p_S != S.end( ) ) {
        vii p_int = find( (*p_M).temperature_vector.begin( ), (*p_M).temperature_vector.end( ), (*p_S).temperature );
        if ( (*p_S).mg == mg && p_int != (*p_M).temperature_vector.end( ) &&(*p_S).device == dev && (*p_S).logpoint == logpoint && (*p_S).operation == operation ) {
            struct tooling_configure one_tc;

            one_tc.mg = (*p_S).mg;
            one_tc.device = (*p_S).device;
            one_tc.id = (*p_S).id;
            one_tc.temperature = (*p_S).temperature;
            one_tc.package = (*p_S).package;
            one_tc.logpoint = logpoint;
            one_tc.operation = operation;
            one_tc.tf.tools.resize( ( int ) (*p_S).tf.tools.size( ) );
            copy( (*p_S).tf.tools.begin( ), (*p_S).tf.tools.end( ), one_tc.tf.tools.begin( ) );
            TS.push_back( one_tc );
        }
        p_S++;
    }
}


/**
 * @brief get the routes that can use machine i to process lot l with tooling family tf
 * 
 * @param TS
 * @param i
 * @param l
 * @param tf
 */
void
AT::get_S( vector < tooling_configure > &TS, int i, int l, int tf )
{
    // get the routes that can use machine i to process lot l with tooling family tf
    get_S( TS, i, l );
    vector < tooling_configure >::iterator p_TS = TS.begin( );
    while ( p_TS != TS.end( ) ) {
        vector < int >::iterator p_int = find( (*p_TS).tf.tools.begin( ), (*p_TS).tf.tools.end( ), tf );

        if ( p_int == (*p_TS).tf.tools.end( ) ) {
            vector < tooling_configure >::iterator p_erase = p_TS;
            p_TS = TS.erase( p_erase );
        } else {
            p_TS++;
        }
    }
}


/**
 * @brief get the routes that can process lot l
 * 
 * @param TS
 * @param l
 */
void
AT::get_S_l( vector < tooling_configure > &TS, int l )
{
    // get the routes that can process lot l
    int dev = lots_device[l];
    int logpoint = lot_logpoint[l];
    int operation = lot_operation[l];

    vector < tooling_configure >::iterator p_S = S.begin( );
    while ( p_S != S.end( ) ) {
        if ( (*p_S).device == dev && (*p_S).logpoint == logpoint && (*p_S).operation == operation ) {
            struct tooling_configure one_tc;

            one_tc.mg = (*p_S).mg;
            one_tc.device = (*p_S).device;
            one_tc.id = (*p_S).id;
            one_tc.temperature = (*p_S).temperature;
            one_tc.package = (*p_S).package;
            one_tc.logpoint = logpoint;
            one_tc.operation = operation;
            one_tc.tf.tools.resize( ( int ) (*p_S).tf.tools.size( ) );
            copy( (*p_S).tf.tools.begin( ), (*p_S).tf.tools.end( ), one_tc.tf.tools.begin( ) );
            TS.push_back( one_tc );
        }
        p_S++;
    }
}


/**
 * @brief get the routes that can use machine i to process lot l with setup Lambda_id
 * 
 * @param TS
 * @param i
 * @param l
 * @param Lambda_id
 */
void
AT::get_S_i_l_Lambda( vector < tooling_configure > &TS, int i, int l, int Lambda_id )
{
    // get the routes that can use machine i to process lot l with setup Lambda_id
    vector < tooling_configure > TS2;
    get_S( TS2, i, l );
    vector < tooling_configure >::iterator p_TS2 = TS2.begin( );
    vector < int >a;

    while ( p_TS2 != TS2.end( ) ) {
        a.clear( );
        int s = (*p_TS2).id;

        vii pt = (*p_TS2).tf.tools.begin( );
        while ( pt != (*p_TS2).tf.tools.end( ) ) {
            int tf = (*pt);
            int pos = s * Max_Num_Tooling_Family + tf;

            a.push_back( a_st[pos] );
            pt++;
        }
        int La_id = get_Lambda_id( (*p_TS2).tf.tools, a, (*p_TS2).temperature, (*p_TS2).package );

        if ( La_id == Lambda_id ) {
            struct tooling_configure one_tc;

            one_tc.mg = (*p_TS2).mg;
            one_tc.device = (*p_TS2).device;
            one_tc.package = (*p_TS2).package;
            one_tc.id = (*p_TS2).id;
            one_tc.temperature = (*p_TS2).temperature;
            one_tc.package = (*p_TS2).package;
            one_tc.tf.tools.resize( ( int ) (*p_TS2).tf.tools.size( ) );
            copy( (*p_TS2).tf.tools.begin( ), (*p_TS2).tf.tools.end( ), one_tc.tf.tools.begin( ) );
            one_tc.logpoint = (*p_TS2).logpoint;
            one_tc.operation = (*p_TS2).operation;
            TS.push_back( one_tc );
        }
        p_TS2++;
    }
}


/**
 * @brief get all the tooling setups
 * 
 * a Lambda_item is a combination of toolings,number of pieces,and temperature
 */
void
AT::get_Lambda( )
{
    // a Lambda_item is a combination of toolings,number of pieces,and temperature
    // get all the tooling setups
    vector < tooling_configure >::iterator p_S = S.begin( );
    int count = 1;

    while ( p_S != S.end( ) ) {
        vector < int >a;
        int s = (*p_S).id;

        vii pt = (*p_S).tf.tools.begin( );
        while ( pt != (*p_S).tf.tools.end( ) ) {
            int tf = (*pt);
            int pos = s * Max_Num_Tooling_Family + tf;

            a.push_back( a_st[pos] );
            pt++;
        }
        vector < Lambda_item >::iterator p_Lambda = Lambda.begin( );
        while ( p_Lambda != Lambda.end( ) ) {
            if ( compare_int_vec( (*p_S).tf.tools, (*p_Lambda).tooling_vec ) && compare_int_vec( a, (*p_Lambda).b ) && (*p_S).temperature == (*p_Lambda).temperature && (*p_S).package == (*p_Lambda).package ) {
                break;
            }
            p_Lambda++;
        }
        if ( p_Lambda == Lambda.end( ) ) {
            struct Lambda_item one_Lambda;

            one_Lambda.id = count;
            count++;
            one_Lambda.tooling_vec.resize( ( int ) (*p_S).tf.tools.size( ) );
            copy( (*p_S).tf.tools.begin( ), (*p_S).tf.tools.end( ), one_Lambda.tooling_vec.begin( ) );
            one_Lambda.b.resize( ( int ) a.size( ) );
            copy( a.begin( ), a.end( ), one_Lambda.b.begin( ) );
            one_Lambda.temperature = (*p_S).temperature;
            one_Lambda.package = (*p_S).package;

            Lambda.push_back( one_Lambda );
        }
        p_S++;
    }
}


/**
 * @brief get all the tooling setups that can use machine i and tooling family tf under operating temperature tau
 *
 * @param L
 * @param i
 * @param tf
 * @param tau
 */
void
AT::get_Lambda( vector < int >&L, int i, int tf, int tau )
{
    // get the tooling setups that can use machine i and tooling family tf under operating temperature tau
    // the results are stored in L

    // get Lambda(i,tf,tau)
    L.resize( ( int ) Lambda_i[i].int_vector.size( ) );
    copy( Lambda_i[i].int_vector.begin( ), Lambda_i[i].int_vector.end( ), L.begin( ) );
    vii p_int = L.begin( );
    while ( p_int != L.end( ) ) {
        vector < Lambda_item >::iterator p_Lambda = Lambda.begin( ) + (*p_int) - 1;
        vii p_find = find( (*p_Lambda).tooling_vec.begin( ), (*p_Lambda).tooling_vec.end( ), tf );
        if ( p_find == (*p_Lambda).tooling_vec.end( ) || tau != (*p_Lambda).temperature ) {
            p_int = L.erase( p_int );
        } else {
            p_int++;
        }
    }
}


/**
 * @brief output the data structure Lambda to a debug file
 */
void
AT::show_Lambda( )
{
    // output the data structure Lambda to a debug file
    ofstream fout( "Debug/debug_Lambda.txt" );
    fout << "show Lambda vector -------------------------------------" << endl;
    vector < Lambda_item >::iterator p_Lambda = Lambda.begin( );
    while ( p_Lambda != Lambda.end( ) ) {
        fout << "id=" << (*p_Lambda).id << ",tooling=";
        vii p_int = (*p_Lambda).tooling_vec.begin( );
        while ( p_int != (*p_Lambda).tooling_vec.end( ) ) {
            int offset = p_int - (*p_Lambda).tooling_vec.begin( );

            vii pb = (*p_Lambda).b.begin( ) + offset;
            fout << (*p_int) << "(" << (*pb) << "),";
            p_int++;
        }
        fout << endl;
        fout << "temperature=" << (*p_Lambda).temperature << endl;
        fout << "package=" << (*p_Lambda).package << endl;
        p_Lambda++;
    }
    fout.close( );
}


/**
 * @brief given the tooling family tf, the associated number of pieces b, temperature, and package
 * 
 * @param tf
 * @param b
 * @param temperature
 * @param package
 * 
 * @return index of the corresponding tooling setup
 */
int
AT::get_Lambda_id( vector < int >&tf, vector < int >&b, int &temperature, string & package )
{
    // given the tooling family tf, the associated number of pieces b and the temperature
    // return the index of the corresponding tooling setup
    vector < Lambda_item >::iterator p_Lambda = Lambda.begin( );
    while ( p_Lambda != Lambda.end( ) ) {
        if ( compare_int_vec( tf, (*p_Lambda).tooling_vec ) && compare_int_vec( b, (*p_Lambda).b ) &&(*p_Lambda).package == package && temperature == (*p_Lambda).temperature ) {
            return (*p_Lambda).id;
        }
        p_Lambda++;
    }

    // could not find the tooling setup in Lambda
    cout << "could not find the tooling setup in Lambda" << endl;
    return 0;
}


/**
 * @brief initialize the data structure Lamuda_i
 */
void
AT::initialize_Lambda_i( )
{
    // initialize the data structure Lamuda_i
    for ( int i = 1; i <= Num_Machine; i++ ) {
        vector < tooling_configure > TS;
        get_S( TS, i );
        vector < tooling_configure >::iterator p_TS = TS.begin( );
        while ( p_TS != TS.end( ) ) {

            // ----------------------------
            vector < int >a;
            int s = (*p_TS).id;

            vii pt = (*p_TS).tf.tools.begin( );
            while ( pt != (*p_TS).tf.tools.end( ) ) {
                int tf = (*pt);
                int pos = s * Max_Num_Tooling_Family + tf;

                a.push_back( a_st[pos] );
                pt++;
            }
            // ----------------------------
            int id = get_Lambda_id( (*p_TS).tf.tools, a, (*p_TS).temperature, (*p_TS).package );

            vii p_find = find( Lambda_i[i].int_vector.begin( ), Lambda_i[i].int_vector.end( ), id );
            if ( p_find == Lambda_i[i].int_vector.end( ) ) {
                Lambda_i[i].int_vector.push_back( id );
            }
            p_TS++;
        }
        vector < int >v( ( int ) Lambda_i[i].int_vector.size( ), 0 );

        vii p_int = Lambda_i[i].int_vector.begin( );
        copy( p_int, p_int + ( int ) Lambda_i[i].int_vector.size( ), v.begin( ) );
        sort( v.begin( ), v.end( ) );
        swap( v, Lambda_i[i].int_vector );
    }
}


/**
 * @brief build M_lambda vector, should be called after initialize_Lambda_i
 */
void
AT::initialize_M_lambda( )
{
    // build M_lambda vector, should be called after initialize_Lambda_i
    vector < Lambda_item >::iterator p_Lambda = Lambda.begin( );
    while ( p_Lambda != Lambda.end( ) ) {
        int id = (*p_Lambda).id;

        for ( int i = 1; i <= Num_Machine; i++ ) {
            vector < int >::iterator p_find = find( Lambda_i[i].int_vector.begin( ), Lambda_i[i].int_vector.end( ), id );

            if ( p_find != Lambda_i[i].int_vector.end( ) ) {
                M_lambda[id].int_vector.push_back( i );
            }
        }
        p_Lambda++;
    }
}


/**
 * @brief output the data structure Lambda_i to a debug file
 */
void
AT::show_Lambda_i( )
{
    // output the data structure Lambda_i to a debug file
    ofstream fout( "Debug/debug_Lambda_i.txt" );
    fout << "show Lambda_i ---------------------------------" << endl;
    for ( int i = 1; i <= Num_Machine; i++ ) {
        fout << "i=" << i << ":";
        vii p_int = Lambda_i[i].int_vector.begin( );
        while ( p_int != Lambda_i[i].int_vector.end( ) ) {
            fout << (*p_int) << ",";
            p_int++;
        }
        fout << endl;
    }
    fout.close( );
}


/**
 * @brief initialize the array machine_mg[]
 */
void
AT::get_machine_mg( )
{
    // initialize the array machine_mg[]
    for ( int i = 1; i <= Num_Machine; i++ ) {
        int i_mg = -1;

        vector < machine_set >::iterator pmg = Machine_Groups.begin( );
        while ( pmg != Machine_Groups.end( ) ) {
            vector < int >::iterator pm = (*pmg).machines.begin( );

            while ( pm != (*pmg).machines.end( ) ) {
                if ( (*pm) == i ) { // find the machine
                    i_mg = pmg - Machine_Groups.begin( ) + 1;
                    break;
                }
                pm++;
            }
            if ( i_mg > 0 ) {
                break;
            }
            pmg++;
        }
        machine_mg[i] = i_mg;
    }
}


/**
 * @brief initialize the array tooling_tf[]
 */
void
AT::get_tooling_tf( )
{
    // initialize the array tooling_tf[]
    for ( int t = 1; t <= Num_Tooling; t++ ) {
        int t_tf = -1;

        vector < tooling_set >::iterator ptf = Tooling_Families.begin( );
        while ( ptf != Tooling_Families.end( ) ) {
            vector < int >::iterator pt = find( (*ptf).tools.begin( ), (*ptf).tools.end( ), t );

            if ( pt != (*ptf).tools.end( ) ) {
                t_tf = ptf - Tooling_Families.begin( ) + 1;
                break;
            }
            ptf++;
        }
        tooling_tf[t] = t_tf;
    }
}


/**
 * @brief initialize the data structure M_l
 */
void
AT::initialize_M_l( )
{
    // initialize the data structure M_l
    for ( int l = 1; l <= Num_Lot; l++ ) {
        vector < tooling_configure >::iterator p_S = S.begin( );
        while ( p_S != S.end( ) ) {
            int dev = (*p_S).device;

            vector < device_item >::iterator p_d = Devices.begin( ) + dev - 1;
            vector < int >::iterator p_l = find( (*p_d).device_lots.begin( ), (*p_d).device_lots.end( ), l );
            int logpoint = (*p_S).logpoint;
            int operation = (*p_S).operation;

            if ( lot_logpoint[l] == logpoint && lot_operation[l] == operation ) {
                if ( p_l != (*p_d).device_lots.end( ) ) {
                    int mg = (*p_S).mg;
                    int temp = (*p_S).temperature;

                    vector < machine_set >::iterator p_M = Machine_Groups.begin( ) + mg - 1;
                    vector < int >::iterator p_int = (*p_M).machines.begin( );

                    while ( p_int != (*p_M).machines.end( ) ) {
                        vector < Machine >::iterator p_Machine = Machine_vector.begin( ) + (*p_int) - 1;
                        vector < int >::iterator p_temp = find( (*p_Machine).temperature_vector.begin( ), (*p_Machine).temperature_vector.end( ), temp );

                        if ( p_temp != (*p_Machine).temperature_vector.end( ) ) {
                            int i = (*p_Machine).id;
                            vector < int >::iterator p1 = find( M_l[l].int_vector.begin( ), M_l[l].int_vector.end( ), i );

                            if ( p1 == M_l[l].int_vector.end( ) ) {
                                M_l[l].int_vector.push_back( i );
                            }
                        }
                        p_int++;
                    }
                }
            }
            p_S++;
        }
    }
}


/**
 * @brief output the data structure M_l to a debug file
 */
void
AT::show_M_l( )
{
    // output the data structure M_l to a debug file
    ofstream fout( "Debug/debug_M_l.txt" );
    fout << "show M_l ---------------------------------" << endl;
    for ( int l = 1; l <= Num_Lot; l++ ) {
        fout << "l=" << l << ":";
        vii p_int = M_l[l].int_vector.begin( );
        while ( p_int != M_l[l].int_vector.end( ) ) {
            fout << (*p_int) << ",";
            p_int++;
        }
        fout << endl;
    }
    fout.close( );
}


/**
 * @brief initialize the data structure L_i
 */
void
AT::initialize_L_i( )
{
    // initialize the data structure L_i
    vector < Machine >::iterator p_M = Machine_vector.begin( );
    while ( p_M != Machine_vector.end( ) ) {
        int i = p_M - Machine_vector.begin( ) + 1;

        vector < tooling_configure >::iterator p_S = S.begin( );
        while ( p_S != S.end( ) ) {
            int temp = (*p_S).temperature;
            vector < int >::iterator p_int = find( (*p_M).temperature_vector.begin( ), (*p_M).temperature_vector.end( ), temp );

            if ( (*p_S).mg == machine_mg[i] && p_int != (*p_M).temperature_vector.end( ) ) {
                int device_num = (*p_S).device;

                vector < device_item >::iterator p_d = Devices.begin( ) + device_num - 1;
                vector < int >::iterator p_l = (*p_d).device_lots.begin( );

                while ( p_l != (*p_d).device_lots.end( ) ) {
                    int l = (*p_l);
                    int logpoint = lot_logpoint[l];
                    int operation = lot_operation[l];

                    if ( logpoint == (*p_S).logpoint && operation == (*p_S).operation ) {
                        vii p_int = find( L_i[i].int_vector.begin( ), L_i[i].int_vector.end( ), (*p_l) );
                        if ( p_int == L_i[i].int_vector.end( ) ) {
                            L_i[i].int_vector.push_back( (*p_l) );
                        }
                    }
                    p_l++;
                }
            }
            p_S++;
        }
        p_M++;
    }
}


/**
 * @brief output the data structure L_i to a debug file
 */
void
AT::show_L_i( )
{
    // output the data structure L_i to a debug file
    ofstream fout( "Debug/debug_L_i.txt" );
    fout << "show L_i ------------------------------------" << endl;
    for ( int i = 1; i <= Num_Machine; i++ ) {
        fout << "i=" << i << " processes lots:";
        vii p_int = L_i[i].int_vector.begin( );
        while ( p_int != L_i[i].int_vector.end( ) ) {
            fout << (*p_int) << ",";
            p_int++;
        }
        fout << endl;
    }
    fout.close( );
}


/**
 * @brief initialize the data structure L_i_d
 */
void
AT::initialize_L_i_d( )
{
    // initialize the data structure L_i_d
    for ( int i = 1; i <= Num_Machine; i++ ) {
        for ( int d = 1; d <= Num_Device; d++ ) {
            vector < device_item >::iterator p_D = Devices.begin( ) + d - 1;
            vii p_lot = (*p_D).device_lots.begin( );
            while ( p_lot != (*p_D).device_lots.end( ) ) {
                vii p_int = find( L_i[i].int_vector.begin( ), L_i[i].int_vector.end( ), (*p_lot) );
                if ( p_int != L_i[i].int_vector.end( ) ) {
                    int pos = i * Max_Num_Device + d;


                    // L_i_d[i][d].int_vector.push_back(*p_lot);
                    L_i_d[pos].int_vector.push_back( *p_lot );
                }
                p_lot++;
            }
        }
    }
}


/**
 * @brief output the data structure L_i_d to a debug file
 */
void
AT::show_L_i_d( )
{
    // output the data structure L_i_d to a debug file
    ofstream fout( "Debug/debug_L_i_d.txt" );
    fout << "show L_i_d ----------------------------------------" << endl;
    for ( int i = 1; i <= Num_Machine; i++ ) {
        for ( int d = 1; d <= Num_Device; d++ ) {
            fout << "i=" << i << ",d=" << d << ":";
            int pos = i * Max_Num_Device + d;

            vii p_int = L_i_d[pos].int_vector.begin( );
            while ( p_int != L_i_d[pos].int_vector.end( ) ) {
                fout << (*p_int) << ",";
                p_int++;
            }
            fout << endl;
        }
    }
    fout.close( );
}


/**
 * @brief get the lots that can be processed by machine i. The results are stored in LS
 * 
 * @param LS
 * @param i
 */
void
AT::get_L( vector < int >&LS, int i )
{
    // get the lots that can be processed by machine i. The results are stored in LS
    vector < Machine >::iterator p_M = Machine_vector.begin( ) + i - 1;
    vector < tooling_configure >::iterator p_S = S.begin( );
    while ( p_S != S.end( ) ) {
        int temp = (*p_S).temperature;
        vector < int >::iterator p_int = find( (*p_M).temperature_vector.begin( ), (*p_M).temperature_vector.end( ), temp );

        if ( (*p_S).mg == machine_mg[i] && p_int != (*p_M).temperature_vector.end( ) ) {
            int device_num = (*p_S).device;

            vector < device_item >::iterator p_d = Devices.begin( ) + device_num - 1;
            vector < int >::iterator p_l = (*p_d).device_lots.begin( );

            while ( p_l != (*p_d).device_lots.end( ) ) {
                int l = (*p_l);
                int logpoint = lot_logpoint[l];
                int operation = lot_operation[l];

                if ( logpoint == (*p_S).logpoint && operation == (*p_S).operation ) {
                    vii p_int = find( LS.begin( ), LS.end( ), (*p_l) );
                    if ( p_int == LS.end( ) ) {
                        LS.push_back( (*p_l) );
                    }
                }
                p_l++;
            }
        }
        p_S++;
    }
}


/**
 * @brief get the lots that can be processed by machine i and contains the device. The results are stored in LS
 * 
 * @param LS
 * @param i
 * @param device
 */
void
AT::get_L( vector < int >&LS, int i, int device )
{
    // get the lots that can be processed by machine i and contains the device
    // the results are stored in LS
    get_L( LS, i );
    vector < int >::iterator p_LS = LS.begin( );

    while ( p_LS != LS.end( ) ) {
        int lot = (*p_LS);
        int dev = lots_device[lot];

        if ( dev != device ) {
            p_LS = LS.erase( p_LS );
        } else {
            p_LS++;
        }
    }
}


/**
 * @brief get the lots that can be processed by machine i with setup lambda_id. The results are stored in LS
 * 
 * @param LS
 * @param i
 * @param lambda_id
 */
void
AT::get_L_i_lambda( vector < int >&LS, int i, int lambda_id )
{
    // get the lots that can be processed by machine i with setup lambda_id. The results are stored in LS
    LS.clear( );
    vii p_l = L_i[i].int_vector.begin( );
    while ( p_l != L_i[i].int_vector.end( ) ) {
        int l = (*p_l);

        vector < tooling_configure > TS;
        get_S_i_l_Lambda( TS, i, l, lambda_id );

        if ( ( int ) TS.size( ) > 0 ) {
            LS.push_back( l );
        }
        p_l++;
    }
}


/**
 * @brief output the data structure Machine_Group to a debug file
 */
void
AT::show_mg( )
{
    // output the data structure Machine_Group to a debug file
    ofstream fout( "Debug/debug_mg.txt" );
    fout << "show machine groups ---------------------" << endl;
    vector < machine_set >::iterator pmg = Machine_Groups.begin( );
    while ( pmg != Machine_Groups.end( ) ) {
        vector < int >::iterator pm = (*pmg).machines.begin( );

        while ( pm != (*pmg).machines.end( ) ) {
            fout << (*pm) << ",";
            pm++;
        }
        fout << endl;
        pmg++;
    }
    fout.close( );
}


/**
 * @brief output the data structure Tooling_Families to a debug file
 */
void
AT::show_tf( )
{
    // output the data structure Tooling_Families to a debug file
    ofstream fout( "Debug/debug_tf.txt" );
    fout << "show tooling families ------------------" << endl;
    vector < tooling_set >::iterator ptf = Tooling_Families.begin( );
    while ( ptf != Tooling_Families.end( ) ) {
        vector < int >::iterator pt = (*ptf).tools.begin( );

        while ( pt != (*ptf).tools.end( ) ) {
            fout << (*pt) << ",";
            pt++;
        }
        fout << endl;
        ptf++;
    }
    fout.close( );
}


/**
 * @brief output the data structure S to a debug file
 */
void
AT::show_S( )
{
    // output the data structure S to a debug file
    ofstream fout( "Debug/debug_S.txt" );
    fout << "show tooling configurations (S)-------------" << endl;
    vector < tooling_configure >::iterator p_S = S.begin( );
    while ( p_S != S.end( ) ) {
        fout << "====" << endl;
        fout << "Tooling configuration ID = " << (*p_S).id << endl;
        fout << "Logpoint      = " << (*p_S).logpoint << endl;
        fout << "operation     = " << (*p_S).operation << endl;
        fout << "Device        = " << (*p_S).device << endl;
        fout << "Machine Group = " << (*p_S).mg << endl;
        fout << "Temperature   = " << (*p_S).temperature << endl;
        fout << "Package       = " << (*p_S).package << endl;
        fout << "Tool Family   = ";
        vector < int >::iterator pt = (*p_S).tf.tools.begin( );

        while ( pt != (*p_S).tf.tools.end( ) ) {
            fout << (*pt) << ", ";
            pt++;
        }
        fout << endl;
        p_S++;
    }
    fout.close( );
}


/**
 * @brief output the data structure Devices to a debug file
 */
void
AT::show_Devices( )
{
    // output the data structure Devices to a debug file
    ofstream fout( "Debug/debug_Devices.txt" );
    fout << "show devices ----------------------------------" << endl;
    vector < device_item >::iterator p_d = Devices.begin( );
    while ( p_d != Devices.end( ) ) {
        fout << "Device " << (*p_d).device << " consists Lots ";
        vector < int >::iterator p_lot = (*p_d).device_lots.begin( );

        while ( p_lot != (*p_d).device_lots.end( ) ) {
            fout << (*p_lot) << ",";
            p_lot++;
        }
        fout << endl;
        p_d++;
    }
    fout.close( );
}


/**
 * @brief output the data structure index_vector to a debug file
 */
void
AT::show_index_vector( )
{
    // output the data structure index_vector to a debug file
    ofstream fout( "Debug/debug_index_vector.txt" );
    fout << "show index_vector -------------------------------" << endl;
    vector < index_node >::iterator p_ind = index_vector.begin( );
    while ( p_ind != index_vector.end( ) ) {
        fout << "index=" << (*p_ind).index << ",i=" << (*p_ind).i << ",l=" << (*p_ind).l << ",s=" << (*p_ind).s << ",Lambda_id=" << (*p_ind).Lambda_id << endl;
        p_ind++;
    }
    fout.close( );
}


/**
 * @brief output the data structure Machine_vector to a debug file
 */
void
AT::show_Machine_vector( )
{
    // output the data structure Machine_vector to a debug file
    ofstream fout( "Debug/debug_Machine_vector.txt" );
    vector < Machine >::iterator p_M = Machine_vector.begin( );
    while ( p_M != Machine_vector.end( ) ) {
        fout << "ID=" << (*p_M).id << endl;
        fout << "Name=" << (*p_M).name << endl;
        fout << "Machine Group=" << (*p_M).mg << endl;
        fout << "Temperature: ";
        vector < int >::iterator p_temp = (*p_M).temperature_vector.begin( );

        while ( p_temp != (*p_M).temperature_vector.end( ) ) {
            fout << (*p_temp) << ",";
            p_temp++;
        }
        fout << endl;
        p_M++;
    }
    fout.close( );
}


/**
 * @brief output the data structure Tooling_vector to a debug file
 */
void
AT::show_Tooling_vector( )
{
    // output the data structure Tooling_vector to a debug file
    ofstream fout( "Debug/debug_Tooling_vector.txt" );
    vector < Tooling >::iterator p_T = Tooling_vector.begin( );
    while ( p_T != Tooling_vector.end( ) ) {
        fout << "ID=" << (*p_T).id << endl;
        fout << "Name=" << (*p_T).name << endl;
        fout << "Tooling Family=" << (*p_T).tf << endl;
        fout << "Temperature: ";
        vector < int >::iterator p_temp = (*p_T).temperature_vector.begin( );

        while ( p_temp != (*p_T).temperature_vector.end( ) ) {
            fout << (*p_temp) << ",";
            p_temp++;
        }
        fout << endl;
        p_T++;
    }
    fout.close( );
}


/**
 * @brief output the temperature combination temp_set to a debug file
 * 
 * @param temp_set
 */
void
AT::show_temp_comb( vector < t_set > &temp_set )
{
    // output the temperature combination temp_set to a debug file
    ofstream fout( "Debug/debug_temp_comb.txt" );
    fout << "Show temperature combinations -----------------" << endl;
    vector < t_set >::iterator p_set = temp_set.begin( );
    while ( p_set != temp_set.end( ) ) {
        vector < int >::iterator p_int = (*p_set).set_elements.begin( );

        while ( p_int != (*p_set).set_elements.end( ) ) {
            fout << (*p_int) << ",";
            p_int++;
        }
        fout << endl;
        p_set++;
    }
    fout.close( );
}


/**
 * @brief output the statistics of the problem
 */
void
AT::show_statistics( )
{
    // output the statistics of the problem to the screen
    cout << "show the problem statistics --------------" << endl;
    cout << "Num_Lot = " << Num_Lot << endl;
    cout << "Num_Initial_lots=" << ( int ) initial_running_lot.size( ) << endl;
    cout << "Num_Device = " << Num_Device << endl;
    cout << "Num_Keydevice = " << Num_Keydevice << endl;
    cout << "Num_Package = " << Num_Package << endl;
    cout << "Num_Temperature = " << Num_Temperature << endl;
    cout << "Num_Machine = " << Num_Machine << endl;
    cout << "Num_Machine_Group = " << Num_Machine_Group << endl;
    cout << "Num_Tooling = " << Num_Tooling << endl;
    cout << "Num_Tooling_Family = " << Num_Tooling_Family << endl;
    cout << "Number of routes = " << ( int ) S.size( ) << endl;
    ofstream fcout( "Output/statistics.txt" );
    fcout << "Num_Lot = " << Num_Lot << endl;
    fcout << "Num_Initial_lots=" << ( int ) initial_running_lot.size( ) << endl;
    fcout << "Num_Device = " << Num_Device << endl;
    fcout << "Num_Keydevice = " << Num_Keydevice << endl;
    fcout << "Num_Package = " << Num_Package << endl;
    fcout << "Num_Temperature = " << Num_Temperature << endl;
    fcout << "Num_Machine = " << Num_Machine << endl;
    fcout << "Num_Machine_Group = " << Num_Machine_Group << endl;
    fcout << "Num_Tooling = " << Num_Tooling << endl;
    fcout << "Num_Tooling_Family = " << Num_Tooling_Family << endl;
    fcout << "Number of routes = " << ( int ) S.size( ) << endl;
    fcout.close( );
}


/**
 * @brief output the data structure device_name to a debug file
 */
void
AT::show_device_name( )
{
    // output the data structure device_name to a debug file
    ofstream fout( "Debug/debug_device_name.txt" );
    fout << "show the device_name ------------------------" << endl;
    vector < ch_array >::iterator p_ch = device_name.begin( );
    while ( p_ch != device_name.end( ) ) {
        fout << "id=" << (*p_ch).id << ",name=" << (*p_ch).char_arry << endl;
        p_ch++;
    }
    fout.close( );
}


/**
 * @brief output the data structure lot_name to a debug file
 */
void
AT::show_lot_name( )
{
    // output the data structure lot_name to a debug file
    ofstream fout( "Debug/debug_lot_name.txt" );
    fout << "show the lot_name --------------------------" << endl;
    vector < ch_array >::iterator p_ch = lot_name.begin( );
    while ( p_ch != lot_name.end( ) ) {
        fout << "id=" << (*p_ch).id << ",name=" << (*p_ch).char_arry << endl;
        p_ch++;
    }
    fout.close( );
}


/**
 * @brief get the index of decision variable x_ils in the list of index_vector
 * 
 * @param i
 * @param l
 * @param s
 * 
 * @return 
 */
int
AT::index_x( int i, int l, int s )
{
    // This function is used to get the index of decision variable x_ils in the list of index_vector
    int index = -1;
    int start_pos = index_vector_flag[i];

    vector < index_node >::iterator p_node = index_vector.begin( ) + start_pos;
    while ( p_node != index_vector.end( ) ) {
        if ( (*p_node).i == i && (*p_node).l == l && (*p_node).s == s ) {
            index = (*p_node).index;
            break;
        }
        p_node++;
    }
    if ( index < 0 ) {
        cout << "WRONG x index!!!, i=" << i << ",l=" << l << ",s=" << s << endl;
    }
    return index;
}


/**
 * @brief get the index of the y_(i,lambda) decision variable in the list of index_vector
 * 
 * @param i
 * @param Lambda_id
 * 
 * @return 
 */
int
AT::index_y( int i, int Lambda_id )
{
    // This function is used to get the index of the y_(i,lambda) decision variable in the list of index_vector
    int index = -1;

    vector < index_node >::iterator p_node = index_vector.begin( ) + x_limit;
    while ( p_node != index_vector.end( ) ) {
        if ( (*p_node).i == i && (*p_node).Lambda_id == Lambda_id ) {
            index = (*p_node).index;
            break;
        }
        p_node++;
    }
    if ( index < 0 ) {
        cout << "WRONG y index!!!" << endl;
    }
    return index;
}


/**
 * @brief build the data structure index_vector
 */
void
AT::build_index_vector( )
{
    // this function is used to build the data structure index_vector
    // this vector is going to be used in function index_x() and index_y
    int counter = 0;

    for ( int i = 1; i <= Num_Machine; i++ ) {
        index_vector_flag[i] = counter; // keep a record of the flags where i starts
        vector < int >L;

        get_L( L, i );
        vector < int >::iterator p_L = L.begin( );

        while ( p_L != L.end( ) ) {
            int l = (*p_L);
            int sim = machine_sim[i];
            int d = lots_device[l];
            int index = index_S_sim_l( sim, l );

            vii p_s = S_sim_l[index].second.int_vector.begin( );
            while ( p_s != S_sim_l[index].second.int_vector.end( ) ) {
                int s = (*p_s);
                struct index_node one_node;

                one_node.i = i;
                one_node.l = l;
                one_node.s = s;
                one_node.Lambda_id = -1;
                one_node.index = counter;
                counter++;
                index_vector.push_back( one_node );
                p_s++;
            }
            p_L++;
        }
    }
    x_limit = counter - 1;
    for ( int k = 1; k <= Num_Keydevice; k++ ) {
        struct index_node one_node;

        one_node.index = counter;
        one_node.i = -1;
        one_node.l = -1;
        one_node.s = -1;
        one_node.Lambda_id = -1;
        counter++;
        index_vector.push_back( one_node );
    }
    for ( int p = 1; p <= Num_Package; p++ ) {
        struct index_node one_node;

        one_node.index = counter;
        one_node.i = -1;
        one_node.l = -1;
        one_node.s = -1;
        one_node.Lambda_id = -1;
        counter++;
        index_vector.push_back( one_node );
    }
    for ( int kp = 1; kp <= ( int ) Key_PKG.size( ); kp++ ) {
        struct index_node one_node;

        one_node.index = counter;
        one_node.i = -1;
        one_node.l = -1;
        one_node.s = -1;
        one_node.Lambda_id = -1;
        counter++;
        index_vector.push_back( one_node );
    }
    for ( int kpp = 1; kpp <= ( int ) Key_PIN_PKG.size( ); kpp++ ) {
        struct index_node one_node;

        one_node.index = counter;
        one_node.i = -1;
        one_node.l = -1;
        one_node.s = -1;
        one_node.Lambda_id = -1;
        counter++;
        index_vector.push_back( one_node );
    }
    for ( int i = 1; i <= Num_Machine; i++ ) {
        vii p_int = Lambda_i[i].int_vector.begin( );
        while ( p_int != Lambda_i[i].int_vector.end( ) ) {
            struct index_node one_node;

            one_node.i = i;
            one_node.index = counter;
            one_node.l = -1;
            one_node.s = -1;
            one_node.Lambda_id = (*p_int);
            index_vector.push_back( one_node );
            counter++;
            p_int++;
        }
    }
    y_limit = counter - 1;
    cout << "counter=" << counter << endl;
    cout << "x_limit=" << x_limit << endl;
    cout << "y_limit=" << y_limit << endl;
}


/**
 * @brief roundup the fractional f to integer
 * 
 * @param f
 * 
 * @return 
 */
int
AT::roundup( double f )
{
    // roundup the fractional f to integer
    if ( is_integer( f ) ) {
        return ( int ) f;
    }
    return ( int ) f + 1;
}


/**
 * @brief test if x is an integer
 * 
 * @param x
 * 
 * @return 
 * @retval 1 if x is an integer
 * @retval 0 if x is not an integer
 */
int
AT::is_integer( double x )
{
    // test if x is an integer, return 1 if it is integer
    int lb = ( int ) x;
    double eps = 1e-06;

    if ( x - lb > eps ) {
        return 0;
    }
    return 1;
}


/**
 * @brief generate temperature combinations
 */
void
AT::temp_combination( )
{
    // this is a function to generate temperature combinations
    vector < int >G;

    for ( int tau = 1; tau <= Num_Temperature; tau++ ) {
        G.push_back( tau );
    }
    vector < int >save;
    vector < int >H;

    for ( int i = 1; i <= Num_Temperature; i++ ) {
        save.push_back( i );
        H.resize( ( int ) save.size( ) );
        copy( save.begin( ), save.end( ), H.begin( ) );

        do {
            struct t_set one_set;

            vii p_int = H.begin( );
            while ( p_int != H.end( ) ) {
                one_set.set_elements.push_back( *p_int );
                p_int++;
            }
            Temperature_Set.push_back( one_set );
        } while ( stdcomb::next_combination( G.begin( ), G.end( ), H.begin( ), H.end( ) ) );
    }
}


/**
 * @brief given the current set, generate the inter sets that overlap the current set
 * 
 * @param current_set
 * @param inter_set
 */
void
AT::get_inter_set( struct t_set current_set, vector < t_set > &inter_set )
{
    // given the current set, generate the inter sets that overlap the current set
    vector < t_set >::iterator p_set = Temperature_Set.begin( );
    while ( p_set != Temperature_Set.end( ) ) {
        vii p_int = current_set.set_elements.begin( );
        while ( p_int != current_set.set_elements.end( ) ) {
            vii p_find = find( (*p_set).set_elements.begin( ), (*p_set).set_elements.end( ), (*p_int) );
            if ( p_find != (*p_set).set_elements.end( ) ) { // interset
                struct t_set one_set = (*p_set);

                inter_set.push_back( one_set );
                break;
            }
            p_int++;
        }
        p_set++;
    }
}


/**
 * @brief given the current set, return the id of the set
 * 
 * @param current_set
 * 
 * @return id of the set
 */
int
AT::get_set_id( struct t_set current_set )
{
    // given the current set, return the id of the set
    int id = 0;

    vector < t_set >::iterator p_set = Temperature_Set.begin( );
    while ( p_set != Temperature_Set.end( ) ) {
        if ( ( int ) (*p_set).set_elements.size( ) == ( int ) current_set.set_elements.size( ) ) {
            int flag = 0;

            vii p_int = current_set.set_elements.begin( );
            while ( p_int != current_set.set_elements.end( ) ) {
                vii p_find = find( (*p_set).set_elements.begin( ), (*p_set).set_elements.end( ), (*p_int) );
                if ( p_find != (*p_set).set_elements.end( ) ) {
                    flag++;
                }
                p_int++;
            }
            if ( flag >= ( int ) current_set.set_elements.size( ) ) {
                id = p_set - Temperature_Set.begin( ) + 1;
                break;
            }
        }
        p_set++;
        if ( id > 0 ) {
            break;
        }
    }
    return id;
}


/**
 * @brief enhanced strtok()
 * 
 * the strtok() provided by C++ could not work for the case ',,,,,,,'
 * find the string starting from start_id until meeting the delim character or meeting the end of the porg
 * 
 * @param pdes
 * @param porg
 * @param start_id
 * @param delim
 * 
 * @return position in the original string after this operation
 */
int
AT::strtok2( char *pdes, char *porg, int start_id, char delim )
{
    // the strtok() provided by C++ could not work for the case ',,,,,,,'
    // find the string starting from start_id until meeting the delim character or meeting the end of the porg

    // return the position in the orginal string after this operation
    // see the test_strtok2()
    int length = strlen( porg );

    if ( start_id >= length ) {
        cout << "length of char[]=" << length << ", start_id=" << start_id << ", wrong start_id!!" << endl;
        pdes[0] = '\0';
        return start_id;
    }
    char ch;

    ch = porg[start_id];
    if ( ch == '\0' || ch == delim || ch == '\r' ) { // if the starting characther is the end or the delim or the return carriage
        pdes[0] = '\0';
        return start_id + 1;
    } else {
        int id = start_id;

        while ( ch != '\0' && ch != delim && ch != '\r' ) {
            pdes[id - start_id] = ch;
            id++;
            ch = porg[id];
        }
        pdes[id - start_id] = '\0';
        return id + 1;
    }
}


/**
 * @brief enhanced strtok()
 * 
 * the strtok() provided by C++ could not work for the case ',,,,,,,'
 * find the string starting from start_id until meeting the delim character or meeting the end of the porg
 * 
 * @param pdes
 * @param porg
 * @param start_id
 * @param delim1
 * @param delim2
 * 
 * @return position in the original string after this operation
 * 
 * @todo add '\\r' support ???
 */
int
AT::strtok2( char *pdes, char *porg, int start_id, char delim1, char delim2 )
{
    // the strtok() provided by C++ could not work for the case ',,,,,,,'
    // find the string starting from start_id until meeting the delim character or meeting the end of the porg
    // return the position in the orginal string after this operation
    // see the test_strtok2()
    char ch;

    ch = porg[start_id];
    if ( ch == '\0' || ch == delim1 || ch == delim2 ) { // if the starting character is the end of the delim
        pdes[0] = '\0';
        return start_id + 1;
    } else {
        int id = start_id;

        while ( ch != '\0' && ch != delim1 && ch != delim2 ) {
            pdes[id - start_id] = ch;
            id++;
            ch = porg[id];
        }
        pdes[id - start_id] = '\0';
        return id + 1;
    }
}


/**
 * @brief trim the spaces both from the head and the tail of the given string ch[]
 * 
 * @param ch
 */
void
AT::trim( char *ch )
{
    // trim the spaces both from the head and the tail of the given string ch[]
    int length = strlen( ch );

    if ( length == 0 )
        return;
    if ( ch[0] != ' ' && ch[length - 1] != ' ' )
        return;
    int i;
    int pfirst = 0, plast = length - 1;

    for ( i = 1; i <= length - 1; i++ ) {
        if ( ch[i - 1] == ' ' && ch[i] != ' ' ) {
            pfirst = i;
            break;
        }
    }
    for ( i = length - 2; i >= 0; i-- ) {
        if ( ch[i + 1] == ' ' && ch[i] != ' ' ) {
            plast = i;
            break;
        }
    }
    char temp[1000];

    for ( i = pfirst; i <= plast; i++ ) {
        temp[i - pfirst] = ch[i];
    }
    for ( i = 0; i <= plast - pfirst; i++ ) {
        ch[i] = temp[i];
    }
    ch[i] = '\0';
}


/**
 * @brief Create the case from input files.  This is an entry function of the GRASP algorithm.
 */
void
AT::create_case_from_files( )
{
    // create the case from input files
    // this is an entry function of the GRASP algorithm
    ofstream f_log( "Output/log_error.txt" );
    f_log
            << "################################################################################################################"
            << endl << "# The file recorded all inconsistent input data."
            << endl
            << "# It pointed out where the incomplete data is, guessed what information may be wrong and what reaction was taken."
            << endl << "##################################################################################################################" << endl << endl;
    f_log.close( );
    readFiles( );
    show_w_l( );
    show_eps( );
    initialize_L_i( );
    show_L_i( );
    initialize_L_i_d( );
    show_L_i_d( );
    initialize_M_l( );
    show_M_l( );
    initialize_S_i( );
    show_S_i( );
    initialize_equivalent_machines( );
    show_equivalent_machines( );
    show_device_name( );
    show_lot_name( );

    // ----------------
    get_Lambda( );
    show_Lambda( );
    initialize_Lambda_i( );
    show_Lambda_i( );
    initialize_M_lambda( );
    process_initial_lot( initial_running_lot, H );
    cout << "get SIM" << endl;
    get_SIM( );
    show_machine_sim( );
    initialize_S_sim_l( );
    show_S_sim_l( );
    cout << "get_tooling_sum_rhs()" << endl;
    get_tooling_sum_rhs( );
    cout << "initialize_L_sim_lambda()" << endl;
    initialize_L_sim_lambda( );
    show_L_sim_lambda( );
    cout << "initialize_sim_lambda_L()" << endl;
    initialize_sim_lambda_L( );
    cout << "initialize_sil()" << endl;
    initialize_sil( );
    cout << "General_Snapshot_time = " << General_Snapshot_time.str << endl;
    show_initial_running_lot( initial_running_lot );
    index_vector.clear( );
    cout << "build_index_vector()" << endl;
    build_index_vector( );
    cout << "initialize_S_sim_l_lambda()" << endl;
    initialize_S_sim_l_lambda( );
    show_S_sim_l_lambda( );
    show_sim_lambda_L( );
    show_sil( );
    get_LPD( );
    get_sum_weight( );
    show_PIN_PKG( );
    show_SIM( );
    show_machine_sim( );
    show_index_vector( );
    first_level_heuristic( );
    cout << "The run has been finished" << endl;
}


/**
 * @brief initialize the data structure equivalent machines
 */
void
AT::initialize_equivalent_machines( )
{
    // initialize the data structure equivalent machines
    for ( int mg = 1; mg <= Num_Machine_Group; mg++ ) {
        for ( int n = 1; n <= ( int ) Temperature_Set.size( ); n++ ) {
            struct equ_mach_set one_equ_mach_set;

            one_equ_mach_set.mg = mg;
            one_equ_mach_set.n = n;
            vector < t_set >::iterator p_set = Temperature_Set.begin( ) + n - 1;
            vector < Machine >::iterator p_M = Machine_vector.begin( );
            while ( p_M != Machine_vector.end( ) ) {
                if ( (*p_M).mg == mg ) {
                    int flag1 = 1;

                    vii p_temp = (*p_M).temperature_vector.begin( );
                    while ( p_temp != (*p_M).temperature_vector.end( ) ) {
                        vii p_find = find( (*p_set).set_elements.begin( ), (*p_set).set_elements.end( ), (*p_temp) );
                        if ( p_find == (*p_set).set_elements.end( ) ) {
                            flag1 = 0;
                            break;
                        }
                        p_temp++;
                    }
                    int flag2 = 1;

                    p_temp = (*p_set).set_elements.begin( );
                    while ( p_temp != (*p_set).set_elements.end( ) ) {
                        vii p_find = find( (*p_M).temperature_vector.begin( ), (*p_M).temperature_vector.end( ), (*p_temp) );
                        if ( p_find == (*p_M).temperature_vector.end( ) ) {
                            flag2 = 0;
                            break;
                        }
                        p_temp++;
                    }
                    if ( flag1 == 1 && flag2 == 1 ) {
                        one_equ_mach_set.equ_mach.push_back( (*p_M).id );
                    }
                }
                p_M++;
            }
            Equivalent_Machine.push_back( one_equ_mach_set );
        }
    }
}


/**
 * @brief output the data structure Equivalent_Machines to a debug file
 */
void
AT::show_equivalent_machines( )
{
    // output the data structure Equivalent_Machines to a debug file
    ofstream f_out( "Debug/debug_equivalent_machines.txt" );
    vector < equ_mach_set >::iterator p_equ_mach = Equivalent_Machine.begin( );
    while ( p_equ_mach != Equivalent_Machine.end( ) ) {
        f_out << "mg=" << (*p_equ_mach).mg << ",n=" << (*p_equ_mach).n << endl;
        vii p_int = (*p_equ_mach).equ_mach.begin( );
        while ( p_int != (*p_equ_mach).equ_mach.end( ) ) {
            f_out << (*p_int) << ",";
            p_int++;
        }
        f_out << endl;
        p_equ_mach++;
    }
}


/**
 * @brief output the data structure lot_set_heur to a debug file
 */
void
AT::show_lot_set_heur( )
{
    // output the data structure lot_set_heur to a debug file
    ofstream fout( "Debug/debug_lot_set_heur.txt" );
    vii p_int = lot_set_heur.begin( );
    while ( p_int != lot_set_heur.end( ) ) {
        int d = lots_device[(*p_int)];

        fout << "lot=" << (*p_int) << ",d=" << d << ",weight=" << w_l[(*p_int)] << endl;
        p_int++;
    }
    fout.close( );
}


/**
 * @brief sort TS according to eps
 * 
 * @param TS
 */
void
AT::sort_TS( vector < tooling_configure > &TS )
{
    // sort TS according to eps
    for ( int pass = 0; pass <= ( int ) TS.size( ) - 2; pass++ ) {
        for ( int i = 0; i <= ( int ) TS.size( ) - 2; i++ ) {
            vector < tooling_configure >::iterator p1 = TS.begin( ) + i;
            vector < tooling_configure >::iterator p2 = TS.begin( ) + i + 1;
            if ( !compare_tc( (*p1), (*p2) ) ) {
                struct tooling_configure one_tc;

                one_tc = (*p1);
                (*p1) = (*p2);
                (*p2) = one_tc;
            }
        }
    }
}


/**
 * @brief 
 */
void
AT::show_w_l( )
{
    ofstream fout( "Debug/debug_w_l.txt" );
    fout << "show w_l[] --------------------------" << endl;
    for ( int l = 1; l <= Num_Lot; l++ ) {
        fout << "l=" << l << ",w_l=" << w_l[l] << endl;
    }
    fout.close( );
}


/**
 * @brief 
 */
void
AT::show_eps( )
{
    ofstream fout( "Debug/debug_eps.txt" );
    fout << "show eps[] --------------------------" << endl;
    fout << "size of eps[]=" << sizeof (eps) << endl;
    fout << " = " << sizeof (eps) / sizeof (eps[0]) << endl;
    vector < tooling_configure >::iterator p_S = S.begin( );
    while ( p_S != S.end( ) ) {
        int s = (*p_S).id;

        fout << "s=" << s << ",eps=" << eps[s] << endl;
        p_S++;
    }
    fout.close( );
}


/**
 * @brief sort the subset of lots
 * 
 * @param finished_dev_amount
 */
void
AT::sort_lot_heur( int finished_dev_amount[] )
{
    // sort the subset of lots
    // lot_set_heur -> p_device, dev_ord_heur
    // the function builds p_device, dev_ord_heur
    f_log << "In sort_lot_heur()" << endl;

    // build p_device[] from lot_set_heur
    for ( int i = 0; i <= Max_Num_Device - 1; i++ ) {
        p_device[i].int_vector.clear( );
    }
    vii p_lot = lot_set_heur.begin( );
    while ( p_lot != lot_set_heur.end( ) ) {
        int lot = (*p_lot);
        int dev = lots_device[lot];

        p_device[dev].int_vector.push_back( lot );
        p_lot++;
    }
    // --------------------------------------------------
    double *total_weight = new double[Num_Device + 1];
    double *total_qty = new double[Num_Device + 1];
    double *unit_price = new double[Num_Device + 1];
    int *dev_seq = new int[Num_Device + 1];

    for ( int d = 1; d <= Num_Device; d++ ) {
        total_weight[d] = 0;
        total_qty[d] = 0;
    }
    for ( int d = 1; d <= Num_Device; d++ ) {
        dev_seq[d] = d;
        vii p_l = p_device[d].int_vector.begin( );
        while ( p_l != p_device[d].int_vector.end( ) ) {
            int l = (*p_l);

            total_weight[d] += w_l[l];
            total_qty[d] += n_l_chips[l];
            p_l++;
        }
        if ( total_qty[d] > 1 ) {
            unit_price[d] = total_weight[d] / total_qty[d];
            vii p_find = find( Packages.begin( ), Packages.end( ), d );
            if ( p_find == Packages.end( ) ) {
                p_find = find( Key_Devices.begin( ), Key_Devices.end( ), d );
                if ( p_find != Key_Devices.end( ) ) { // d is a keydevice
                    double temp = n_k_minchips[d] - finished_dev_amount[d];

                    if ( temp > 0 ) {
                        unit_price[d] += temp;
                    }
                }
            } else { // d is a package device
                double temp = n_p_minchips[d] - finished_dev_amount[d];

                if ( temp > 0 ) {
                    unit_price[d] += temp;
                }
            }
        } else {
            unit_price[d] = 0;
        }
    }

    // sort the devices according to unit_price[],the order is stored in up[]
    int *up = new int[Num_Device + 1];

    for ( int d = 1; d <= Num_Device; d++ ) {
        up[d] = 0;
    }
    up[1] = 1;
    int up_length = 1;

    for ( int d = 2; d <= Num_Device; d++ ) {
        int index = 0;

        for ( int up_id = up_length; up_id >= 1; up_id-- ) {
            int i = up[up_id];

            if ( unit_price[d] > unit_price[i] ) {
                index = up_id;
                up[up_id + 1] = up[up_id];
            } else {
                index = up_id + 1;
                break;
            }
        }
        up[index] = d;
        up_length++;
    }

    // store the devices' sequence in dev_ord_heur
    dev_ord_heur.clear( );
    for ( int d = 1; d <= Num_Device; d++ ) {
        f_log << "d=" << up[d] << ",unit_price=" << unit_price[up[d]] << endl;
        if ( unit_price[up[d]] > 0 ) {
            dev_ord_heur.push_back( up[d] );
        }
    }

    // sort the lots within one device
    for ( int d = 1; d <= Num_Device; d++ ) {
        if ( ( int ) p_device[d].int_vector.size( ) > 0 ) {
            vector < int >lot_vector;

            lot_vector.push_back( *p_device[d].int_vector.begin( ) );
            vii p_l = p_device[d].int_vector.begin( ) + 1;
            while ( p_l != p_device[d].int_vector.end( ) ) {
                int l = (*p_l);
                double unit_price = w_l[l] / n_l_chips[l];

                vii p_int = lot_vector.end( ) - 1;
                while ( p_int != lot_vector.begin( ) - 1 ) {
                    int lot = (*p_int);

                    if ( w_l[lot] / n_l_chips[lot] > unit_price ) {
                        break;
                    }
                    p_int--;
                }
                p_int++;
                lot_vector.insert( p_int, l );
                p_l++;
            }
            swap( lot_vector, p_device[d].int_vector );
            f_log << "d=" << d << ":";
            p_l = p_device[d].int_vector.begin( );
            while ( p_l != p_device[d].int_vector.end( ) ) {
                f_log << (*p_l) << ",";
                p_l++;
            }
            f_log << endl;
        }
    }
    delete[]up;
    delete[]dev_seq;
    delete[]unit_price;
    delete[]total_qty;
    delete[]total_weight;
}


/**
 * @brief 
 * 
 * @param tooling_used
 * @param finished_dev_amount
 */
void
AT::assign_heur( int **tooling_used, int finished_dev_amount[] )
{
    f_log << "In assign_heur()" << endl;
    int lot_counter = 0;
    int break_limit = 0;

    vii p_dev = dev_ord_heur.begin( );
    while ( p_dev != dev_ord_heur.end( ) ) {
        int dev = (*p_dev);


        // -----------------------------S(d)
        vector < tooling_configure > TS;
        get_S_l( TS, (*p_device[dev].int_vector.begin( )) );

        // sort the routes, primitive first according to eps[]
        sort_TS( TS );
        vii p_lot = p_device[dev].int_vector.begin( );
        while ( p_lot != p_device[dev].int_vector.end( ) ) { // for each lot in the device
            f_log << "dev=" << dev << ",lot=" << (*p_lot) << endl;
            int mach_selected = -1;
            int route_selected = -1;
            vector < int >mach_vect;
            vector < int >route_vect;

            vector < tooling_configure >::iterator p_TS = TS.begin( );
            while ( p_TS != TS.end( ) ) {
                int mg = (*p_TS).mg;
                int s = (*p_TS).id;
                vector < int >a;

                vii pt = (*p_TS).tf.tools.begin( );
                while ( pt != (*p_TS).tf.tools.end( ) ) {
                    int tf = (*pt);
                    int pos = s * Max_Num_Tooling_Family + tf;

                    a.push_back( a_st[pos] );
                    pt++;
                }
                vii pm = (*(Machine_Groups.begin( ) + mg - 1)).machines.begin( );
                while ( pm != (*(Machine_Groups.begin( ) + mg - 1)).machines.end( ) ) {
                    int i = (*pm);

                    vector < machine_heur_item >::iterator p_mach = Machine_Heur.begin( ) + i - 1;

                    // is the mach running?
                    if ( compare_int_vec( (*p_TS).tf.tools, (*p_mach).tooling )
                         && compare_int_vec( a, (*p_mach).b ) &&(*p_mach).package == (*p_TS).package && (*p_mach).temperature == (*p_TS).temperature && (*p_mach).time_used + n_l_chips[(*p_lot)] / rate[s] + Load_Unload_Time <= H[i] ) { // some toolings have been installed
                        mach_vect.push_back( i );
                        route_vect.push_back( s );
                    }
                    pm++;
                }
                p_TS++;
            }
            if ( ( int ) (mach_vect.size( )) > 0 ) { // some running mach can be assigned to the device
                double min_s = 1E+8;
                int s_record = -1;

                vii p_route = route_vect.begin( );
                while ( p_route != route_vect.end( ) ) {
                    int s = (*p_route);

                    if ( eps[s] < min_s ) {
                        min_s = eps[s];
                        s_record = s;
                    }
                    p_route++;
                }
                vii p_mach = mach_vect.begin( );
                double min_t = 1E+8;
                int i_record = -1;

                while ( p_mach != mach_vect.end( ) ) {

                    // select the machine with the least remaining time
                    int n = p_mach - mach_vect.begin( );

                    vii p_r = route_vect.begin( ) + n;
                    vector < machine_heur_item >::iterator pm = Machine_Heur.begin( ) + (*p_mach) - 1;
                    if ( (*pm).time_used < min_t && (*p_r) == s_record ) {
                        min_t = (*pm).time_used;
                        i_record = (*p_mach);
                    }
                    p_mach++;
                }
                mach_selected = i_record;
                route_selected = s_record;
            } else { // no related machine is running
                p_TS = TS.begin( );
                while ( p_TS != TS.end( ) ) {
                    int tooling_selected_flag = 0;
                    int s = (*p_TS).id;
                    int mg = (*p_TS).mg;
                    int temperature = (*p_TS).temperature;
                    struct t_set one_set;

                    one_set.set_elements.push_back( temperature );
                    vector < t_set > inter_set;
                    get_inter_set( one_set, inter_set );
                    vector < t_set >::iterator p_set = inter_set.begin( );
                    vector < int >n_vect;

                    while ( p_set != inter_set.end( ) ) {
                        int n = get_set_id( (*p_set) );

                        n_vect.push_back( n );
                        p_set++;
                    }
                    // select the tooling----------------------------------------------------------------------
                    vii p_tool = (*p_TS).tf.tools.begin( ); // test if there is enough tooling
                    vector < int >record_n;

                    while ( p_tool != (*p_TS).tf.tools.end( ) ) {
                        int tf = (*p_tool);

                        vii p_n = n_vect.begin( );
                        while ( p_n != n_vect.end( ) ) {
                            int n = (*p_n);
                            int pos = tf * Max_Num_Temperature + n;
                            int pos2 = s * Max_Num_Tooling_Family + tf;

                            if ( tooling_used[tf][n] + a_st[pos2] <= n_t_n_tooling[pos] ) {
                                record_n.push_back( n );
                                break;
                            }
                            p_n++;
                        }
                        p_tool++;
                    }
                    if ( ( int ) record_n.size( ) == ( int ) (*p_TS).tf.tools.size( ) ) {
                        tooling_selected_flag = 1;
                    }
                    if ( ( int ) (*p_TS).tf.tools.size( ) == 1 && (*(*p_TS).tf.tools.begin( )) == 0 ) {
                        tooling_selected_flag = 1;
                    }

                    // select a machine to open----------------------------------------------------------------------
                    vii pmg = (*(Machine_Groups.begin( ) + mg - 1)).machines.begin( );
                    while ( pmg != (*(Machine_Groups.begin( ) + mg - 1)).machines.end( ) && tooling_selected_flag ) {
                        int i = (*pmg);

                        vector < Machine >::iterator pM = Machine_vector.begin( ) + i - 1;
                        vii pfind = find( (*pM).temperature_vector.begin( ), (*pM).temperature_vector.end( ), temperature );
                        vector < machine_heur_item >::iterator p_mach = Machine_Heur.begin( ) + i - 1;
                        if ( pfind == (*pM).temperature_vector.end( ) || ( int ) (*p_mach).tooling.size( ) > 0 ) { // the machine i can not run under the temperature
                            pmg++;
                            continue;
                        } else {
                            mach_selected = i;
                            route_selected = s;
                            break;
                        }
                    }
                    if ( mach_selected > 0 ) { // some machine is selected
                        for ( int i = 1; i <= ( int ) record_n.size( ); i++ ) { // assign the tooling
                            vii p_int = record_n.begin( ) + i - 1;
                            int n = (*p_int);

                            p_int = (*p_TS).tf.tools.begin( ) + i - 1;
                            int tf = (*p_int);
                            int pos = s * Max_Num_Tooling_Family + tf;


                            // tooling_used[tf][n]+=a_st[s][tf];
                            tooling_used[tf][n] += a_st[pos];
                        }
                        break;
                    }
                    p_TS++;
                }
            }
            f_log << "mach_selected=" << mach_selected << endl;
            f_log << "route_selected=" << route_selected << endl;

            // assign the lot to mach_selected
            if ( mach_selected > 0 ) {
                vector < machine_heur_item >::iterator p_mach = Machine_Heur.begin( ) + mach_selected - 1;
                (*p_mach).time_used += n_l_chips[(*p_lot)] / rate[route_selected] + Load_Unload_Time;
                vector < tooling_configure >::iterator p_S = S.begin( ) + route_selected - 1;
                (*p_mach).temperature = (*p_S).temperature;
                (*p_mach).package = (*p_S).package;
                (*p_mach).tooling.resize( ( int ) (*p_S).tf.tools.size( ) );
                copy( (*p_S).tf.tools.begin( ), (*p_S).tf.tools.end( ), (*p_mach).tooling.begin( ) );
                vector < int >a;
                int s = (*p_S).id;

                vii pt = (*p_S).tf.tools.begin( );
                while ( pt != (*p_S).tf.tools.end( ) ) {
                    int tf = (*pt);
                    int pos = s * Max_Num_Tooling_Family + tf;

                    a.push_back( a_st[pos] );
                    pt++;
                }
                (*p_mach).b.resize( ( int ) a.size( ) );
                copy( a.begin( ), a.end( ), (*p_mach).b.begin( ) );
                (*p_mach).lot.push_back( *p_lot );
                finished_dev_amount[dev] += n_l_chips[(*p_lot)];
                lot_counter++;
                vector < lot_heur_item >::iterator p_find = Lot_Assign_Heur.begin( ) +(*p_lot) - 1;
                (*p_find).i = mach_selected;
                (*p_find).s = route_selected;
            } else {
                f_log << "discard lot " << (*p_lot) << endl;
            }
            vii p_find = find( lot_set_heur.begin( ), lot_set_heur.end( ), (*p_lot) );
            lot_set_heur.erase( p_find );
            if ( lot_counter >= ( int ) lot_set_heur.size( ) * 0.01 && lot_counter >= 5 ) {
                break_limit = 1;
                break;
            }
            p_find = find( Packages.begin( ), Packages.end( ), dev );
            if ( p_find != Packages.end( ) && finished_dev_amount[dev] >= n_p_minchips[dev] ) {
                break_limit = 1;
                break;
            }
            p_find = find( Key_Devices.begin( ), Key_Devices.end( ), dev );
            if ( p_find != Key_Devices.end( ) && finished_dev_amount[dev] >= n_k_minchips[dev] ) {
                break_limit = 1;
                break;
            }
            p_lot++;
        }
        if ( break_limit ) {
            f_log << "lot_counter=" << lot_counter << endl;
            break;
        }
        p_dev++;
    }
}


/**
 * @brief 
 */
void
AT::initialize_Machine_Heur( )
{
    Machine_Heur.clear( );
    for ( int i = 1; i <= Num_Machine; i++ ) {
        struct machine_heur_item one_item;

        one_item.time_used = 0;
        one_item.temperature = -1;
        Machine_Heur.push_back( one_item );
    }
}


/**
 * @brief
 */
void
AT::show_Machine_Heur( )
{
    ofstream fout( "Debug/debug_Machine_Heur.txt" );
    double total_weight = 0;

    for ( int d = 1; d <= Num_Device; d++ ) {
        package_qty[d] = 0;
        keydevice_qty[d] = 0;
    }
    double obj = 0.0;

    for ( int i = 1; i <= Num_Machine; i++ ) {
        vector < machine_heur_item >::iterator pm = Machine_Heur.begin( ) + i - 1;
        fout << "i=" << i << endl;
        vii p_lot = (*pm).lot.begin( );
        fout << "assigned lots:";
        while ( p_lot != (*pm).lot.end( ) ) {
            fout << (*p_lot) << ",";
            total_weight += w_l[(*p_lot)];
            vector < lot_heur_item >::iterator pp = Lot_Assign_Heur.begin( ) +(*p_lot) - 1;
            obj += (w_l[(*p_lot)] - eps[(*pp).s]);
            int d = lots_device[(*p_lot)];

            vii p_find = find( Packages.begin( ), Packages.end( ), d );
            if ( p_find != Packages.end( ) ) {
                package_qty[d] += n_l_chips[(*p_lot)];
            }
            p_find = find( Key_Devices.begin( ), Key_Devices.end( ), d );
            if ( p_find != Key_Devices.end( ) ) {
                keydevice_qty[d] += n_l_chips[(*p_lot)];
            }
            p_lot++;
        }
        fout << endl << "installed tooling:";
        vii p_tool = (*pm).tooling.begin( );
        while ( p_tool != (*pm).tooling.end( ) ) {
            fout << (*p_tool) << ",";
            p_tool++;
        }
        fout << endl << "number of toolings ";
        vii pb = (*pm).b.begin( );
        while ( pb != (*pm).b.end( ) ) {
            fout << (*pb) << ",";
            pb++;
        }
        fout << "package:" << (*pm).package << endl;
        fout << "temperature:" << (*pm).temperature << endl;
        fout << "time used=" << (*pm).time_used << ", H[i]=" << H[i] << endl;
    }
    fout << "------------------------------------------------" << endl;
    fout << "total_weight=" << total_weight << endl;
    for ( int k = 1; k <= Num_Keydevice; k++ ) {
        int d = (*(Key_Devices.begin( ) + k - 1));
        double shortage = n_k_minchips[d] - keydevice_qty[d];

        fout << "d=" << d << ",required qty=" << n_k_minchips[d] << ",finished qty=" << keydevice_qty[d] << ",shortage=" << shortage << endl;
        if ( shortage > 0 ) {
            obj -= shortage * penalty[d] / coef;
        }
    }
    for ( int p = 1; p <= Num_Package; p++ ) {
        int d = (*(Packages.begin( ) + p - 1));
        double shortage = n_p_minchips[d] - package_qty[d];

        fout << "d=" << d << ",required qty=" << n_p_minchips[d] << ",finished qty=" << package_qty[d] << ",shortage=" << shortage << endl;
        if ( shortage > 0 ) {
            obj -= shortage * penalty[d] / coef;
        }
    }
    fout << "obj=" << obj << endl;
    fout.close( );
}


/**
 * @brief 
 * 
 * @param a
 * @param b
 * 
 * @return 
 */
bool AT::compare_tc( const tooling_configure & a, const tooling_configure & b )
{
    return (eps[a.id] < eps[b.id]);
}


/**
 * @brief 
 * 
 * @param buf
 */
void
AT::pack( BCP_buffer & buf ) const
{
    cout << "int AT pack()" << endl;
    buf.pack( Num_Tooling );
    buf.pack( Num_Tooling_Family );
    buf.pack( Num_Machine );
    buf.pack( Num_Machine_Group );
    buf.pack( Num_Lot );
    buf.pack( Num_Device );
    buf.pack( Num_Keydevice );
    buf.pack( Num_Package );
    buf.pack( Num_Temperature );
    buf.pack( x_limit );
    buf.pack( y_limit );
    buf.pack( SIM_option );
    buf.pack( H, Num_Machine + 1 );
    int *int_array = new int[Num_Tooling_Family * Max_Num_Temperature];

    for ( int tf = 1; tf <= Num_Tooling_Family; tf++ ) {
        for ( int n = 1; n <= Max_Num_Temperature - 1; n++ ) {
            int id = (tf - 1) * Max_Num_Temperature + n - 1;
            int pos = (tf - 1) * Max_Num_Temperature + n - 1;


            // int_array[id]=n_t_n_tooling[tf][n];
            int_array[id] = n_t_n_tooling[pos];

            // if(n==1){ cout<<"tf="<<tf<<",n="<<n<<",id="<<id<<",n_t_n_tooling="<<n_t_n_tooling[tf][n]<<endl;}
        }
    }
    buf.pack( int_array, Num_Tooling_Family * Max_Num_Temperature );
    delete[]int_array;
    buf.pack( n_l_chips, Num_Lot + 1 );
    buf.pack( Key_Devices );
    buf.pack( Packages );
    buf.pack( n_k_minchips, Max_Num_Device + 1 );
    buf.pack( n_p_minchips, Max_Num_Device + 1 );
    buf.pack( w_l, Num_Lot + 1 );
    buf.pack( rate, Max_Num_Tooling_Configure );
    buf.pack( eps, Max_Num_Tooling_Configure );
    buf.pack( lots_device, Num_Lot + 1 );
    buf.pack( machine_mg, Num_Machine + 1 );
    buf.pack( machine_sim, Num_Machine + 1 );
    buf.pack( tooling_tf, Num_Tooling + 1 );
    buf.pack( L_i, Num_Machine + 1 );
    buf.pack( M_l, Num_Lot + 1 );
    buf.pack( S_i, Num_Machine + 1 );
    buf.pack( Lambda_i, Num_Machine + 1 );
    buf.pack( M_lambda, Max_Num_Tooling_Configure );
    buf.pack( S );
    buf.pack( Tooling_Families );
    buf.pack( Tooling_vector );
    buf.pack( Machine_vector );
    buf.pack( Machine_Groups );
    buf.pack( Devices );
    buf.pack( index_vector );
    buf.pack( Temperature_Set );
    buf.pack( device_name );
    buf.pack( lot_name );
    buf.pack( Lambda );
    int_array = new int[( int ) S.size( ) * (Num_Tooling_Family + 1)];

    for ( int s = 1; s <= ( int ) S.size( ); s++ ) {
        for ( int tf = 0; tf <= Num_Tooling_Family; tf++ ) { // need to start from 0 for a_st[][], tf could be zero !!!
            int id = (s - 1) * (Num_Tooling_Family + 1) + tf;
            int pos = (s - 1) * Max_Num_Tooling_Family + tf;


            // int_array[id]=a_st[s][tf];
            int_array[id] = a_st[pos];
        }
    }
    buf.pack( int_array, ( int ) S.size( ) * (Num_Tooling_Family + 1) );
    delete[]int_array;
    buf.pack( SIM );
    buf.pack( Machine_Heur );
    buf.pack( Lot_Assign_Heur );
    buf.pack( tooling_sum_rhs );
    buf.pack( L_sim_lambda );
    buf.pack( sim_lambda_L );
    buf.pack( S_sim_l ); // S(i,l)
    buf.pack( S_sim_l_lambda ); // S(i,l,lambda)
    buf.pack( elite_soln );
    buf.pack( coef );
    buf.pack( sum_weight );
}


/**
 * @brief 
 * 
 * @param buf
 */
void
AT::unpack( BCP_buffer & buf )
{
    cout << "unpack numbers" << endl;
    buf.unpack( Num_Tooling );
    cout << "Num_Tooling=" << Num_Tooling << endl;
    buf.unpack( Num_Tooling_Family );
    buf.unpack( Num_Machine );
    buf.unpack( Num_Machine_Group );
    buf.unpack( Num_Lot );
    buf.unpack( Num_Device );
    buf.unpack( Num_Keydevice );
    buf.unpack( Num_Package );
    buf.unpack( Num_Temperature );
    buf.unpack( x_limit );
    buf.unpack( y_limit );
    cout << "y_limit=" << y_limit << endl;
    buf.unpack( SIM_option );
    cout << "unpack H[]" << endl;
    int num_cols = Num_Machine + 1;
    double *H_cp = new double[num_cols];

    buf.unpack( H_cp, num_cols, false );
    copy( H_cp, H_cp + num_cols, H );

    // for(int i=1;i<=Num_Machine;i++){ cout<<"i="<<i<<",H="<<H[i]<<endl;}
    delete[]H_cp;
    cout << "unpack n_t_n_tooling[][]" << endl;
    num_cols = Num_Tooling_Family * Max_Num_Temperature;
    int *int_array = new int[num_cols];

    buf.unpack( int_array, num_cols, false );
    for ( int tf = 1; tf <= Num_Tooling_Family; tf++ ) {
        for ( int n = 1; n <= Max_Num_Temperature - 1; n++ ) {
            int id = (tf - 1) * Max_Num_Temperature + n - 1;
            int pos = (tf - 1) * Max_Num_Temperature + n - 1;


            // n_t_n_tooling[tf][n]=int_array[id];
            n_t_n_tooling[pos] = int_array[id];

            // if(n==1){cout<<"tf="<<tf<<",n="<<n<<",id="<<id<<",n_t_n_tooling="<<n_t_n_tooling[tf][n]<<endl;}
        }
    }
    delete[]int_array;
    cout << "unpack n_l_chips[]" << endl;
    num_cols = Num_Lot + 1;
    int_array = new int[num_cols];

    buf.unpack( int_array, num_cols, false );
    copy( int_array, int_array + num_cols, n_l_chips );

    // for(int i=1;i<=Num_Lot;i++){ cout<<"i="<<i<<",n_l_chips="<<n_l_chips[i]<<endl;}
    delete[]int_array;
    cout << "unpack Key_Devices" << endl;
    buf.unpack( Key_Devices );
    cout << "size=" << Key_Devices.size( ) << endl;
    cout << "unpack Packages" << endl;
    buf.unpack( Packages );
    cout << "size=" << Packages.size( ) << endl;
    cout << "unpack n_k_minchips[]" << endl;
    num_cols = Max_Num_Device + 1;
    int_array = new int[num_cols];

    buf.unpack( int_array, num_cols, false );
    copy( int_array, int_array + num_cols, n_k_minchips );

    delete[]int_array;
    cout << "unpack n_p_minchips[]" << endl;
    num_cols = Max_Num_Device + 1;
    int_array = new int[num_cols];

    buf.unpack( int_array, num_cols, false );
    copy( int_array, int_array + num_cols, n_p_minchips );

    delete[]int_array;
    num_cols = Num_Lot + 1;
    double *w_l_cp = new double[num_cols];

    buf.unpack( w_l_cp, num_cols, false );
    copy( w_l_cp, w_l_cp + num_cols, w_l );

    // for(int l=1;l<=Num_Lot;l++){ cout<<"l="<<l<<",w_l="<<w_l[l]<<endl;}
    delete[]w_l_cp;
    cout << "unpack rate[]" << endl;
    num_cols = Max_Num_Tooling_Configure;
    double *rate_cp = new double[num_cols];

    buf.unpack( rate_cp, num_cols, false );
    copy( rate_cp, rate_cp + num_cols, rate );

    // for(int s=1;s<=120;s++){ cout<<"s="<<s<<",rate="<<rate[s]<<endl;}
    delete[]rate_cp;
    cout << "unpack eps[]" << endl;
    double *eps_cp = new double[num_cols];

    buf.unpack( eps_cp, num_cols, false );
    copy( eps_cp, eps_cp + num_cols, eps );

    // for(int s=1;s<=120;s++){ cout<<"s="<<s<<",eps="<<eps[s]<<endl;}
    delete[]eps_cp;
    cout << "unpack lots_device[]" << endl;
    num_cols = Num_Lot + 1;
    int_array = new int[num_cols];

    buf.unpack( int_array, num_cols, false );
    copy( int_array, int_array + num_cols, lots_device );

    // for(int l=1;l<=Num_Lot;l++){ cout<<"l="<<l<<",lots_device="<<lots_device[l]<<endl;}
    delete[]int_array;
    cout << "unpack machine_mg[]" << endl;
    num_cols = Num_Machine + 1;
    int_array = new int[num_cols];

    buf.unpack( int_array, num_cols, false );
    copy( int_array, int_array + num_cols, machine_mg );

    // for(int i=1;i<=Num_Machine;i++){ cout<<"i="<<i<<",machine_mg="<<machine_mg[i]<<endl;}
    delete[]int_array;
    cout << "unpack machine_sim[]" << endl;
    num_cols = Num_Machine + 1;
    int_array = new int[num_cols];

    buf.unpack( int_array, num_cols, false );
    copy( int_array, int_array + num_cols, machine_sim );
    delete[]int_array;
    cout << "unpack tooling_tf" << endl;
    num_cols = Num_Tooling + 1;
    int_array = new int[num_cols];

    buf.unpack( int_array, num_cols, false );
    copy( int_array, int_array + num_cols, tooling_tf );

    // for(int t=1;t<=Num_Tooling;t++){ cout<<"t="<<t<<",tooling_tf="<<tooling_tf[t]<<endl;}
    delete[]int_array;
    cout << "unpack L_i" << endl;
    num_cols = Num_Machine + 1;
    vec_int * vec_array = new vec_int[num_cols];
    buf.unpack( vec_array, num_cols, false );
    copy( vec_array, vec_array + num_cols, L_i );

    // show_L_i();
    delete[]vec_array;
    cout << "unpack M_l" << endl;
    num_cols = Num_Lot + 1;
    vec_array = new vec_int[num_cols];
    buf.unpack( vec_array, num_cols, false );
    copy( vec_array, vec_array + num_cols, M_l );

    // show_M_l();
    delete[]vec_array;
    cout << "unpack S_i" << endl;
    num_cols = Num_Machine + 1;
    vec_tc * vec_tc_array = new vec_tc[num_cols];
    buf.unpack( vec_tc_array, num_cols, false );
    copy( vec_tc_array, vec_tc_array + num_cols, S_i );

    // show_S_i();
    delete[]vec_tc_array;
    cout << "unpack Lambda_i" << endl;
    vec_array = new vec_int[num_cols];
    buf.unpack( vec_array, num_cols, false );
    copy( vec_array, vec_array + num_cols, Lambda_i );

    // show_Lambda_i();
    delete[]vec_array;
    cout << "unpack M_lambda" << endl;
    num_cols = Max_Num_Tooling_Configure;
    vec_array = new vec_int[num_cols];
    buf.unpack( vec_array, num_cols, false );
    copy( vec_array, vec_array + num_cols, M_lambda );
    delete[]vec_array;
    cout << "unpack S" << endl;
    buf.unpack( S );

    // show_S();
    cout << "unpack Tooling_Families" << endl;
    buf.unpack( Tooling_Families );
    cout << "unpack Tooling_vector" << endl;
    buf.unpack( Tooling_vector );

    // show_Tooling_vector();
    cout << "unpack Machine_vector" << endl;
    buf.unpack( Machine_vector );

    // show_Machine_vector();
    cout << "unpack Machine_Groups" << endl;
    buf.unpack( Machine_Groups );
    cout << "unpack Devices" << endl;
    buf.unpack( Devices );

    // show_Devices();
    cout << "unpack index_vector" << endl;
    buf.unpack( index_vector );

    // show_index_vector();
    cout << "unpack Temperature_Set" << endl;
    buf.unpack( Temperature_Set );
    cout << "unpack device_name" << endl;
    buf.unpack( device_name );

    // show_device_name();
    cout << "unpack lot_name" << endl;
    buf.unpack( lot_name );
    cout << "unpack Lambda vector" << endl;
    buf.unpack( Lambda );

    // show_Lambda();
    cout << "unpack a_st" << endl;
    num_cols = ( int ) S.size( ) * (Num_Tooling_Family + 1);
    int_array = new int[num_cols];

    buf.unpack( int_array, num_cols, false );
    for ( int s = 1; s <= ( int ) S.size( ); s++ ) {
        for ( int tf = 0; tf <= Num_Tooling_Family; tf++ ) { // need to start from 0 for a_st[][], tf could be zero !!!
            int id = (s - 1) * (Num_Tooling_Family + 1) + tf;
            int pos = (s - 1) * Max_Num_Tooling_Family + tf;
            a_st[pos] = int_array[id];
        }
    }

    delete[]int_array;
    cout << "unpack SIM" << endl;
    buf.unpack( SIM );
    cout << "unpack Machine_Heur" << endl;
    buf.unpack( Machine_Heur );
    cout << "unpack Lot_Assign_Heur" << endl;
    buf.unpack( Lot_Assign_Heur );
    cout << "unpack tooling_sum_rhs" << endl;
    buf.unpack( tooling_sum_rhs );
    cout << "unpack L_sim_lambda" << endl;
    buf.unpack( L_sim_lambda );
    cout << "unpack sim_lambda_L" << endl;
    buf.unpack( sim_lambda_L );
    cout << "unpack S_sim_l" << endl;
    buf.unpack( S_sim_l ); // S(i,l)
    cout << "unpack S_sim_l_lambda" << endl;
    buf.unpack( S_sim_l_lambda );
    cout << "unpack elite_soln" << endl;
    buf.unpack( elite_soln );
    cout << "unpack coef" << endl;
    buf.unpack( coef );
    cout << "unpack sum_wieght" << endl;
    buf.unpack( sum_weight );
}


/**
 * @brief 
 * 
 * @param buf
 */
AT::AT( BCP_buffer & buf )
{
    unpack( buf );
}


/**
 * @brief used to group the machines into SIM(set of identical machines
 * 
 * this function is used to group the machines into SIM(set of identical machines)
 * identical machine: (1)in the same machine family (2)have the same list of operating temperatures (3)have the same H[]
 */
void
AT::get_SIM( )
{
    // this function is used to group the machines into SIM(set of identical machines)
    // identical machine: (1)in the same machine family (2)have the same list of operating temperatures (3)have the same H[]
    vector < Machine >::iterator pM = Machine_vector.begin( );
    while ( pM != Machine_vector.end( ) ) {
        int identical_flag = 0; // not identical

        if ( ( int ) SIM.size( ) < 1 ) { // nothing in SIM yet
            struct SIM_item one_item;

            one_item.simid = 1;
            one_item.represented_machine_id = (*pM).id;
            one_item.mg = (*pM).mg;
            copy( (*pM).name, (*pM).name + 50, one_item.name );
            one_item.temperature_vector.resize( ( int ) (*pM).temperature_vector.size( ) );
            copy( (*pM).temperature_vector.begin( ), (*pM).temperature_vector.end( ), one_item.temperature_vector.begin( ) );
            one_item.num_machine = 1;
            machine_sim[(*pM).id] = one_item.simid;
            SIM.push_back( one_item );
        } else {
            vector < SIM_item >::iterator pSIM = SIM.begin( );
            while ( pSIM != SIM.end( ) ) {
                if ( (*pSIM).mg == (*pM).mg && compare_int_vec( (*pSIM).temperature_vector, (*pM).temperature_vector ) && fabs( H[(*pSIM).represented_machine_id] - H[(*pM).id] ) < 1E-03 ) {

                    // (*pSIM) is identical to (*pM)
                    (*pSIM).num_machine++;
                    machine_sim[(*pM).id] = (*pSIM).simid;
                    identical_flag = 1;
                    break;
                }
                pSIM++;
            }
            if ( !identical_flag ) {
                struct SIM_item one_item;

                one_item.simid = ( int ) SIM.size( ) + 1;
                one_item.represented_machine_id = (*pM).id;
                one_item.mg = (*pM).mg;
                copy( (*pM).name, (*pM).name + 50, one_item.name );
                one_item.temperature_vector.resize( ( int ) (*pM).temperature_vector.size( ) );
                copy( (*pM).temperature_vector.begin( ), (*pM).temperature_vector.end( ), one_item.temperature_vector.begin( ) );
                one_item.num_machine = 1;
                machine_sim[(*pM).id] = one_item.simid;
                SIM.push_back( one_item );
            }
        }

        pM++;
    }
}


/**
 * @brief 
 */
void
AT::show_SIM( )
{
    ofstream fSIM( "Debug/debugSIM.txt" );
    vector < SIM_item >::iterator pSIM = SIM.begin( );
    while ( pSIM != SIM.end( ) ) {
        fSIM << "simid=" << (*pSIM).simid << ",mg=" << (*pSIM).mg << ",represented_id=" << (*pSIM).represented_machine_id << ",name=" << (*pSIM).name << ",num_machine=" << (*pSIM).num_machine << endl;
        fSIM << "operating temperatures: " << endl;
        vii pt = (*pSIM).temperature_vector.begin( );
        while ( pt != (*pSIM).temperature_vector.end( ) ) {
            fSIM << (*pt) << ",";
            pt++;
        }
        fSIM << endl;
        for ( int i = 1; i <= Num_Machine; i++ ) {
            if ( machine_sim[i] == (*pSIM).simid ) {
                fSIM << i << ",";
            }
        }
        fSIM << endl;
        pSIM++;
    }
    fSIM.close( );
}


/**
 * @brief 
 */
void
AT::show_machine_sim( )
{
    ofstream fout( "Debug/debug_machine_sim.txt" );
    for ( int i = 1; i <= Num_Machine; i++ ) {
        fout << "i=" << i << ",sim=" << machine_sim[i] << endl;
    }
    fout.close( );
}


/**
 * @brief
 */
void
AT::get_LPD( )
{
    LPD.clear( );
    vii p_int = Key_Devices.begin( );
    while ( p_int != Key_Devices.end( ) ) {
        int d = (*p_int);

        vector < device_item >::iterator p_dev = Devices.begin( ) + d - 1;
        vii p_lot = (*p_dev).device_lots.begin( );
        while ( p_lot != (*p_dev).device_lots.end( ) ) {
            LPD.push_back( *p_lot );
            p_lot++;
        }
        p_int++;
    }
    p_int = Packages.begin( );
    while ( p_int != Packages.end( ) ) {
        int d = (*p_int);

        vector < device_item >::iterator p_dev = Devices.begin( ) + d - 1;
        vii p_lot = (*p_dev).device_lots.begin( );
        while ( p_lot != (*p_dev).device_lots.end( ) ) {
            LPD.push_back( *p_lot );
            p_lot++;
        }
        p_int++;
    }
    ofstream fout( "Debug/debug_LPD.txt" );
    p_int = LPD.begin( );
    while ( p_int != LPD.end( ) ) {
        fout << (*p_int) << endl;
        p_int++;
    }
    fout.close( );
}


/**
 * @brief given the LP solution, apply the heuristic for the first level problem
 * 
 * This routine should be called after the LP solver.
 */
void
AT::first_level_heuristic( )
{
    // given the LP solution, apply the heuristic for the first level problem
    // this routine should be called after the LP solver
    double *solution = new double[y_limit + 1];
    int *tooling_used = new int[Num_Tooling_Family * Num_Temperature];
    int *sim_used = new int[( int ) SIM.size( ) + 1];
    int *SIM_number = new int[( int ) SIM.size( ) + 1];
    int fix_y[Max_Num_Machine + 1];


    // clear the arrays
    for ( int id = 0; id <= y_limit; id++ ) {
        solution[id] = 0.0;
    }
    for ( int id = 0; id <= Num_Tooling_Family * Num_Temperature - 1; id++ ) {
        tooling_used[id] = 0;
    }
    for ( int id = 0; id <= ( int ) SIM.size( ); id++ ) {
        sim_used[id] = 0;
        SIM_number[id] = 0;
    }
    int second_level_option = 1; // 1: apply math model 2:apply greedy method

    // ============================================================================================================{
    // --------------------------------------------------------setup the model through OSI
    CoinPackedMatrix M;
    double *cost = new double[y_limit + 1];
    double *col_lb = new double[y_limit + 1];
    double *col_ub = new double[y_limit + 1];
    int num_con = 0;

    if ( new_old_model == 1 ) {

        // updated model
        num_con = Num_Lot + Num_Machine + Num_Tooling_Family * ( int ) Temperature_Set.size( );
        for ( int i = 1; i <= Num_Machine; i++ ) {
            num_con += ( int ) Lambda_i[i].int_vector.size( );
        }
        num_con += Num_Keydevice + Num_Package;

        // add Key PKG and Key PIN PKG constraints
        num_con += ( int ) Key_PKG.size( ) + ( int ) Key_PIN_PKG.size( );
    } else {
        num_con = Num_Lot;
        for ( int i = 1; i <= Num_Machine; i++ ) {
            vector < int >::iterator p_Lambda = Lambda_i[i].int_vector.begin( );

            while ( p_Lambda != Lambda_i[i].int_vector.end( ) ) {
                int Lambda_id = (*p_Lambda);
                vector < int >::iterator p_L = L_i[i].int_vector.begin( );

                while ( p_L != L_i[i].int_vector.end( ) ) {
                    int l = (*p_L);

                    vector < tooling_configure > TS;
                    get_S_i_l_Lambda( TS, i, l, Lambda_id );
                    num_con += ( int ) TS.size( );
                    p_L++;
                }
                p_Lambda++;
            }
        }
        num_con += Num_Machine + Num_Tooling_Family * ( int ) Temperature_Set.size( ) + Num_Machine + Num_Keydevice + Num_Package;

        // add Key PKG and Key PIN PKG constraints
        num_con += ( int ) Key_PKG.size( ) + ( int ) Key_PIN_PKG.size( );
    }
    cout << "in first_level_heuristic,num_var=" << y_limit + 1 << ",num_con=" << num_con << endl;
    double *row_lb = new double[num_con];
    double *row_ub = new double[num_con];


    // --------------------------------------------clear the arrays
    time_t t1, t2;
    for ( int id = 0; id <= y_limit; id++ ) {
        cost[id] = 0.0;
        col_lb[id] = -DBL_MAX;
        col_ub[id] = DBL_MAX;
    }
    for ( int id = 0; id <= num_con - 1; id++ ) {
        row_lb[id] = -DBL_MAX;
        row_ub[id] = DBL_MAX;
    }
    // ============================================================================================================}
    if ( second_level_option == 1 ) {
        build_first_level_model_OSI( &M, cost, col_lb, col_ub, row_lb, row_ub );
        OsiXxxSolverInterface si;
        time( &t1 );
        si.loadProblem( M, col_lb, col_ub, cost, row_lb, row_ub );
        time( &t2 );
        cout << "it costs " << difftime( t2, t1 ) << " seconds to load the problem" << endl;

        // set the integer variables
        time( &t1 );
        for ( int id = 0; id <= x_limit; id++ ) {
            si.setInteger( id );
        }
        for ( int id = x_limit + Num_Keydevice + Num_Package + ( int ) Key_PKG.size( ) + ( int ) Key_PIN_PKG.size( ) + 1; id <= y_limit; id++ ) {
            si.setInteger( id );
        }
        time( &t2 );
        cout << "it costs " << difftime( t2, t1 ) << " seconds to set the integrity" << endl;
        si.setHintParam( OsiDoDualInResolve, false, OsiHintDo );
        si.writeLp( "Debug/AT_OSI" ); // THIS IS THE WHOLE MODEL (This is the problem we are going to solve)
    }

    // ============================================================================================================{build the model for update_benefit
    CoinPackedMatrix M2;
    double *cost2 = new double[Num_Lot + Num_Keydevice + Num_Package];
    double *col_lb2 = new double[Num_Lot + Num_Keydevice + Num_Package];
    double *col_ub2 = new double[Num_Lot + Num_Keydevice + Num_Package];
    double *row_lb2 = new double[1 + Num_Keydevice + Num_Package];
    double *row_ub2 = new double[1 + Num_Keydevice + Num_Package];

    build_update_benefit_model( &M2, cost2, col_lb2, col_ub2, row_lb2, row_ub2 );
    OsiXxxSolverInterface si_KP;
    si_KP.loadProblem( M2, col_lb2, col_ub2, cost2, row_lb2, row_ub2 );

    // ============================================================================================================}
    // -----------------------------------------------------------------------------------
    vector < double >SL_avg( ( int ) L_sim_lambda.size( ), 0 );
    vector < int >SL_num( ( int ) SL_avg.size( ), 0 );
    vector < double >SL_best( ( int ) L_sim_lambda.size( ), 0 );


    // -----------------------------------------------------------------------------------
    time( &t1 );
    int alpha_list[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
    double prob_list[] = { 0.10, 0.10, 0.10, 0.10, 0.10, 0.10, 0.10, 0.10, 0.10, 0.10 };
    double avg_list[] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
    int num_list[] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
    double delta = 50;

    vector < soln_pool_item > soln_pool;
    int soln_pool_size = 20;
    double best_obj = 1E+10;
    int best_iter = -1;


    // ----------------------------------------------------------initialize the sim_lambda_benefit
    for ( int tf = 1; tf <= Num_Tooling_Family; tf++ ) {
        for ( int n = 1; n <= Num_Temperature; n++ ) {
            int id = (tf - 1) * Num_Temperature + n - 1;

            tooling_used[id] = 0;
        }
    }
    for ( int i = 1; i <= ( int ) SIM.size( ); i++ ) {
        sim_used[i] = 0;
    }
    for ( int i = 1; i <= ( int ) SIM.size( ); i++ ) {
        SIM_number[i] = 0;
    }
    for ( int i = 1; i <= Num_Machine; i++ ) {
        int simid = machine_sim[i];

        SIM_number[simid]++;
    }
    vector < pair < double, vec_int > >sim_lambda_benefit_save;

    initialize_benefit( sim_lambda_benefit_save, tooling_used, sim_used, SIM_number );

    // -----------------------------------------------------------
    OsiXxxSolverInterface si;
    si.loadProblem( M, col_lb, col_ub, cost, row_lb, row_ub );

    // set the integer variables
    for ( int id = 0; id <= x_limit; id++ ) {
        si.setInteger( id );
    }
    for ( int id = x_limit + Num_Keydevice + Num_Package + ( int ) Key_PKG.size( ) +( int ) Key_PIN_PKG.size( ) + 1; id <= y_limit; id++ ) {
        si.setInteger( id );
        si.setColBounds( id, 0, 0 );
    }
    for ( int iter = 1; iter <= Max_Iter; iter++ ) {
        cout << "Outer iter=" << iter << endl;

        // ----------------------------------------------------initialization
        for ( int id = x_limit + Num_Keydevice + Num_Package + ( int ) Key_PKG.size( ) + ( int ) Key_PIN_PKG.size( ) + 1; id <= y_limit; id++ ) {
            si.setColBounds( id, 0, 0 );
        }
        for ( int tf = 1; tf <= Num_Tooling_Family; tf++ ) {
            for ( int n = 1; n <= Num_Temperature; n++ ) {
                int id = (tf - 1) * Num_Temperature + n - 1;

                tooling_used[id] = 0;
            }
        }
        for ( int i = 1; i <= ( int ) SIM.size( ); i++ ) {
            sim_used[i] = 0;
        }
        for ( int i = 1; i <= Num_Machine; i++ ) {
            fix_y[i] = 0;
        } // clear fix_y[]
        vector < int >lot_remain;

        for ( int l = 1; l <= Num_Lot; l++ ) {
            lot_remain.push_back( l );
        }
        vector < pair < double, vec_int > >sim_lambda_benefit;

        sim_lambda_benefit.resize( ( int ) sim_lambda_benefit_save.size( ) );
        copy( sim_lambda_benefit_save.begin( ), sim_lambda_benefit_save.end( ), sim_lambda_benefit.begin( ) );

        // --------------------------------------------------------------------self-adjusted RCL
        int select_alpha_id = -1;
        double alpha = 0;

        if ( iter <= 10 ) { // warm up
            select_alpha_id = iter - 1;
            alpha = alpha_list[select_alpha_id];
        } else {
            select_alpha_id = select_alpha( prob_list, 10 );
            alpha = alpha_list[select_alpha_id];
        }
        cout << "alpha=" << alpha << endl;

        // --------------------------------------------------------------------start the loop
        int counter = 0;
        vector < int >lot_assigned_so_far;
        vector < int >production( Num_Device, 0 );

        while ( true ) {
            cout << "counter=" << counter << endl;

            // --------------------------------------------------------------------------construct the CL and RCL
            vector < pair < pair < int, int >, double > > candidate_list;

            construct_CL( candidate_list, tooling_used, sim_used, SIM_number, sim_lambda_benefit );
            cout << "size of CL=" << ( int ) candidate_list.size( ) << endl;
            if ( ( int ) candidate_list.size( ) < 1 ) {
                break;
            } // stop the loop here
            int RCL_length = construct_RCL( candidate_list, alpha );

            cout << "RCL_length=" << RCL_length << endl;
            int selected_id;

            if ( iter <= 20 ) {
                selected_id = pick( RCL_length ) + 1;
            } else {
                selected_id = pick( candidate_list, RCL_length, SL_avg, SL_best, best_obj, 50 ) + 1;
            }
            cout << "selected_id=" << selected_id << endl;

            // ----------------------------------------------------------------------------randomly select one
            vector < pair < pair < int, int >, double > > ::iterator p_selected = candidate_list.begin( ) + selected_id - 1;
            int sim_selected = (*p_selected).first.first;
            int Lambda_selected = (*p_selected).first.second;

            vector < Lambda_item >::iterator pL = Lambda.begin( ) + Lambda_selected - 1;
            cout << "sim_selected=" << sim_selected << ",Lambda_selected=" << Lambda_selected << endl;

            // ----------------------------------------------------------------------------update machine and tooling usage
            sim_used[sim_selected]++;

            // ---------------------------------------------------
            vii p_tf = (*pL).tooling_vec.begin( );
            while ( p_tf != (*pL).tooling_vec.end( ) ) {
                int tf = (*p_tf);
                int offset = p_tf - (*pL).tooling_vec.begin( );

                vii p_b = (*pL).b.begin( ) + offset;
                int id = (tf - 1) * Num_Temperature + (*pL).temperature - 1;

                tooling_used[id] += (*p_b);
                p_tf++;
            }
            // ---------------------------------------------------fix y
            cout << "fix y" << endl;
            for ( int i = 1; i <= Num_Machine; i++ ) {
                if ( machine_sim[i] == sim_selected && fix_y[i] < 1 ) {
                    fix_y[i] = Lambda_selected;
                    break;
                }
            }

            // -------------------------------------------------------------------------------------assign lots to the selected sim_lambda combination
            vector < int >lot_selected;

            cout << "greedy assignment" << endl;

            // greedy_assignment(sim_selected,Lambda_selected,lot_remain,lot_selected,production);
            int id_select = index_L_sim_lambda( sim_selected, Lambda_selected );

            lot_selected.resize( ( int ) sim_lambda_benefit[id_select].second.int_vector.size( ) );
            copy( sim_lambda_benefit[id_select].second.int_vector.begin( ), sim_lambda_benefit[id_select].second.int_vector.end( ), lot_selected.begin( ) );
            vector < int >affected_dev;

            for ( int l1 = 1; l1 <= ( int ) lot_selected.size( ); l1++ ) {
                int l = lot_selected[l1 - 1];
                int d = lots_device[l];

                lot_assigned_so_far.push_back( l );
                production[d - 1] += n_l_chips[l];
                vii pfind = find( lot_remain.begin( ), lot_remain.end( ), l );
                if ( pfind != lot_remain.end( ) ) {
                    lot_remain.erase( pfind );
                }
                vii p2 = find( affected_dev.begin( ), affected_dev.end( ), d );
                if ( p2 == affected_dev.end( ) ) {
                    affected_dev.push_back( d );
                }
                si_KP.setColBounds( l - 1, 0.0, 0.0 );
            }

            // --------------------------------------------------
            cout << "size of lot_remain  =" << lot_remain.size( ) << endl;
            cout << "size of lot_selected=" << lot_selected.size( ) << endl;

            // -------------------------------------------------
            cout << "updates" << endl;
            update_benefit( sim_lambda_benefit, lot_remain, production, affected_dev, tooling_used, sim_used, SIM_number );
            counter++;
        }

        // -------------------------------------------------------------------------------
        double second_level_obj = 1E+10;

        vector < sub_soln_item > sub_soln;
        vector < pair < int, double > > shortage;
        vector < pair < pair < int, double >, double > > unassigned_lots;

        if ( second_level_option == 1 ) {

            // ---------------------------------------------------------------------------solve the problem with fix_y[] as LP
            for ( int i = 1; i <= Num_Machine; i++ ) {
                if ( fix_y[i] > 0 ) {
                    int y_id = index_y( i, fix_y[i] );

                    si.setColBounds( y_id, 1, 1 );
                }
            }
            si.setHintParam( OsiDoDualInResolve, false, OsiHintDo );
            if ( LP_IP == 1 ) {
                si.writeLp( "Debug/first_level_heur" ); // This is a subproblem when y is fixed
                si.resolve( );
                Num_LP_solved++;
            } else {
                si.branchAndBound( );
            }
            if ( si.isProvenOptimal( ) ) {
                CoinDisjointCopyN( si.getColSolution( ), y_limit + 1, solution );

                // ---------------------------------------------------------------------------adjust solution[]
                adjust_LP_solution( solution );

                // -----------------------------------------------------------------------solve this subproblem heuristically
                second_level_obj = second_level_heuristic( solution, sub_soln, shortage, unassigned_lots, 2 );
            } else {
                continue;
            }
        } else if ( second_level_option == 2 ) {
            second_level_obj = second_level_greedy( fix_y, sub_soln, shortage, unassigned_lots );
        }
        cout << "second_level_obj=" << second_level_obj << endl;

        // ------------------------------------------------------------------
        bool insert_flag = true;
        for ( int j = 1; j <= ( int ) soln_pool.size( ); j++ ) {
            if ( fabs( second_level_obj - soln_pool[j - 1].obj ) < 1E-06 ) {
                insert_flag = false;
            }
        }
        if ( insert_flag ) {
            soln_pool_item one_item;
            one_item.obj = second_level_obj;
            one_item.sub_soln.resize( ( int ) sub_soln.size( ) );
            copy( sub_soln.begin( ), sub_soln.end( ), one_item.sub_soln.begin( ) );
            one_item.shortage.resize( ( int ) shortage.size( ) );
            copy( shortage.begin( ), shortage.end( ), one_item.shortage.begin( ) );
            one_item.unassigned_lots.resize( ( int ) unassigned_lots.size( ) );
            copy( unassigned_lots.begin( ), unassigned_lots.end( ), one_item.unassigned_lots.begin( ) );
            soln_pool.push_back( one_item );
        }

        // ------------------------------------------------------------------do update staff here
        if ( second_level_obj < best_obj ) {
            best_obj = second_level_obj;
            best_iter = iter;
        }

        // update the alpha probability list
        if ( iter <= 10 ) {
            avg_list[select_alpha_id] = second_level_obj;
            num_list[select_alpha_id]++;
        } else {
            avg_list[select_alpha_id] = ((avg_list[select_alpha_id] * num_list[select_alpha_id]) + second_level_obj) / (num_list[select_alpha_id] + 1);
            num_list[select_alpha_id]++;
            update_alpha_prob( prob_list, avg_list, 10, best_obj, delta );
        }

        // update SL
        for ( int i = 1; i <= Num_Machine; i++ ) {
            int sim = machine_sim[i];
            int Lambda_id = fix_y[i];

            if ( Lambda_id > 0 ) {
                int index = index_L_sim_lambda( sim, Lambda_id );

                SL_avg[index] = (SL_avg[index] * SL_num[index] + second_level_obj) / (SL_num[index] + 1);
                if ( SL_num[index] < 1 || second_level_obj < SL_best[index] ) {
                    SL_best[index] = second_level_obj;
                }
                SL_num[index]++;
                if ( SL_best[index] > best_obj ) {
                    best_obj = SL_best[index];
                }
            }
        }
        cout << "insert_flag=" << insert_flag << endl;
    }
    time( &t2 );
    cout << "it costs " << difftime( t2, t1 ) << " seconds to run the Phase I iterations" << endl;
    cout << "best iter=" << best_iter << ",best_obj=" << best_obj << endl;
    sort( soln_pool.begin( ), soln_pool.end( ), compare_soln );
    cout << "Phase I statistics:" << endl;
    cout << "Min =" << soln_pool[0].obj << ",Max=" << soln_pool[( int ) soln_pool.size( ) - 1].obj << endl;
    double PhaseI_avg = 0.0;

    for ( int id = 1; id <= ( int ) soln_pool.size( ); id++ ) {
        PhaseI_avg += soln_pool[id - 1].obj;
    }
    PhaseI_avg = PhaseI_avg / ( int ) soln_pool.size( );
    cout << "ave obj=" << PhaseI_avg << endl;
    if ( ( int ) soln_pool.size( ) > soln_pool_size ) {
        soln_pool.erase( soln_pool.begin( ) + soln_pool_size, soln_pool.end( ) );
    }
    for ( int i = 1; i <= ( int ) soln_pool.size( ); i++ ) {
        cout << soln_pool[i - 1].obj << endl;
    }
    ofstream fcout( "Output/resultsummery.txt" );
    fcout << "it costs " << difftime( t2, t1 ) << " seconds to run the Phase I iterations" << endl;
    fcout << "best iter=" << best_iter << ",best_obj=" << best_obj << endl;
    fcout << "Phase I statistics:" << endl;
    fcout << "Min =" << soln_pool[0].obj << ",Max=" << soln_pool[( int ) soln_pool.size( ) - 1].obj << endl;
    fcout << "ave obj=" << PhaseI_avg << endl;
    fcout << "solution pool:" << endl;
    for ( int i = 1; i <= ( int ) soln_pool.size( ); i++ ) {
        fcout << soln_pool[i - 1].obj << endl;
    }
    fcout.close( );

    // ---------------------------------------------------------------------------copy the solutions to elite_soln (data member of AT class)
    elite_soln.clear( );
    elite_soln.resize( ( int ) soln_pool.size( ) );
    copy( soln_pool.begin( ), soln_pool.end( ), elite_soln.begin( ) );

    // ---------------------------------------------------------------------------output Phase I solution
    cout << "elite soln after Phase I" << endl;
    for ( int i = 1; i <= ( int ) soln_pool.size( ); i++ ) {
        double total_weight = 0.0;

        for ( int j = 1; j <= Num_Machine; j++ ) {
            vii p_lot = soln_pool[i - 1].sub_soln[j - 1].lots.int_vector.begin( );
            while ( p_lot != soln_pool[i - 1].sub_soln[j - 1].lots.int_vector.end( ) ) {
                int l = (*p_lot);

                total_weight += w_l[l];
                p_lot++;
            }
        }
        double total_shortage = 0.0;

        for ( int d = 1; d <= Num_Device; d++ ) {
            if ( is_KD_PD( d ) && soln_pool[i - 1].shortage[d - 1].second > 0 ) {
                total_shortage += soln_pool[i - 1].shortage[d - 1].second;
            }
        }
        cout << "obj=" << soln_pool[i - 1].obj << ",total_weight=" << total_weight << ",total_shortage=" << total_shortage << endl;
    }

    // ---------------------------------------------------------------------------local search for the elite soln
    if ( PhaseII_option ) {
        time_t local_search_start;
        time( &local_search_start );

        // -------------------------------------------------------------------------------try the LP local branch idea
        cout << "Apply LP based Local Branch with K=1" << endl;
        time( &t1 );
        double best_local_branch_obj = 1E+10;
        int best_id = -1;

        for ( int id = 1; id <= ( int ) soln_pool.size( ); id++ ) {
            OsiXxxSolverInterface ssii;
            ssii.loadProblem( M, col_lb, col_ub, cost, row_lb, row_ub );
            int counter = 1;


            // apply local branch 1
            int K = 1;
            double best_for_this_id = soln_pool[id - 1].obj;
            double local_branch_obj = local_branch_LP( &ssii, soln_pool[id - 1], K );

            cout << "id=" << id << ",local_branch_obj_1=" << local_branch_obj << ",best_for_this_id=" << best_for_this_id << endl;
            while ( local_branch_obj < best_for_this_id - 1E-06 && counter <= 2 ) {
                best_for_this_id = local_branch_obj;
                local_branch_obj = local_branch_LP( &ssii, soln_pool[id - 1], K );
                cout << "id=" << id << ",local_branch_obj_1=" << local_branch_obj << endl;
                counter++;
            }
            if ( best_for_this_id < best_local_branch_obj ) {
                best_local_branch_obj = best_for_this_id;
                best_id = id;
            }
        }
        soln_pool[best_id - 1].obj = compute_obj( soln_pool[best_id - 1].sub_soln, soln_pool[best_id - 1].shortage );

        // --------------------------------------------------------------------------------compute total weight and total shortage
        double tw_lb = 0.0;

        for ( int j = 1; j <= Num_Machine; j++ ) {
            vii p_lot = soln_pool[best_id - 1].sub_soln[j - 1].lots.int_vector.begin( );
            while ( p_lot != soln_pool[best_id - 1].sub_soln[j - 1].lots.int_vector.end( ) ) {
                int l = (*p_lot);

                tw_lb += w_l[l];
                p_lot++;
            }
        }
        double ts_lb = 0.0;

        for ( int d = 1; d <= Num_Device; d++ ) {
            if ( is_KD_PD( d ) && soln_pool[best_id - 1].shortage[d - 1].second > 0 ) {
                ts_lb += soln_pool[best_id - 1].shortage[d - 1].second;
            }
        }
        cout << "obj=" << soln_pool[best_id - 1].obj << ",total_weight=" << tw_lb << ",total_shortage=" << ts_lb << endl;
        time( &t2 );
        cout << "it costs " << difftime( t2, t1 ) << " seconds to run the local branch" << endl;
        cout << "Num_Simulated=" << Num_Simulated << ",Num_Discarded=" << Num_Discarded << endl;

        // ------------------------------------------------------------------------------------------------------------
        cout << "Apply LP based Local Branch with K=2" << endl;
        time( &t1 );
        best_local_branch_obj = 1E+10;
        best_id = -1;
        for ( int id = 1; id <= ( int ) soln_pool.size( ); id++ ) {
            OsiXxxSolverInterface ssii;
            ssii.loadProblem( M, col_lb, col_ub, cost, row_lb, row_ub );
            int counter = 1;


            // apply local branch 2
            double best_for_this_id = soln_pool[id - 1].obj;
            double local_branch_obj = local_branch_LP( &ssii, soln_pool[id - 1], 2 );

            cout << "id=" << id << ",local_branch_obj_2=" << local_branch_obj << ",best_for_this_id=" << best_for_this_id << endl;
            while ( local_branch_obj < best_for_this_id - 1E-06 && counter <= 2 ) {
                best_for_this_id = local_branch_obj;
                local_branch_obj = local_branch_LP( &ssii, soln_pool[id - 1], 2 );
                cout << "id=" << id << ",local_branch_obj_2=" << local_branch_obj << endl;
            }
            if ( best_for_this_id < best_local_branch_obj ) {
                best_local_branch_obj = best_for_this_id;
                best_id = id;
            }
        }
        soln_pool[best_id - 1].obj = compute_obj( soln_pool[best_id - 1].sub_soln, soln_pool[best_id - 1].shortage );
        cout << "obj=" << soln_pool[best_id - 1].obj << endl;
        time( &t2 );
        cout << "it costs " << difftime( t2, t1 ) << " seconds to run the local branch" << endl;
        cout << "Total Num_Simulated=" << Num_Simulated << ",Total Num_Discarded=" << Num_Discarded << endl;
        cout << "Num_LP_solved=" << Num_LP_solved << endl;

        // -----------------------------------------------------------
        // ----------------------------------------------------------try the gene idea
    }

    // ---------------------------------------------------------------------------output the best solution
    sort( soln_pool.begin( ), soln_pool.end( ), compare_soln );
    minimize_makespan( soln_pool[0] );
    show_sub_soln( soln_pool[0].sub_soln );

    // ---------------------------------------------------------------------------here comes the enhancement
    initialize_tooling_trace( soln_pool[0], tooling_trace );

    // show_tooling_trace(tooling_trace);
    machine_resetup( soln_pool[0] );

    // ---------------------------------------------------------------------------this part generates reports for the GRASP solution
    double *solution_output = new double[y_limit + 1 + (y_limit - x_limit + 1)];

    soln_pool_item_to_solution( soln_pool[0], solution_output ); // transform the best GRASP solution to a double array for output
    generate_reports( solution_output );

    // delete [] solution_output;
    // ---------------------------------------------------------------------------this part generates reports for the enhanced actions
    generate_reports( initial_running_lot, enhanced_solution );
    show_tooling_trace( tooling_trace );

    // -------------------------------------------------------------------------------------------------------
    delete[]SIM_number;
    delete[]sim_used;
    delete[]tooling_used;
    delete[]solution;
    delete[]cost;
    delete[]col_lb;
    delete[]col_ub;
    delete[]row_lb;
    delete[]row_ub;
    delete[]cost2;
    delete[]col_lb2;
    delete[]col_ub2;
    delete[]row_lb2;
    delete[]row_ub2;
}


/**
 * @brief given tooling and SIM usage, construct CL according to the (sim,lambda) benefit
 * 
 * @param CL
 * @param tooling_used
 * @param sim_used
 * @param SIM_number
 * @param sim_lambda_benefit
 */
void
AT::construct_CL( vector < pair < pair < int, int >, double > >&CL, int *tooling_used, int *sim_used, int *SIM_number, vector < pair < double, vec_int > >&sim_lambda_benefit )
{
    // given tooling and SIM usage, construct CL according to the (sim,lambda) benefit
    CL.clear( );
    int index = -1;

    for ( int simid = 1; simid <= ( int ) SIM.size( ); simid++ ) {
        vector < SIM_item >::iterator pSIM = SIM.begin( ) + simid - 1;
        int machine_id = (*pSIM).represented_machine_id;
        vector < int >::iterator p_Lambda = Lambda_i[machine_id].int_vector.begin( );

        while ( p_Lambda != Lambda_i[machine_id].int_vector.end( ) ) {
            int Lambda_id = (*p_Lambda);

            index++;
            if ( sim_lambda_benefit[index].first > 1E-04 ) {

                // append the CL
                pair < pair < int, int >, double >one_pair;

                one_pair.first.first = simid;
                one_pair.first.second = Lambda_id;
                one_pair.second = sim_lambda_benefit[index].first;
                CL.push_back( one_pair );
            }
            p_Lambda++;
        }
    }
    // sort the candidate_list according to the benefit
    // ----------------------------------------------------------------------output the CL
    sort( CL.begin( ), CL.end( ), compare_candidates );
}


/**
 * @brief construct a CL with respect to the machine-lambda combinations
 * 
 * @param CL
 * @param machine_lambda_benefit
 */
void
AT::construct_CL_resetup( vector < pair < pair < int, int >, double > >&CL, vector < pair < double, vec_int > >&machine_lambda_benefit )
{
    // construct a CL with respect to the machine-lambda combinations
    CL.clear( );
    int index = -1;

    for ( int machine_id = 1; machine_id <= ( int ) Machine_vector.size( ); machine_id++ ) {
        vector < int >::iterator p_Lambda = Lambda_i[machine_id].int_vector.begin( );

        while ( p_Lambda != Lambda_i[machine_id].int_vector.end( ) ) {
            int Lambda_id = (*p_Lambda);

            index++;
            if ( machine_lambda_benefit[index].first > 1E-04 ) {

                // append the CL
                pair < pair < int, int >, double >one_pair;

                one_pair.first.first = machine_id;
                one_pair.first.second = Lambda_id;
                one_pair.second = machine_lambda_benefit[index].first;
                CL.push_back( one_pair );
            }
            p_Lambda++;
        }
    }
    // sort the candidate_list according to the benefit
    // ----------------------------------------------------------------------output the CL
    sort( CL.begin( ), CL.end( ), compare_candidates );
}


/**
 * @brief 
 * 
 * @param CL
 * @param alpha
 * @return 
 */
int
AT::construct_RCL( vector < pair < pair < int, int >, double > >&CL, double alpha )
{
    int temp = roundup( alpha );

    if ( ( int ) CL.size( ) < temp ) {
        temp = ( int ) CL.size( );
    }
    return temp;
}


/**
 * @brief 
 */
void
AT::get_tooling_sum_rhs( )
{
    tooling_sum_rhs.clear( );
    for ( int tf = 1; tf <= Num_Tooling_Family; tf++ ) {
        for ( int n = 1; n <= ( int ) Temperature_Set.size( ); n++ ) {
            vector < t_set >::iterator p_set = Temperature_Set.begin( ) + n - 1;
            vector < t_set > inter_set;
            get_inter_set( (*p_set), inter_set );
            vector < t_set >::iterator pm = inter_set.begin( );
            int sum = 0;

            while ( pm != inter_set.end( ) ) {
                int set_id = get_set_id( *pm );
                int pos = tf * Max_Num_Temperature + set_id;

                sum += n_t_n_tooling[pos];
                pm++;
            }
            tooling_sum_rhs.push_back( make_pair( make_pair( tf, n ), sum ) );
        }
    }
}


/**
 * @brief 
 * 
 * @param sim_lambda_benefit
 * @param tooling_used
 * @param sim_used
 * @param SIM_number
 */
void
AT::initialize_benefit( vector < pair < double, vec_int > >&sim_lambda_benefit, int *tooling_used, int *sim_used, int *SIM_number )
{
    cout << "in initialize_benefit" << endl;

    // ---------------------------------------------------------------------------------------------------------for LL (sort all the lots according to their improtance)
    vector < pair < int, double > > LL;

    for ( int l = 1; l <= Num_Lot; l++ ) {
        int d = lots_device[l];
        int type = is_KD_PD( d );

        bool is_kp = is_Key_PKG( d );
        bool is_kpp = is_Key_PIN_PKG( d );
        pair < int, double >one_pair;

        one_pair.first = l;
        one_pair.second = w_l[l];
        if ( type == 1 ) {
            double min = n_l_chips[l];

            if ( min > n_k_minchips[d] ) {
                min = n_k_minchips[d];
            }
            one_pair.second += penalty[d] / coef * min;
        }
        if ( is_kp ) {
            double min = n_l_chips[l];
            int pkg_id = device_PKG[d];

            if ( min > n_kp_minchips[pkg_id] ) {
                min = n_kp_minchips[pkg_id];
            }
            one_pair.second += PKG_penalty[pkg_id] / coef * min;
        }
        if ( is_kpp ) {
            double min = n_l_chips[l];
            int pkg_id = device_PKG[d];
            int pin_num = device_PIN[d];
            int target = 0;

            for ( int id = 1; id <= ( int ) Key_PIN_PKG.size( ); id++ ) {
                if ( Key_PIN_PKG[id - 1].first.first == pin_num && Key_PIN_PKG[id - 1].first.second == pkg_id ) {
                    target = Key_PIN_PKG[id - 1].second;
                    break;
                }
            }
            if ( min > target ) {
                min = target;
            }
            one_pair.second += get_PIN_PKG_penalty( pkg_id, pin_num ) / coef *min;
        }
        LL.push_back( one_pair );
    }
    sort( LL.begin( ), LL.end( ), compare_lot );

    // ------------------------------------------------------------------------------------------------
    sim_lambda_benefit.clear( );
    int index = -1;

    for ( int sim = 1; sim <= ( int ) SIM.size( ); sim++ ) {
        int machine_id = SIM[sim - 1].represented_machine_id;
        vector < int >::iterator p_Lambda = Lambda_i[machine_id].int_vector.begin( );

        while ( p_Lambda != Lambda_i[machine_id].int_vector.end( ) ) {
            int Lambda_id = (*p_Lambda);

            index++;
            pair < double, vec_int > one_pair;


            // ---------------------------------------------------------------------------------------------------------test if sim_lambda is feasible
            int test = is_sim_lambda_feasible( sim, Lambda_id, tooling_used, sim_used, SIM_number );

            if ( !test ) {
                one_pair.first = -1E+6;
                one_pair.second.int_vector.clear( );
                sim_lambda_benefit.push_back( one_pair );
                p_Lambda++;
                continue;
            }

            // ---------------------------------------------------------------------------------------------------------for LLL
            vector < pair < int, double > > LLL;

            for ( int id = 1; id <= ( int ) LL.size( ); id++ ) {
                int l = LL[id - 1].first;

                vii pfind = find( L_sim_lambda[index].second.int_vector.begin( ), L_sim_lambda[index].second.int_vector.end( ), l );
                if ( pfind != L_sim_lambda[index].second.int_vector.end( ) ) {
                    int s = max_rate_s( machine_id, l, Lambda_id );
                    double time_required = n_l_chips[l] / rate[s] + Load_Unload_Time;
                    double ben = LL[id - 1].second / time_required;

                    LLL.push_back( make_pair( l, ben ) );
                }
            }
            sort( LLL.begin( ), LLL.end( ), compare_lot );

            // ---------------------------------------------------------------------------------------------------------for LLL
            vector < int >production( Num_Device, 0 );
            vector < int >PKG_production( ( int ) PKG.size( ), 0 );
            vector < int >PIN_PKG_production( ( int ) PKG.size( ) * ( int ) PIN_order.size( ) + 1, 0 );
            double time_used = 0;
            double sum = 0;

            for ( int id = 1; id <= ( int ) LLL.size( ); id++ ) {
                int l = LLL[id - 1].first;
                int d = lots_device[l];
                int s = max_rate_s( machine_id, l, Lambda_id );
                double time_required = n_l_chips[l] / rate[s] + Load_Unload_Time;

                if ( time_used + time_required <= H[machine_id] ) {
                    time_used += time_required;
                    production[d - 1] += n_l_chips[l];
                    int pkg_id = device_PKG[d];
                    int pin_num = device_PIN[d];

                    PKG_production[pkg_id - 1] += n_l_chips[l];
                    vii pfind = find( PIN_order.begin( ), PIN_order.end( ), pin_num );
                    int pin_order = pfind - PIN_order.begin( ) + 1;
                    int pin_pkg_index = (pkg_id - 1) * ( int ) PIN_order.size( ) + pin_order - 1;

                    PIN_PKG_production[pin_pkg_index] += n_l_chips[l];
                    int target = 0;

                    for ( int id2 = 1; id2 <= ( int ) Key_PIN_PKG.size( ); id2++ ) {
                        if ( Key_PIN_PKG[id2 - 1].first.first == pin_num && Key_PIN_PKG[id2 - 1].first.second == pkg_id ) {
                            target = Key_PIN_PKG[id2 - 1].second;
                            break;
                        }
                    }
                    sum += LLL[id - 1].second * time_required;
                    one_pair.second.int_vector.push_back( l );

                    // ------------------------------------------------update and sort
                    int type = is_KD_PD( d );

                    bool is_kp = is_Key_PKG( d );
                    bool is_kpp = is_Key_PIN_PKG( d );
                    if ( type == 1 || is_kp || is_kpp ) {
                        bool flag = false;
                        for ( int id2 = id + 1; id2 <= ( int ) LLL.size( ); id2++ ) {
                            int l2 = LLL[id2 - 1].first;
                            int d2 = lots_device[l2];
                            int s2 = max_rate_s( machine_id, l2, Lambda_id );
                            double time2 = n_l_chips[l2] / rate[s2] + Load_Unload_Time;

                            LLL[id2 - 1].second = w_l[l2] / time2;
                            if ( type == 1 && d2 == d ) {
                                if ( production[d - 1] < n_k_minchips[d] ) {
                                    int diff = n_k_minchips[d] - production[d - 1];

                                    if ( diff < n_l_chips[l2] ) {
                                        LLL[id2 - 1].second += (penalty[d2] / coef * diff) / time2;
                                    } else {
                                        LLL[id2 - 1].second += (penalty[d2] / coef * n_l_chips[l2]) / time2;
                                    }
                                    flag = true;
                                }
                            }
                            if ( is_kp && pkg_id == device_PKG[d2] ) {
                                if ( PKG_production[pkg_id - 1] < n_kp_minchips[pkg_id] ) {
                                    int diff = n_kp_minchips[pkg_id] - PKG_production[pkg_id - 1];

                                    if ( diff < n_l_chips[l2] ) {
                                        LLL[id2 - 1].second += (PKG_penalty[pkg_id] / coef * diff) / time2;
                                    } else {
                                        LLL[id2 - 1].second += (PKG_penalty[pkg_id] / coef * n_l_chips[l2]) / time2;
                                    }
                                    flag = true;
                                }
                            }
                            if ( is_kpp && pkg_id == device_PKG[d2] && pin_num == device_PIN[d2] ) {
                                if ( PIN_PKG_production[pin_pkg_index] < target ) {
                                    int diff = target - PIN_PKG_production[pin_pkg_index];

                                    if ( diff < n_l_chips[l2] ) {
                                        LLL[id2 - 1].second += (get_PIN_PKG_penalty( pkg_id, pin_num ) / coef * diff) / time2;
                                    } else {
                                        LLL[id2 - 1].second += (get_PIN_PKG_penalty( pkg_id, pin_num ) / coef * n_l_chips[l2]) / time2;
                                    }
                                    flag = true;
                                }
                            }
                        }
                        if ( flag ) {
                            sort( LLL.begin( ) + id, LLL.end( ), compare_lot );
                        }
                    }
                } // end_if
            }
            one_pair.first = sum;
            sim_lambda_benefit.push_back( one_pair );
            p_Lambda++;
        }
    }
}


/**
 * @brief the vector \<sim_lambda_benefit> was built by initialize_benefit().
 * 
 * the vector \<sim_lambda_benefit> was built by initialize_benefit(). Note that infeasible setup is also included in the vector. The vector is of the same size as \<L_sim_lambda>
 * the values in \<sim_lambda_benefit> are never used in the right hand side of =. That is, it is fine to use a \<sim_lambda_benefit> with all 0 benefits (This statement is for AT enhancement.)
 *
 *  * @param sim_lambda_benefit
 * @param lot_remain
 * @param production
 * @param affected_dev
 * @param tooling_used
 * @param sim_used
 * @param SIM_number
 */
void
AT::update_benefit( vector < pair < double, vec_int > >&sim_lambda_benefit, vector < int >&lot_remain, vector < int >&production, vector < int >&affected_dev, int *tooling_used, int *sim_used, int *SIM_number )
{
    // the vector <sim_lambda_benefit> was built by initialize_benefit(). Note that infeasible setup is also included in the vector. The vector is of the same size as <L_sim_lambda>
    // the values in <sim_lambda_benefit> are never used in the right hand side of =. That is, it is fine to use a <sim_lambda_benefit> with all 0 benefits (This statement is for AT enhancement.)
    int index = -1;


    // ------------copy production
    cout << "copy production" << endl;
    vector < int >prod( ( int ) production.size( ), 0 );

    copy( production.begin( ), production.end( ), prod.begin( ) );
    vector < int >PKG_production_save( ( int ) PKG.size( ), 0 );
    vector < int >PIN_PKG_production_save( ( int ) PKG.size( ) * ( int ) PIN_order.size( ) + 1, 0 );

    for ( int d = 1; d <= Num_Device; d++ ) {
        int pkg_id = device_PKG[d];
        int pin_num = device_PIN[d];

        vii pfind = find( PIN_order.begin( ), PIN_order.end( ), pin_num );
        int pin_order = pfind - PIN_order.begin( ) + 1;
        int index = (pkg_id - 1) * ( int ) PIN_order.size( ) + pin_order - 1;

        PKG_production_save[pkg_id - 1] += prod[d - 1];
        PIN_PKG_production_save[index] += prod[d - 1];
    }
    // ---------------------------------------------------------------------------------------------------------for LL
    cout << "initialize LL" << endl;
    vector < pair < int, double > > LL; // <lot_id, benefit>

    for ( int id = 1; id <= ( int ) lot_remain.size( ); id++ ) {

        // for each remaining lot,compute the corresponding benefit based on current production
        int l = lot_remain[id - 1];
        int d = lots_device[l];
        int type = is_KD_PD( d );
        int pkg_id = device_PKG[d];
        int pin_num = device_PIN[d];

        bool is_kp = is_Key_PKG( d );
        bool is_kpp = is_Key_PIN_PKG( d );
        pair < int, double >one_pair;

        one_pair.first = l;
        one_pair.second = w_l[l];
        if ( type == 1 && prod[d - 1] < n_k_minchips[d] ) { // if the device is a key device,need to compute the reduction of penalty
            int min = n_l_chips[l];

            if ( min > n_k_minchips[d] - prod[d - 1] ) {
                min = n_k_minchips[d] - prod[d - 1];
            }
            one_pair.second += penalty[d] / coef * min;
        } else if ( type == 2 && prod[d - 1] < n_p_minchips[d] ) { // if the device is a package device (this is not used anymore)
            int min = n_l_chips[l];

            if ( min > n_p_minchips[d] - prod[d - 1] ) {
                min = n_p_minchips[d] - prod[d - 1];
            }
            one_pair.second += penalty[d] / coef * min;
        }
        if ( is_kp && PKG_production_save[pkg_id - 1] < n_kp_minchips[pkg_id] ) { // if the device contains a key package
            int diff = n_kp_minchips[pkg_id] - PKG_production_save[pkg_id - 1];
            int min = n_l_chips[l];

            if ( min > diff ) {
                min = diff;
            }
            one_pair.second += PKG_penalty[pkg_id] / coef * min;
        }
        int target = 0;

        for ( int id2 = 1; id2 <= ( int ) Key_PIN_PKG.size( ); id2++ ) {
            if ( Key_PIN_PKG[id2 - 1].first.first == pin_num && Key_PIN_PKG[id2 - 1].first.second == pkg_id ) {
                target = Key_PIN_PKG[id2 - 1].second;
                break;
            }
        }
        vii pfind = find( PIN_order.begin( ), PIN_order.end( ), pin_num );
        int pin_order = pfind - PIN_order.begin( ) + 1;
        int index = (pkg_id - 1) * ( int ) PIN_order.size( ) + pin_order - 1;

        if ( is_kpp && PIN_PKG_production_save[index] < target ) {
            int diff = target - PIN_PKG_production_save[index];
            int min = n_l_chips[l];

            if ( min > diff ) {
                min = diff;
            }
            one_pair.second += get_PIN_PKG_penalty( pkg_id, pin_num ) / coef *min;
        }
        LL.push_back( one_pair );
    }
    sort( LL.begin( ), LL.end( ), compare_lot ); // the remaining lots are sorted according to the benefits
    // ------------------------------------------------------------------------------------------------
    cout << "update the sim_lambda_benefit" << endl;
    int count = 0;
    int count_limit = 1E+6;

    index = -1;
    for ( int sim = 1; sim <= ( int ) SIM.size( ); sim++ ) {
        int machine_id = SIM[sim - 1].represented_machine_id;
        vector < int >::iterator p_Lambda = Lambda_i[machine_id].int_vector.begin( );

        while ( p_Lambda != Lambda_i[machine_id].int_vector.end( ) ) {

            // for each SIM-Lambda combination,update the corresponding benefit can be obtained
            int Lambda_id = (*p_Lambda);

            index++;
            count++;

            // some initial test to save effeor
            // --------------------------------------------------------------------------------------------
            if ( sim_lambda_benefit[index].first < 0 ) { // previosly infeasible or non-benefitial setup
                p_Lambda++;
                continue;
            }

            // ---------------------------------------------------------------------------------------------------------test if sim_lambda is feasible
            int test = is_sim_lambda_feasible( sim, Lambda_id, tooling_used, sim_used, SIM_number );

            if ( !test ) {
                sim_lambda_benefit[index].first = -1E+6;
                sim_lambda_benefit[index].second.int_vector.clear( );
                p_Lambda++;
                continue;
            }
            copy( production.begin( ), production.end( ), prod.begin( ) );
            vector < int >PKG_production( ( int ) PKG.size( ), 0 );
            vector < int >PIN_PKG_production( ( int ) PKG.size( ) * ( int ) PIN_order.size( ) + 1, 0 );

            copy( PKG_production_save.begin( ), PKG_production_save.end( ), PKG_production.begin( ) );
            copy( PIN_PKG_production_save.begin( ), PIN_PKG_production_save.end( ), PIN_PKG_production.begin( ) );

            // --------------------------------------------------------if affected, clear
            sim_lambda_benefit[index].second.int_vector.clear( );
            sim_lambda_benefit[index].first = 0;

            // ---------------------------------------------------------------------------------------------------------for LLL
            vector < pair < int, double > > LLL;

            for ( int id = 1; id <= ( int ) LL.size( ); id++ ) {
                int l = LL[id - 1].first;

                vii pfind = find( L_sim_lambda[index].second.int_vector.begin( ), L_sim_lambda[index].second.int_vector.end( ), l ); // index also can be used in L_sim_lambda[]
                if ( pfind != L_sim_lambda[index].second.int_vector.end( ) ) {

                    // only consider the lots that can be processed by the given SIM-Lambda combination
                    int s = max_rate_s( machine_id, l, Lambda_id );
                    double time_required = n_l_chips[l] / rate[s] + Load_Unload_Time;
                    double ben = LL[id - 1].second / time_required; // compute the benefit gained in each time unit

                    LLL.push_back( make_pair( l, ben ) );
                }
            }
            sort( LLL.begin( ), LLL.end( ), compare_lot );

            // ---------------------------------------------------------------------------------------------------------for LLL
            double sum = 0;
            double time_used = 0;

            for ( int id = 1; id <= ( int ) LLL.size( ); id++ ) {
                int l = LLL[id - 1].first;
                int d = lots_device[l];
                int s = max_rate_s( machine_id, l, Lambda_id );
                double time_required = n_l_chips[l] / rate[s] + Load_Unload_Time;

                if ( time_used + time_required <= H[machine_id] ) {
                    time_used += time_required;
                    sum += LLL[id - 1].second * time_required;
                    sim_lambda_benefit[index].second.int_vector.push_back( l );
                    prod[d - 1] += n_l_chips[l];
                    int pkg_id = device_PKG[d];
                    int pin_num = device_PIN[d];

                    PKG_production[pkg_id - 1] += n_l_chips[l];
                    vii pfind = find( PIN_order.begin( ), PIN_order.end( ), pin_num );
                    int pin_order = pfind - PIN_order.begin( ) + 1;
                    int pin_pkg_index = (pkg_id - 1) * ( int ) PIN_order.size( ) + pin_order - 1;

                    PIN_PKG_production[pin_pkg_index] += n_l_chips[l];
                    int target = 0;

                    for ( int id2 = 1; id2 <= ( int ) Key_PIN_PKG.size( ); id2++ ) {
                        if ( Key_PIN_PKG[id2 - 1].first.first == pin_num && Key_PIN_PKG[id2 - 1].first.second == pkg_id ) {
                            target = Key_PIN_PKG[id2 - 1].second;
                            break;
                        }
                    }

                    // ------------------------------------------------update and sort, since the first lot is selected, the rest of the lots need to be sorted again!!!
                    int type = is_KD_PD( d );

                    bool is_kp = is_Key_PKG( d );
                    bool is_kpp = is_Key_PIN_PKG( d );
                    if ( type == 1 || is_kp || is_kpp ) {
                        bool flag = false;
                        for ( int id2 = id + 1; id2 <= ( int ) LLL.size( ); id2++ ) {
                            int l2 = LLL[id2 - 1].first;
                            int d2 = lots_device[l2];
                            int s2 = max_rate_s( machine_id, l2, Lambda_id );
                            double time2 = n_l_chips[l2] / rate[s2] + Load_Unload_Time;

                            LLL[id2 - 1].second = w_l[l2] / time2;
                            if ( type == 1 && d2 == d ) {

                                // if the lot under investigation contains the same key device
                                // then the original benefit should be updated b/c a lot has been selected
                                if ( production[d - 1] < n_k_minchips[d] ) {
                                    int diff = n_k_minchips[d] - production[d - 1];

                                    if ( diff < n_l_chips[l2] ) {
                                        LLL[id2 - 1].second += (penalty[d2] / coef * diff) / time2;
                                    } else {
                                        LLL[id2 - 1].second += (penalty[d2] / coef * n_l_chips[l2]) / time2;
                                    }
                                    flag = true;
                                }
                            }
                            if ( is_kp && pkg_id == device_PKG[d2] ) {
                                if ( PKG_production[pkg_id - 1] < n_kp_minchips[pkg_id] ) {
                                    int diff = n_kp_minchips[pkg_id] - PKG_production[pkg_id - 1];

                                    if ( diff < n_l_chips[l2] ) {
                                        LLL[id2 - 1].second += (PKG_penalty[pkg_id] / coef * diff) / time2;
                                    } else {
                                        LLL[id2 - 1].second += (PKG_penalty[pkg_id] / coef * n_l_chips[l2]) / time2;
                                    }
                                    flag = true;
                                }
                            }
                            if ( is_kpp && pkg_id == device_PKG[d2] && pin_num == device_PIN[d2] ) {
                                if ( PIN_PKG_production[pin_pkg_index] < target ) {
                                    int diff = target - PIN_PKG_production[pin_pkg_index];

                                    if ( diff < n_l_chips[l2] ) {
                                        LLL[id2 - 1].second += (get_PIN_PKG_penalty( pkg_id, pin_num ) / coef * diff) / time2;
                                    } else {
                                        LLL[id2 - 1].second += (get_PIN_PKG_penalty( pkg_id, pin_num ) / coef * n_l_chips[l2]) / time2;
                                    }
                                    flag = true;
                                }
                            }
                        }
                        if ( flag ) {
                            sort( LLL.begin( ) + id, LLL.end( ), compare_lot );
                        }

                        // ------------------------------------------------------------------------------------
                    }
                }
            }
            sim_lambda_benefit[index].first = sum;
            p_Lambda++;
            if ( count > count_limit ) {
                break;
            }
        }
        if ( count > count_limit ) {
            break;
        }
    }
}


/**
 * @brief instead of update the benefit according to sim-lambda combination, it is necessary to use machine-lambda combination because at this point    machines in the sim are not identical anymore due the different H[]
 * 
 * instead of update the benefit according to sim-lambda combination, it is necessary to use machine-lambda combination because at this point
 * machines in the sim are not identical anymore due the different H[]
 * the values in \<machine_lambda_benefit> are never used in the right hand side of =. Thus the \<machine_lambda_benefit> will not affect the values of other variables. That is, it is fine to use a \<machine_lambda_benefit> with all 0 benefits (This statement is for AT enhancement.)
 * 
 * @param current_machine
 * @param current_Lambda
 * @param current_time
 * @param machine_lambda_benefit
 * @param lot_remain
 * @param production
 * @param affected_dev
 * @param tooling_used
 * @param sim_used
 * @param SIM_number
 * @param idle_machines
 */
void
AT::update_benefit_resetup( int current_machine, int current_Lambda, double current_time, vector < pair < double, vec_int > >&machine_lambda_benefit, vector < int >&lot_remain, vector < int >&production, vector < int >&affected_dev, int *tooling_used,
                            int *sim_used, int *SIM_number, vector < int >&idle_machines )
{
    // instead of update the benefit according to sim-lambda combination, it is necessary to use machine-lambda combination because at this point
    // machines in the sim are not identical anymore due the different H[]
    // the values in <machine_lambda_benefit> are never used in the right hand side of =. Thus the <machine_lambda_benefit> will not affect the values of other variables. That is, it is fine to use a <machine_lambda_benefit> with all 0 benefits (This statement is for AT enhancement.)
    int index = -1;


    // ------------copy production for the devices
    vector < int >prod( ( int ) production.size( ), 0 );

    copy( production.begin( ), production.end( ), prod.begin( ) );

    // --------------------------------------------------------compute the production for package and pin package
    vector < int >PKG_production_save( ( int ) PKG.size( ), 0 );
    vector < int >PIN_PKG_production_save( ( int ) PKG.size( ) * ( int ) PIN_order.size( ) + 1, 0 );

    for ( int d = 1; d <= Num_Device; d++ ) {
        int pkg_id = device_PKG[d];
        int pin_num = device_PIN[d];

        vii pfind = find( PIN_order.begin( ), PIN_order.end( ), pin_num );
        int pin_order = pfind - PIN_order.begin( ) + 1;
        int index = (pkg_id - 1) * ( int ) PIN_order.size( ) + pin_order - 1;

        PKG_production_save[pkg_id - 1] += prod[d - 1];
        PIN_PKG_production_save[index] += prod[d - 1];
    }
    // ---------------------------------------------------------------------------------------------------------for LL
    // This segment of code sorts the remaining lots according to their benefit
    vector < pair < int, double > > LL;

    for ( int id = 1; id <= ( int ) lot_remain.size( ); id++ ) {
        int l = lot_remain[id - 1];
        int d = lots_device[l];
        int type = is_KD_PD( d );
        int pkg_id = device_PKG[d];
        int pin_num = device_PIN[d];

        bool is_kp = is_Key_PKG( d );
        bool is_kpp = is_Key_PIN_PKG( d );
        pair < int, double >one_pair;

        one_pair.first = l;
        one_pair.second = w_l[l];
        if ( type == 1 && prod[d - 1] < n_k_minchips[d] ) {
            int min = n_l_chips[l];

            if ( min > n_k_minchips[d] - prod[d - 1] ) {
                min = n_k_minchips[d] - prod[d - 1];
            }
            one_pair.second += penalty[d] / coef * min;
        } else if ( type == 2 && prod[d - 1] < n_p_minchips[d] ) {
            int min = n_l_chips[l];

            if ( min > n_p_minchips[d] - prod[d - 1] ) {
                min = n_p_minchips[d] - prod[d - 1];
            }
            one_pair.second += penalty[d] / coef * min;
        }
        if ( is_kp && PKG_production_save[pkg_id - 1] < n_kp_minchips[pkg_id] ) {
            int diff = n_kp_minchips[pkg_id] - PKG_production_save[pkg_id - 1];
            int min = n_l_chips[l];

            if ( min > diff ) {
                min = diff;
            }
            one_pair.second += PKG_penalty[pkg_id] / coef * min;
        }
        int target = 0;

        for ( int id2 = 1; id2 <= ( int ) Key_PIN_PKG.size( ); id2++ ) {
            if ( Key_PIN_PKG[id2 - 1].first.first == pin_num && Key_PIN_PKG[id2 - 1].first.second == pkg_id ) {
                target = Key_PIN_PKG[id2 - 1].second;
                break;
            }
        }
        vii pfind = find( PIN_order.begin( ), PIN_order.end( ), pin_num );
        int pin_order = pfind - PIN_order.begin( ) + 1;
        int index = (pkg_id - 1) * ( int ) PIN_order.size( ) + pin_order - 1;

        if ( is_kpp && PIN_PKG_production_save[index] < target ) {
            int diff = target - PIN_PKG_production_save[index];
            int min = n_l_chips[l];

            if ( min > diff ) {
                min = diff;
            }
            one_pair.second += get_PIN_PKG_penalty( pkg_id, pin_num ) / coef *min;
        }
        LL.push_back( one_pair );
    }
    sort( LL.begin( ), LL.end( ), compare_lot ); // the remaining lots are sorted according to the benefits
    // ------------------------------------------------------------------------------------------------
    // The following segment of code iterats over all machine-lambda combinations. For each iteration,lots are picked from the sorted LL and assigned to the
    // selected machine-lambda combination. Once a lot is selcted and assigned,the benefit of the remaining lots need to be updated accordingly.Thus an updating
    // procedure need to be applied each time a lot is assigned. This reupdate costs a lot of computational time.
    // In the case of resetup machines,change over setup time will be caused for each resetup, except the situation that the machine-lambda under investigation
    // is the current machine-lambda combination. That is, it is not necessary to change the tooling setup for the current machine.
    // Once change over time is incured,the available machine time H[] is reduced by the same amount of time.
    int count = 0;
    int count_limit = 1E+6;

    index = -1;
    for ( int machine_id = 1; machine_id <= ( int ) Machine_vector.size( ); machine_id++ ) {

        // test if the machine_id is idle (available or not)
        vii pfind = find( idle_machines.begin( ), idle_machines.end( ), machine_id );
        bool machine_idle_flag = true;
        if ( pfind == idle_machines.end( ) ) { // machine_id is NOT idle
            machine_idle_flag = false;
        }
        int sim = machine_sim[machine_id];
        vector < int >::iterator p_Lambda = Lambda_i[machine_id].int_vector.begin( );

        while ( p_Lambda != Lambda_i[machine_id].int_vector.end( ) ) {

            // the inner loop for each machine-lambda combination
            int Lambda_id = (*p_Lambda);


            // ---------------------------------------------------compute the resetup time
            double resetup_time = 0;

            if ( machine_id != current_machine || Lambda_id != current_Lambda ) { // unmatched machine or unmatch Lambda_id
                vector < Lambda_item >::iterator pL = Lambda.begin( ) + Lambda_id - 1;
                for ( int j = 1; j <= ( int ) (*pL).tooling_vec.size( ); j++ ) {
                    int tf = (*pL).tooling_vec[j - 1];

                    resetup_time += Tooling_Setup_Time[tf];
                }
            }
            index++;
            count++;

            // --------------------------------------------------------------------------------------------
            if ( machine_lambda_benefit[index].first < 0 ) { // previosly infeasible or non-benefitial setup
                p_Lambda++;
                continue;
            }

            // -----------------------------------------------------------------------------------------------test if machine_lambda is feasible
            int test = is_sim_lambda_feasible( sim, Lambda_id, tooling_used, sim_used, SIM_number );

            if ( !test || !machine_idle_flag ) { // if the machine-lambda is infeasible
                machine_lambda_benefit[index].first = -1E+6;
                machine_lambda_benefit[index].second.int_vector.clear( );
                p_Lambda++;
                continue;
            }

            // -------------------------------------------------------------------------------if the current_time plus setup time exceed the horizon, then it is not interesed to resetup
            if ( current_time + resetup_time > H[machine_id] ) {
                p_Lambda++;
                continue;
            }

            // --------------------------------------------------------------------------
            // upto this point,the machine-lambda is feasible and should be investigated
            // ---------------------------------------------------------------make a copy of the production such that it will not be destroyed
            copy( production.begin( ), production.end( ), prod.begin( ) );
            vector < int >PKG_production( ( int ) PKG.size( ), 0 );
            vector < int >PIN_PKG_production( ( int ) PKG.size( ) * ( int ) PIN_order.size( ) + 1, 0 );

            copy( PKG_production_save.begin( ), PKG_production_save.end( ), PKG_production.begin( ) );
            copy( PIN_PKG_production_save.begin( ), PIN_PKG_production_save.end( ), PIN_PKG_production.begin( ) );

            // ---------------------------------------------------------------------------------------------------------check if affected dev
            // --------------------------------------------------------if affected, clear
            machine_lambda_benefit[index].second.int_vector.clear( );
            machine_lambda_benefit[index].first = 0;

            // ---------------------------------------------------------------------------------------------------------for LLL
            vector < pair < int, double > > LLL;

            for ( int id = 1; id <= ( int ) LL.size( ); id++ ) {
                int l = LL[id - 1].first;
                int pos = index_L_sim_lambda( sim, Lambda_id );

                vii pfind = find( L_sim_lambda[pos].second.int_vector.begin( ), L_sim_lambda[pos].second.int_vector.end( ), l );
                if ( pfind != L_sim_lambda[pos].second.int_vector.end( ) ) {
                    int s = max_rate_s( machine_id, l, Lambda_id );
                    double time_required = n_l_chips[l] / rate[s] + Load_Unload_Time;
                    double ben = LL[id - 1].second / time_required;

                    LLL.push_back( make_pair( l, ben ) );
                }
            }
            sort( LLL.begin( ), LLL.end( ), compare_lot );

            // ---------------------------------------------------------------------------------------------------------for LLL
            double sum = 0;
            double time_used = current_time + resetup_time; // if the resetup costs time, it should be taken into accout in the time used

            for ( int id = 1; id <= ( int ) LLL.size( ); id++ ) {
                int l = LLL[id - 1].first;
                int d = lots_device[l];
				//added by Mark G
				if(id > 2){
					int l2 = LLL[id - 2].first;
					int d2 = lots_device[l2];
					
					if(PKG[device_PKG[d2]-1]==PKG[device_PKG[d]-1]){
						time_used = 8;	//replaces 2.5 hours if pkg of lot is different from last lot
										//Hard coded for now. will be revised to "pkg_setup_time" variable once input.txt is fixed
					}
				}
				//end
                int s = max_rate_s( machine_id, l, Lambda_id );
                double time_required = n_l_chips[l] / rate[s] + Load_Unload_Time;
				

                if ( time_used + time_required <= H[machine_id] ) {
                    time_used += time_required;
                    sum += LLL[id - 1].second * time_required;
                    machine_lambda_benefit[index].second.int_vector.push_back( l );
                    prod[d - 1] += n_l_chips[l];
                    int pkg_id = device_PKG[d];
                    int pin_num = device_PIN[d];

                    PKG_production[pkg_id - 1] += n_l_chips[l];
                    vii pfind = find( PIN_order.begin( ), PIN_order.end( ), pin_num );
                    int pin_order = pfind - PIN_order.begin( ) + 1;
                    int pin_pkg_index = (pkg_id - 1) * ( int ) PIN_order.size( ) + pin_order - 1;

                    PIN_PKG_production[pin_pkg_index] += n_l_chips[l];
                    int target = 0;

                    for ( int id2 = 1; id2 <= ( int ) Key_PIN_PKG.size( ); id2++ ) {
                        if ( Key_PIN_PKG[id2 - 1].first.first == pin_num && Key_PIN_PKG[id2 - 1].first.second == pkg_id ) {
                            target = Key_PIN_PKG[id2 - 1].second;
                            break;
                        }
                    }

                    // ------------------------------------------------update and sort, since the first lot is selected, the rest of the lots need to be sorted again!!!
                    int type = is_KD_PD( d );

                    bool is_kp = is_Key_PKG( d );
                    bool is_kpp = is_Key_PIN_PKG( d );
                    if ( type == 1 || is_kp || is_kpp ) {
                        bool flag = false;
                        for ( int id2 = id + 1; id2 <= ( int ) LLL.size( ); id2++ ) {
                            int l2 = LLL[id2 - 1].first;
                            int d2 = lots_device[l2];
                            int s2 = max_rate_s( machine_id, l2, Lambda_id );
                            double time2 = n_l_chips[l2] / rate[s2] + Load_Unload_Time;

                            LLL[id2 - 1].second = w_l[l2] / time2;
                            if ( type == 1 && d2 == d ) {
                                if ( production[d - 1] < n_k_minchips[d] ) {
                                    int diff = n_k_minchips[d] - production[d - 1];

                                    if ( diff < n_l_chips[l2] ) {
                                        LLL[id2 - 1].second += (penalty[d2] / coef * diff) / time2;
                                    } else {
                                        LLL[id2 - 1].second += (penalty[d2] / coef * n_l_chips[l2]) / time2;
                                    }
                                    flag = true;
                                }
                            }
                            if ( is_kp && pkg_id == device_PKG[d2] ) {
                                if ( PKG_production[pkg_id - 1] < n_kp_minchips[pkg_id] ) {
                                    int diff = n_kp_minchips[pkg_id] - PKG_production[pkg_id - 1];

                                    if ( diff < n_l_chips[l2] ) {
                                        LLL[id2 - 1].second += (PKG_penalty[pkg_id] / coef * diff) / time2;
                                    } else {
                                        LLL[id2 - 1].second += (PKG_penalty[pkg_id] / coef * n_l_chips[l2]) / time2;
                                    }
                                    flag = true;
                                }
                            }
                            if ( is_kpp && pkg_id == device_PKG[d2] && pin_num == device_PIN[d2] ) {
                                if ( PIN_PKG_production[pin_pkg_index] < target ) {
                                    int diff = target - PIN_PKG_production[pin_pkg_index];

                                    if ( diff < n_l_chips[l2] ) {
                                        LLL[id2 - 1].second += (get_PIN_PKG_penalty( pkg_id, pin_num ) / coef * diff) / time2;
                                    } else {
                                        LLL[id2 - 1].second += (get_PIN_PKG_penalty( pkg_id, pin_num ) / coef * n_l_chips[l2]) / time2;
                                    }
                                    flag = true;
                                }
                            }
                        }
                        if ( flag ) {
                            sort( LLL.begin( ) + id, LLL.end( ), compare_lot );
                        }

                        // ------------------------------------------------------------------------------------
                    }
                }
            }
            machine_lambda_benefit[index].first = sum;
            p_Lambda++;
            if ( count > count_limit ) {
                break;
            }
        }
        if ( count > count_limit ) {
            break;
        }
    }
}


/**
 * @brief 
 */
void
AT::initialize_L_sim_lambda( )
{
    L_sim_lambda.clear( );
    for ( int sim = 1; sim <= ( int ) SIM.size( ); sim++ ) {
        int i = SIM[sim - 1].represented_machine_id;
        vector < int >::iterator p_Lambda = Lambda_i[i].int_vector.begin( );

        while ( p_Lambda != Lambda_i[i].int_vector.end( ) ) {
            int Lambda_id = (*p_Lambda);
            vector < int >LS;

            get_L_i_lambda( LS, i, Lambda_id );
            pair < pair < int, int >, vec_int > one_pair;

            one_pair.first.first = sim;
            one_pair.first.second = Lambda_id;
            one_pair.second.int_vector.resize( ( int ) LS.size( ) );
            copy( LS.begin( ), LS.end( ), one_pair.second.int_vector.begin( ) );
            L_sim_lambda.push_back( one_pair );
            p_Lambda++;
        }
    }
}


/**
 * @brief 
 */
void
AT::show_L_sim_lambda( )
{
    ofstream fdebug_L_i_lambda( "Debug/debug_L_sim_lambda.txt" );
    vector < pair < pair < int, int >, vec_int > >::iterator pLS = L_sim_lambda.begin( );

    while ( pLS != L_sim_lambda.end( ) ) {
        fdebug_L_i_lambda << "sim=" << (*pLS).first.first << ",Lambda_id=" << (*pLS).first.second << ",lots:";
        vii p_lot = (*pLS).second.int_vector.begin( );
        while ( p_lot != (*pLS).second.int_vector.end( ) ) {
            fdebug_L_i_lambda << (*p_lot) << ",";
            p_lot++;
        }
        fdebug_L_i_lambda << endl;
        pLS++;
    }
    fdebug_L_i_lambda.close( );
}


/**
 * @brief 
 * 
 * @param solution
 * @param sub_soln
 * @param shortage
 * @param unassigned_lots
 * @param option
 * 
 * @return 
 */
double
AT::second_level_heuristic( double *solution, vector < sub_soln_item > &sub_soln, vector < pair < int, double > >&shortage, vector < pair < pair < int, double >, double > >&unassigned_lots, int option )
{
    // given the LP solution
    // initialize sub_soln
    // < < <i,Lambda_id>,time_used>,lot1,lot2,...>
    for ( int i = 1; i <= Num_Machine; i++ ) {
        sub_soln_item one_item;
        one_item.i = i;
        one_item.Lambda_id = -1;
        one_item.time_used = 0.0;
        sub_soln.push_back( one_item );
    }
    // initialize assigned_lots and shortage
    vector < int >assigned_lots;

    for ( int d = 1; d <= Num_Device; d++ ) {
        vii pfind = find( Key_Devices.begin( ), Key_Devices.end( ), d );
        if ( pfind != Key_Devices.end( ) ) { // d is a key device
            shortage.push_back( make_pair( d, n_k_minchips[d] ) );
        } else {
            vii pfind = find( Packages.begin( ), Packages.end( ), d );
            if ( pfind != Packages.end( ) ) { // d is a package device
                shortage.push_back( make_pair( d, n_p_minchips[d] ) );
            } else { // d is neither a key nor package device
                shortage.push_back( make_pair( d, -1E+10 ) );
            }
        }
    }

    // construct sub_soln,assigned_lots,and shortage
    for ( int id = 0; id <= x_limit; id++ ) {
        if ( solution[id] > 1.0 - 1E-06 ) {
            vector < index_node >::iterator p_node = index_vector.begin( ) + id;
            int l = (*p_node).l;
            int i = (*p_node).i;
            int s = (*p_node).s;

            sub_soln[i - 1].lots.int_vector.push_back( l );
            sub_soln[i - 1].time_used += n_l_chips[l] / rate[s] + Load_Unload_Time;
            assigned_lots.push_back( l );
            int dev = lots_device[l];

            shortage[dev - 1].second -= n_l_chips[l];
        }
    }
    for ( int id = x_limit + Num_Keydevice + Num_Package + ( int ) Key_PKG.size( ) +( int ) Key_PIN_PKG.size( ) + 1; id <= y_limit; id++ ) {
        if ( solution[id] > 1.0 - 1E-06 ) {
            vector < index_node >::iterator p_node = index_vector.begin( ) + id;
            int i = (*p_node).i;
            int Lambda_id = (*p_node).Lambda_id;

            sub_soln[i - 1].Lambda_id = Lambda_id;
        }
    }
    // get the KP and KPP production
    vector < int >PKG_production( ( int ) PKG.size( ), 0 );
    vector < int >PIN_PKG_production( ( int ) PKG.size( ) * ( int ) PIN_order.size( ) + 1, 0 );

    for ( int id = 1; id <= ( int ) assigned_lots.size( ); id++ ) {
        int l = assigned_lots[id - 1];
        int d = lots_device[l];
        int pkg_id = device_PKG[d];
        int pin_num = device_PIN[d];

        vii pfind = find( PIN_order.begin( ), PIN_order.end( ), pin_num );
        int pin_order = pfind - PIN_order.begin( ) + 1;
        int index = (pkg_id - 1) * ( int ) PIN_order.size( ) + pin_order - 1;

        PKG_production[pkg_id - 1] += n_l_chips[l];
        PIN_PKG_production[index] += n_l_chips[l];
    }
    // initialze and construct unassigned_lots
    // <<lot,contribution>,unit_price>
    unassigned_lots.resize( Num_Lot );
    for ( int l = 1; l <= Num_Lot; l++ ) {
        unassigned_lots[l - 1].first.first = l;
        unassigned_lots[l - 1].first.second = w_l[l];
        unassigned_lots[l - 1].second = w_l[l] / n_l_chips[l];
    }
    vector < pair < pair < int, double >, double > > ::iterator p_lot = unassigned_lots.begin( );

    while ( p_lot != unassigned_lots.end( ) ) {
        int l = (*p_lot).first.first;

        vii pfind = find( assigned_lots.begin( ), assigned_lots.end( ), l );
        if ( pfind != assigned_lots.end( ) ) {
            p_lot = unassigned_lots.erase( p_lot );
        } else {
            int dev = lots_device[l];

            bool is_kp = is_Key_PKG( dev );
            bool is_kpp = is_Key_PIN_PKG( dev );
            int pkg_id = device_PKG[dev];
            int pin_num = device_PIN[dev];

            vii pfind = find( PIN_order.begin( ), PIN_order.end( ), pin_num );
            int pin_order = pfind - PIN_order.begin( ) + 1;
            int index = (pkg_id - 1) * ( int ) PIN_order.size( ) + pin_order - 1;
            int min = shortage[dev - 1].second;

            if ( min > n_l_chips[l] ) {
                min = n_l_chips[l];
            }
            if ( min > 0 ) {
                (*p_lot).first.second += penalty[dev] / coef * min;
                (*p_lot).second += penalty[dev] / coef * min / n_l_chips[l];
            }
            if ( is_kp ) {
                int diff = n_kp_minchips[pkg_id] - PKG_production[pkg_id - 1];
                int min = diff;

                if ( min > n_l_chips[l] ) {
                    min = n_l_chips[l];
                }
                if ( min > 0 ) {
                    (*p_lot).first.second += PKG_penalty[pkg_id] / coef * min;
                    (*p_lot).second += PKG_penalty[pkg_id] / coef * min / n_l_chips[l];
                }
            }
            if ( is_kpp ) {
                int target = 0;

                for ( int id = 1; id <= ( int ) Key_PIN_PKG.size( ); id++ ) {
                    if ( Key_PIN_PKG[id - 1].first.first == pin_num && Key_PIN_PKG[id - 1].first.second == pkg_id ) {
                        target = Key_PIN_PKG[id - 1].second;
                        break;
                    }
                }
                int diff = target - PIN_PKG_production[index];
                int min = diff;

                if ( min > n_l_chips[l] ) {
                    min = n_l_chips[l];
                }
                if ( min > 0 ) {
                    (*p_lot).first.second += get_PIN_PKG_penalty( pkg_id, pin_num ) / coef * min;
                    (*p_lot).second += get_PIN_PKG_penalty( pkg_id, pin_num ) / coef * min / n_l_chips[l];
                }
            }
            p_lot++;
        }
    }
    sort( unassigned_lots.begin( ), unassigned_lots.end( ), compare_2_3 );

    // dispay section
    cout << "Number of unassigned lots=" << ( int ) unassigned_lots.size( ) << endl;

    // -------------------------------------------------------------------------------------------
    if ( LP_IP == 1 ) {
        N1( sub_soln, shortage, unassigned_lots );
    }
    if ( option == 2 && LP_IP == 1 ) {
        N2( sub_soln, shortage, unassigned_lots );
    }
    if ( option == 3 && LP_IP == 1 ) {
        N2( sub_soln, shortage, unassigned_lots );
        N3( sub_soln, shortage, unassigned_lots );
    }
    return compute_obj( sub_soln, shortage );
}


/**
 * @brief 
 * 
 * @param sub_soln
 * @param shortage
 * @param unassigned_lots
 */
void
AT::N1( vector < sub_soln_item > &sub_soln, vector < pair < int, double > >&shortage, vector < pair < pair < int, double >, double > >&unassigned_lots )
{
    cout << "in local search N1()" << endl;
    vector < int >PKG_production( ( int ) PKG.size( ), 0 );
    vector < int >PIN_PKG_production( ( int ) PKG.size( ) * ( int ) PIN_order.size( ) + 1, 0 );

    for ( int id = 1; id <= ( int ) sub_soln.size( ); id++ ) {
        for ( int id2 = 1; id2 <= ( int ) sub_soln[id - 1].lots.int_vector.size( ); id2++ ) {
            int l = sub_soln[id - 1].lots.int_vector[id2 - 1];
            int d = lots_device[l];
            int pkg_id = device_PKG[d];
            int pin_num = device_PIN[d];

            vii pfind = find( PIN_order.begin( ), PIN_order.end( ), pin_num );
            int pin_order = pfind - PIN_order.begin( ) + 1;
            int index = (pkg_id - 1) * ( int ) PIN_order.size( ) + pin_order - 1;

            PKG_production[pkg_id - 1] += n_l_chips[l];
            PIN_PKG_production[index] += n_l_chips[l];
        }
    }
    vector < pair < pair < int, double >, double > > ::iterator p_lot = unassigned_lots.begin( );

    while ( p_lot != unassigned_lots.end( ) ) {
        int flag = 0;
        int l = (*p_lot).first.first;
        vector < pair < int, int > > ::iterator p_pair = sim_lambda_L[l - 1].second.sim_lambda_pairs.begin( );

        while ( p_pair != sim_lambda_L[l - 1].second.sim_lambda_pairs.end( ) ) {
            int sim = (*p_pair).first;
            int Lambda_id = (*p_pair).second;
            int s = max_rate_s( SIM[sim - 1].represented_machine_id, l, Lambda_id );
            double time_required = n_l_chips[l] / rate[s] + Load_Unload_Time;

            for ( int id2 = 1; id2 <= ( int ) sub_soln.size( ); id2++ ) {
                int i = sub_soln[id2 - 1].i;

                if ( sim == machine_sim[i] && Lambda_id == sub_soln[id2 - 1].Lambda_id && sub_soln[id2 - 1].time_used + time_required <= H[i] ) {

                    // lot l can be assigned to this machine-lambda combination
                    sub_soln[id2 - 1].lots.int_vector.push_back( l );
                    sub_soln[id2 - 1].time_used += time_required;
                    int dev = lots_device[l];

                    shortage[dev - 1].second -= n_l_chips[l];
                    p_lot = unassigned_lots.erase( p_lot );

                    // ---------------------------------------------
                    flag = 1;
                    break;
                }
            }
            if ( flag ) {
                break;
            }
            p_pair++;
        }
        if ( !flag ) {
            p_lot++;
        }
    }
}


/**
 * @brief 
 * 
 * @param sub_soln
 * @param shortage
 * @param unassigned_lots
 */
void
AT::N2( vector < sub_soln_item > &sub_soln, vector < pair < int, double > >&shortage, vector < pair < pair < int, double >, double > >&unassigned_lots )
{
    cout << "in local search N2()" << endl;

    // compute PKG and PIN_PKG production
    vector < int >PKG_production( ( int ) PKG.size( ), 0 );
    vector < int >PIN_PKG_production( ( int ) PKG.size( ) * ( int ) PIN_order.size( ) + 1, 0 );

    for ( int id = 1; id <= ( int ) sub_soln.size( ); id++ ) {
        for ( int id2 = 1; id2 <= ( int ) sub_soln[id - 1].lots.int_vector.size( ); id2++ ) {
            int l = sub_soln[id - 1].lots.int_vector[id2 - 1];
            int d = lots_device[l];
            int pkg_id = device_PKG[d];
            int pin_num = device_PIN[d];

            vii pfind = find( PIN_order.begin( ), PIN_order.end( ), pin_num );
            int pin_order = pfind - PIN_order.begin( ) + 1;
            int index = (pkg_id - 1) * ( int ) PIN_order.size( ) + pin_order - 1;

            PKG_production[pkg_id - 1] += n_l_chips[l];
            PIN_PKG_production[index] += n_l_chips[l];
        }
    }
    bool iter_flag = true;
    int count = 0;

    while ( iter_flag && count <= 2 ) {
        iter_flag = false;
        vector < pair < pair < int, double >, double > > ::iterator p_lot = unassigned_lots.begin( );

        while ( p_lot != unassigned_lots.end( ) ) {
            int l_from = (*p_lot).first.first;
            int d_from = lots_device[l_from];
            int sim_best = -1;
            int i_best = -1;
            int Lambda_id_best = -1;
            int l_to_best = -1;
            double ben_best = 1E+10;
            vector < pair < int, int > > ::iterator p_pair = sim_lambda_L[l_from - 1].second.sim_lambda_pairs.begin( );

            while ( p_pair != sim_lambda_L[l_from - 1].second.sim_lambda_pairs.end( ) ) {
                int sim = (*p_pair).first;
                int Lambda_id = (*p_pair).second;
                int s_from = max_rate_s( SIM[sim - 1].represented_machine_id, l_from, Lambda_id );
                double time_required = n_l_chips[l_from] / rate[s_from] + Load_Unload_Time;

                for ( int id2 = 1; id2 <= ( int ) sub_soln.size( ); id2++ ) {
                    int i = sub_soln[id2 - 1].i;

                    if ( sim == machine_sim[i] && Lambda_id == sub_soln[id2 - 1].Lambda_id ) {

                        // lot l_from can be assigned to this machine-lambda combination
                        vii pint = sub_soln[id2 - 1].lots.int_vector.begin( );

                        // pint=sub_soln[id2-1].lots.int_vector.begin();
                        while ( pint != sub_soln[id2 - 1].lots.int_vector.end( ) ) {
                            int l_to = (*pint); // this is the lot to be exchange
                            int d_to = lots_device[l_to];
                            int s_to = max_rate_s( i, l_to, Lambda_id );

                            if ( sub_soln[id2 - 1].time_used - (n_l_chips[l_to] / rate[s_to] + Load_Unload_Time) + time_required <= H[i] ) {
                                double benefit = 0.0;


                                // --------------
                                vector < pair < int, double > > shortage_2( ( int ) shortage.size( ) );
                                vector < int >PKG_production_2( ( int ) PKG.size( ), 0 );
                                vector < int >PIN_PKG_production_2( ( int ) PKG.size( ) *( int ) PIN_order.size( ) + 1, 0 );

                                copy( shortage.begin( ), shortage.end( ), shortage_2.begin( ) );
                                copy( PKG_production.begin( ), PKG_production.end( ), PKG_production_2.begin( ) );
                                copy( PIN_PKG_production.begin( ), PIN_PKG_production.end( ), PIN_PKG_production_2.begin( ) );

                                // --------------
                                // this is the benefit to loss
                                benefit += w_l[l_to] - eps[s_to];
                                shortage_2[d_to - 1].second += n_l_chips[l_to];
                                if ( is_KD_PD( d_to ) == 1 && shortage_2[d_to - 1].second > 0 ) {
                                    if ( shortage_2[d_to - 1].second - n_l_chips[l_to] < 0 ) {
                                        benefit += penalty[d_to] * shortage_2[d_to - 1].second / coef;
                                    } else {
                                        benefit += penalty[d_to] * n_l_chips[l_to] / coef;
                                    }
                                }
                                bool is_kp_to = is_Key_PKG( d_to );
                                bool is_kpp_to = is_Key_PIN_PKG( d_to );
                                int pkg_id_to = device_PKG[d_to];
                                int pin_num_to = device_PIN[d_to];

                                vii pfind_to = find( PIN_order.begin( ), PIN_order.end( ), pin_num_to );
                                int pin_order_to = pfind_to - PIN_order.begin( ) + 1;

                                if ( is_kp_to ) {
                                    PKG_production_2[pkg_id_to - 1] -= n_l_chips[l_to];
                                    int diff = n_kp_minchips[pkg_id_to] - PKG_production_2[pkg_id_to - 1];
                                    int min = diff;

                                    if ( min > n_l_chips[l_to] ) {
                                        min = n_l_chips[l_to];
                                    }
                                    if ( min > 0 ) {
                                        benefit += PKG_penalty[pkg_id_to] * min / coef;
                                    }
                                }
                                if ( is_kpp_to ) {
                                    int index = (pkg_id_to - 1) *( int ) PIN_order.size( ) + pin_order_to - 1;

                                    PIN_PKG_production_2[index] -= n_l_chips[l_to];
                                    int target = 0;

                                    for ( int id3 = 1; id3 <= ( int ) Key_PIN_PKG.size( ); id3++ ) {
                                        if ( Key_PIN_PKG[id3 - 1].first.first == pin_num_to && Key_PIN_PKG[id3 - 1].first.second == pkg_id_to ) {
                                            target = Key_PIN_PKG[id3 - 1].second;
                                            break;
                                        }
                                    }
                                    int diff = target - PIN_PKG_production_2[index];
                                    int min = diff;

                                    if ( min > n_l_chips[l_to] ) {
                                        min = n_l_chips[l_to];
                                    }
                                    if ( min > 0 ) {
                                        benefit += get_PIN_PKG_penalty( pkg_id_to, pin_num_to ) * min / coef;
                                    }
                                }

                                // ------------------------------------------------------------------------
                                // this is the benefit to gain
                                bool is_kp_from = is_Key_PKG( d_from );
                                bool is_kpp_from = is_Key_PIN_PKG( d_from );
                                int pkg_id_from = device_PKG[d_from];
                                int pin_num_from = device_PIN[d_from];

                                vii pfind_from = find( PIN_order.begin( ), PIN_order.end( ), pin_num_from );
                                int pin_order_from = pfind_from - PIN_order.begin( ) + 1;

                                benefit -= (w_l[l_from] - eps[s_from]);
                                if ( is_KD_PD( d_from ) == 1 ) {
                                    int min = shortage_2[d_from - 1].second;

                                    if ( min > n_l_chips[l_from] ) {
                                        min = n_l_chips[l_from];
                                    }
                                    if ( min > 0 ) {
                                        benefit -= penalty[d_from] * min / coef;
                                    }
                                }
                                shortage_2[d_from - 1].second -= n_l_chips[l_from];
                                if ( is_kp_from ) {
                                    int temp = PKG_production_2[pkg_id_from - 1] + n_l_chips[l_from];
                                    int diff = n_kp_minchips[pkg_id_from] - temp;
                                    int min = diff;

                                    if ( min > n_l_chips[l_from] ) {
                                        min = n_l_chips[l_from];
                                    }
                                    if ( min > 0 ) {
                                        benefit -= PKG_penalty[pkg_id_from] * min / coef;
                                    }
                                    PKG_production_2[pkg_id_from - 1] += n_l_chips[l_from];
                                }
                                if ( is_kpp_from ) {
                                    int index = (pkg_id_from - 1) *( int ) PIN_order.size( ) + pin_order_from - 1;
                                    int temp = PIN_PKG_production_2[index] + n_l_chips[l_from];
                                    int target = 0;

                                    for ( int id3 = 1; id3 <= ( int ) Key_PIN_PKG.size( ); id3++ ) {
                                        if ( Key_PIN_PKG[id3 - 1].first.first == pin_num_from && Key_PIN_PKG[id3 - 1].first.second == pkg_id_from ) {
                                            target = Key_PIN_PKG[id3 - 1].second;
                                            break;
                                        }
                                    }
                                    int diff = target - temp;
                                    int min = diff;

                                    if ( min > n_l_chips[l_from] ) {
                                        min = n_l_chips[l_from];
                                    }
                                    if ( min > 0 ) {
                                        benefit -= (get_PIN_PKG_penalty( pkg_id_from, pin_num_from ) * min / coef);
                                    }
                                    PIN_PKG_production_2[index] += n_l_chips[l_from];
                                }
                                if ( benefit < 0 && benefit < ben_best ) {
                                    ben_best = benefit;
                                    sim_best = sim;
                                    i_best = i;
                                    Lambda_id_best = Lambda_id;
                                    l_to_best = l_to;
                                }
                            }
                            pint++;
                        }
                    }
                }
                p_pair++;
            }
            if ( ben_best < -1 ) {
                int d_to_best = lots_device[l_to_best];


                // ---------------------------------------------------------------------
                shortage[d_from - 1].second -= n_l_chips[l_from];
                int pkg_from = device_PKG[d_from];
                int pin_from = device_PIN[d_from];

                vii pfind = find( PIN_order.begin( ), PIN_order.end( ), pin_from );
                int pin_from_order = pfind - PIN_order.begin( ) + 1;
                int index_from = (pkg_from - 1) * ( int ) PIN_order.size( ) + pin_from_order - 1;

                PKG_production[pkg_from - 1] += n_l_chips[l_from];
                PIN_PKG_production[index_from] += n_l_chips[l_from];
                int pkg_to = device_PKG[d_to_best];
                int pin_to = device_PIN[d_to_best];

                pfind = find( PIN_order.begin( ), PIN_order.end( ), pin_to );
                int pin_to_order = pfind - PIN_order.begin( ) + 1;
                int index_to = (pkg_to - 1) * ( int ) PIN_order.size( ) + pin_to_order - 1;


                // -----------------------------------------------------------------------
                // update unassigned_lots
                iter_flag = true;
                count++;
                p_lot = unassigned_lots.erase( p_lot );
                pair < pair < int, double >, double >one_pair;

                one_pair.first.first = l_to_best;
                one_pair.first.second = w_l[l_to_best];
                if ( is_KD_PD( d_to_best ) && shortage[d_to_best - 1].second + n_l_chips[l_to_best] > 0 ) {
                    if ( shortage[d_to_best - 1].second > 0 ) {
                        one_pair.first.second += penalty[d_to_best] / coef * n_l_chips[l_to_best];
                    } else {
                        one_pair.first.second += penalty[d_to_best] / coef * (shortage[d_to_best - 1].second + n_l_chips[l_to_best]);
                    }
                }
                if ( is_Key_PKG( d_to_best ) && PKG_production[pkg_to - 1] - n_l_chips[l_to_best] < n_kp_minchips[pkg_to] ) {
                    int diff = n_kp_minchips[pkg_to] -(PKG_production[pkg_to - 1] - n_l_chips[l_to_best]);
                    int min = diff;

                    if ( min > n_l_chips[l_to_best] ) {
                        min = n_l_chips[l_to_best];
                    }
                    one_pair.first.second += PKG_penalty[pkg_to] * min / coef;
                }
                int target = 0;

                for ( int id = 1; id <= ( int ) Key_PIN_PKG.size( ); id++ ) {
                    if ( Key_PIN_PKG[id - 1].first.first == pin_to && Key_PIN_PKG[id - 1].first.second == pkg_to ) {
                        target = Key_PIN_PKG[id - 1].second;
                        break;
                    }
                }
                if ( is_Key_PIN_PKG( d_to_best ) && PIN_PKG_production[index_to] - n_l_chips[l_to_best] < target ) {
                    int diff = target - (PIN_PKG_production[index_to] - n_l_chips[l_to_best]);
                    int min = diff;

                    if ( min > n_l_chips[l_to_best] ) {
                        min = n_l_chips[l_to_best];
                    }
                    one_pair.first.second += get_PIN_PKG_penalty( pkg_to, pin_to ) * min / coef;
                }
                one_pair.second = one_pair.first.second / n_l_chips[l_to_best];
                unassigned_lots.push_back( one_pair );

                // update sub_soln
                vii pint = find( sub_soln[i_best - 1].lots.int_vector.begin( ), sub_soln[i_best - 1].lots.int_vector.end( ), l_to_best );
                if ( pint != sub_soln[i_best - 1].lots.int_vector.end( ) ) {
                    (*pint) = l_from;
                } else {
                    cout << "!!! error here" << endl;
                }
                int s_to_best = max_rate_s( i_best, l_to_best, Lambda_id_best );
                int s_from = max_rate_s( SIM[sim_best - 1].represented_machine_id, l_from, Lambda_id_best );

                sub_soln[i_best - 1].time_used += -(n_l_chips[l_to_best] / rate[s_to_best] + Load_Unload_Time) +(n_l_chips[l_from] / rate[s_from] + Load_Unload_Time);

                // update shortage
                shortage[d_to_best - 1].second += n_l_chips[l_to_best];
                PKG_production[pkg_to - 1] -= n_l_chips[l_to_best];
                PIN_PKG_production[index_to] -= n_l_chips[l_to_best];
            } else {
                p_lot++;
            }
        }
    }
    sort( unassigned_lots.begin( ), unassigned_lots.end( ), compare_2_3 );
    cout << "N2 finished" << endl;
}


/**
 * @brief 
 * 
 * @param sub_soln
 * @param shortage
 * @param unassigned_lots
 */
void
AT::N3( vector < sub_soln_item > &sub_soln, vector < pair < int, double > >&shortage, vector < pair < pair < int, double >, double > >&unassigned_lots )
{
    // extended insertion
    vector < pair < pair < int, double >, double > > ::iterator p_lot = unassigned_lots.begin( );

    while ( p_lot != unassigned_lots.end( ) ) {
        bool erase_flag = false;
        int l_from = (*p_lot).first.first;
        int d_from = lots_device[l_from];

        for ( int i = 1; i <= Num_Machine; i++ ) {
            int Lambda_id = sub_soln[i - 1].Lambda_id;

            if ( Lambda_id > 0 ) {
                int sim = machine_sim[i];
                int index = index_L_sim_lambda( sim, Lambda_id );

                vii pfind = find( L_sim_lambda[index].second.int_vector.begin( ), L_sim_lambda[index].second.int_vector.end( ), l_from );
                if ( pfind == L_sim_lambda[index].second.int_vector.end( ) ) {
                    continue;
                }

                // -----------------------------------------------------------------------------------------
                int s_from = max_rate_s( i, l_from, Lambda_id );
                double time_from = n_l_chips[l_from] / rate[s_from] + Load_Unload_Time;

                if ( time_from + sub_soln[i - 1].time_used > H[i] ) {

                    // -----------------------------------------------------------------------------------------
                    vector < pair < int, double > > lots;

                    lots.resize( ( int ) sub_soln[i - 1].lots.int_vector.size( ) );
                    for ( int j = 1; j <= ( int ) sub_soln[i - 1].lots.int_vector.size( ); j++ ) {
                        lots[j - 1].first = sub_soln[i - 1].lots.int_vector[j - 1];
                        lots[j - 1].second = 0;
                    }
                    lots.push_back( make_pair( l_from, 0 ) );

                    // -----------------------------------------------------------------------------------------
                    vector < double >sh( ( int ) shortage.size( ), 0 );

                    for ( int j = 1; j <= ( int ) shortage.size( ); j++ ) {
                        sh[j - 1] = shortage[j - 1].second;
                    }
                    // -----------------------------------------------------------------------------------------
                    double ben_get = w_l[l_from] - eps[s_from];

                    if ( is_KD_PD( d_from ) && sh[d_from - 1] > 0 ) {
                        if ( sh[d_from - 1] > n_l_chips[l_from] ) {
                            ben_get += penalty[d_from] / coef * n_l_chips[l_from];
                        } else {
                            ben_get += penalty[d_from] / coef * sh[d_from - 1];
                        }
                    }
                    sh[d_from - 1] -= n_l_chips[l_from];

                    // -----------------------------------------------------------------------------------------
                    for ( int j = 1; j <= ( int ) lots.size( ); j++ ) {
                        int l = lots[j - 1].first;
                        int s = max_rate_s( i, l, Lambda_id );

                        lots[j - 1].second = w_l[l] - eps[s];
                        int d = lots_device[l];

                        if ( is_KD_PD( d ) && sh[d - 1] + n_l_chips[l] > 0 ) {
                            double min = n_l_chips[l];

                            if ( min > sh[d - 1] + n_l_chips[l] ) {
                                min = sh[d - 1] + n_l_chips[l];
                            }
                            lots[j - 1].second += penalty[d] / coef * min;
                        }
                    }
                    sort( lots.begin( ), lots.end( ), compare_lot );

                    // ------------------------------------------------------------------------------------------
                    double time_required = time_from + sub_soln[i - 1].time_used;
                    double ben_loss = lots[( int ) lots.size( ) - 1].second;
                    vector < int >lot_removed;

                    while ( time_required > H[i] && ben_loss < ben_get ) {
                        int l = lots[( int ) lots.size( ) - 1].first;
                        int d = lots_device[l];
                        int s = max_rate_s( i, l, Lambda_id );

                        lots.erase( lots.end( ) - 1 );
                        lot_removed.push_back( l );

                        // --------------------------------------------------------------------------------------update the remove_ben
                        sh[d - 1] += n_l_chips[l];
                        if ( is_KD_PD( d ) ) {
                            for ( int j = 1; j <= ( int ) lots.size( ); j++ ) {
                                int ll = lots[j - 1].first;
                                int dd = lots_device[ll];
                                int ss = max_rate_s( i, ll, Lambda_id );

                                if ( dd == d && sh[dd - 1] + n_l_chips[ll] > 0 ) {
                                    lots[j - 1].second = w_l[ll] - eps[ss];
                                    double min = n_l_chips[ll];

                                    if ( min > sh[dd - 1] + n_l_chips[ll] ) {
                                        min = sh[dd - 1] + n_l_chips[ll];
                                    }
                                    lots[j - 1].second += penalty[dd] / coef *min;
                                }
                            }
                            sort( lots.begin( ), lots.end( ), compare_lot );
                        }

                        // --------------------------------------------------------------------------------------
                        time_required -= (n_l_chips[l] / rate[s] + Load_Unload_Time);
                        ben_loss += lots[( int ) lots.size( ) - 1].second;
                    }
                    if ( time_required < H[i] ) {
                        sub_soln[i - 1].lots.int_vector.clear( );
                        sub_soln[i - 1].lots.int_vector.resize( ( int ) lots.size( ) );
                        double time = 0;

                        for ( int j = 1; j <= ( int ) lots.size( ); j++ ) {
                            int l = lots[j - 1].first;
                            int s = max_rate_s( i, l, Lambda_id );

                            time += n_l_chips[l] / rate[s] + Load_Unload_Time;
                            sub_soln[i - 1].lots.int_vector[j - 1] = l;
                        }
                        sub_soln[i - 1].time_used = time;
                        for ( int j = 1; j <= ( int ) lot_removed.size( ); j++ ) {
                            pair < pair < int, double >, double >one_pair;
                            int l2 = lot_removed[j - 1];
                            int d2 = lots_device[l2];

                            one_pair.first.first = l2;
                            if ( is_KD_PD( d2 ) && sh[d2 - 1] > 0 ) {
                                double min = n_l_chips[l2];

                                if ( min > sh[d2 - 1] ) {
                                    min = sh[d2 - 1];
                                }
                                one_pair.first.second = w_l[l2] + penalty[d2] / coef * min;
                            } else {
                                one_pair.first.second = w_l[l2];
                            }
                            one_pair.second = one_pair.first.second / n_l_chips[l2];
                            unassigned_lots.push_back( one_pair );
                        }
                        for ( int j = 1; j <= ( int ) sh.size( ); j++ ) {
                            shortage[j - 1].second = sh[j - 1];
                        }
                        p_lot = unassigned_lots.erase( p_lot );
                        erase_flag = true;
                        break;
                    } else { // it is not benefitial to assign to machine i
                        continue;
                    }
                } else {

                    // simply insert lot l_from to machine i
                    sub_soln[i - 1].lots.int_vector.push_back( l_from );
                    sub_soln[i - 1].time_used += time_from;
                    shortage[d_from - 1].second -= n_l_chips[l_from];
                    p_lot = unassigned_lots.erase( p_lot );
                    erase_flag = true;
                    break;
                }
            }
        }
        if ( !erase_flag ) {
            p_lot++;
        }
    }
}


/**
 * @brief given a lot, find all the (sim,lambda) combinations
 */
void
AT::initialize_sim_lambda_L( )
{
    // given a lot, find all the (sim,lambda) combinations
    for ( int l = 1; l <= Num_Lot; l++ ) {
        pair < int, sim_lambda_item > one_pair;

        one_pair.first = l;
        sim_lambda_L.push_back( one_pair );
    }
    for ( int l = 1; l <= Num_Lot; l++ ) {
        int index = -1;

        for ( int sim = 1; sim <= ( int ) SIM.size( ); sim++ ) {
            int i = SIM[sim - 1].represented_machine_id;

            vii p_Lambda = Lambda_i[i].int_vector.begin( );
            while ( p_Lambda != Lambda_i[i].int_vector.end( ) ) {
                int Lambda_id = (*p_Lambda);

                index++;
                vii pfind = find( L_sim_lambda[index].second.int_vector.begin( ), L_sim_lambda[index].second.int_vector.end( ), l );
                if ( pfind != L_sim_lambda[index].second.int_vector.end( ) ) {
                    sim_lambda_L[l - 1].second.sim_lambda_pairs.push_back( make_pair( sim, Lambda_id ) );
                }
                p_Lambda++;
            }
        }
    }
}


/**
 * @brief 
 */
void
AT::show_sim_lambda_L( )
{
    ofstream fout( "Debug/debug_sim_lambda_L.txt" );
    for ( int l = 1; l <= Num_Lot; l++ ) {
        fout << "lot=" << l << endl;
        vector < pair < int, int > > ::iterator p_pair = sim_lambda_L[l - 1].second.sim_lambda_pairs.begin( );

        while ( p_pair != sim_lambda_L[l - 1].second.sim_lambda_pairs.end( ) ) {
            fout << "(" << (*p_pair).first << "," << (*p_pair).second << ")" << ",";
            p_pair++;
        }
        fout << endl;
    }
    fout.close( );
}


/**
 * @brief
 * 
 * @param i
 * @param l
 * @param Lambda_id
 * @return 
 */
int
AT::max_rate_s( int i, int l, int Lambda_id )
{
    int sim = machine_sim[i];
    int index = index_S_sim_l_lambda( sim, l, Lambda_id );

    return S_sim_l_lambda[index].s;
}


/**
 * @brief 
 */
void
AT::initialize_S_sim_l_lambda( )
{
    int count = 1; // count is to record the id of the element in the S_sim_l_lambda. id-1 is the position

    sim_position_S_sim_l_lambda.push_back( count );
    for ( int sim = 1; sim <= ( int ) SIM.size( ); sim++ ) {
        int i = SIM[sim - 1].represented_machine_id;

        vii p_Lambda = Lambda_i[i].int_vector.begin( );
        while ( p_Lambda != Lambda_i[i].int_vector.end( ) ) {
            int Lambda_id = (*p_Lambda);
            int index = index_L_sim_lambda( sim, Lambda_id );
            vector < int >::iterator p_L = L_sim_lambda[index].second.int_vector.begin( );

            while ( p_L != L_sim_lambda[index].second.int_vector.end( ) ) {
                int l = (*p_L);
                int flag = 0;

                for ( int id = 1; id <= ( int ) S_sim_l_lambda.size( ); id++ ) {
                    if ( sim == S_sim_l_lambda[id - 1].sim && Lambda_id == S_sim_l_lambda[id - 1].Lambda_id && l == S_sim_l_lambda[id - 1].l ) {
                        flag = 1;
                        break;
                    }
                }
                if ( flag ) {
                    p_L++;
                    continue;
                }
                int max_rate_s = -1;
                double max_rate = -1E+6;

                vector < tooling_configure > TS;
                get_S_i_l_Lambda( TS, i, l, Lambda_id );
                vector < tooling_configure >::iterator pTS = TS.begin( );
                while ( pTS != TS.end( ) ) {
                    int s = (*pTS).id;

                    if ( rate[s] > max_rate ) {
                        max_rate = rate[s];
                        max_rate_s = s;
                    }
                    pTS++;
                }
                struct S_sim_l_lambda_item one_item;

                one_item.sim = sim;
                one_item.l = l;
                one_item.Lambda_id = Lambda_id;
                one_item.s = max_rate_s;
                S_sim_l_lambda.push_back( one_item );
                count++;
                p_L++;
            }
            p_Lambda++;
        }
        sim_position_S_sim_l_lambda.push_back( count );
    }
}


/**
 * @brief 
 */
void
AT::show_S_sim_l_lambda( )
{
    ofstream fout( "Debug/debug_S_sim_l_lambda.txt" );
    int position = 1;

    for ( int id = 1; id <= ( int ) S_sim_l_lambda.size( ); id++ ) {
        fout << "position=" << position << ", sim=" << S_sim_l_lambda[id - 1].sim << "," << "l=" << S_sim_l_lambda[id - 1].l << "," << "lambda=" << S_sim_l_lambda[id - 1].Lambda_id << "," << "s=" << S_sim_l_lambda[id - 1].s << endl;
        position++;
    }
    vii p_sim = sim_position_S_sim_l_lambda.begin( );
    int sim = 1;

    while ( p_sim != sim_position_S_sim_l_lambda.end( ) ) {
        fout << "sim=" << sim << ", position=" << (*p_sim) << endl;
        sim++;
        p_sim++;
    }
    fout.close( );
}


/**
 * @brief
 * 
 * @param sim
 * @param l
 * @param Lambda_id
 * @return 
 */
int
AT::index_S_sim_l_lambda( int sim, int l, int Lambda_id )
{
    int index = -1;

    if ( sim <= 0 ) {
        cout << "WRONG sim in index_S_sim_l_lambda() " << endl;
        return index;
    }
    int start_id = sim_position_S_sim_l_lambda[sim - 1];

    for ( int id = start_id; id <= ( int ) S_sim_l_lambda.size( ); id++ ) {
        if ( sim == S_sim_l_lambda[id - 1].sim && l == S_sim_l_lambda[id - 1].l && Lambda_id == S_sim_l_lambda[id - 1].Lambda_id ) {
            index = id - 1;
            break;
        }
    }
    if ( index < 0 ) {
        cout << "Warning!! Wrong S_sim_l_lambda index!!" << endl;
        cout << "sim=" << sim << ",l=" << l << ",Lambda_id=" << Lambda_id << endl;
    }
    return index;
}


/**
 * @brief 
 * 
 * @param dev
 * 
 * @return 
 * @retval 0 if dev is neither KD nor PD
 * @retval 1 if dev is KD
 * @retval 2 if dev is PD
 */
int
AT::is_KD_PD( int dev )
{
    int value = 0;

    vii pfind = find( Key_Devices.begin( ), Key_Devices.end( ), dev );
    if ( pfind != Key_Devices.end( ) ) {
        value = 1;
    }
    pfind = Packages.begin( );
    pfind = find( Packages.begin( ), Packages.end( ), dev );
    if ( pfind != Packages.end( ) ) {
        value = 2;
    }
    return value;
}


/**
 * @brief 
 * 
 * @param dev
 * 
 * @return 
 */
bool AT::is_Key_PKG( int dev )
{
    bool flag = false;
    int
    pkg = device_PKG[dev];

    vii pfind = find( Key_PKG.begin( ), Key_PKG.end( ), pkg );
    if ( pfind != Key_PKG.end( ) ) {
        flag = true;
    }
    return flag;
}


/**
 * @brief 
 * 
 * @param dev
 * 
 * @return 
 */
bool AT::is_Key_PIN_PKG( int dev )
{
    bool flag = false;
    int
    pkg_id = device_PKG[dev];
    int
    pin_num = device_PIN[dev];

    for ( int id = 1; id <= ( int ) Key_PIN_PKG.size( ); id++ ) {
        if ( Key_PIN_PKG[id - 1].first.first == pin_num && Key_PIN_PKG[id - 1].first.second == pkg_id ) {
            flag = true;
        }
    }
    return flag;
}


/**
 * @brief 
 * 
 * @param sub_soln
 * @param shortage
 * 
 * @return 
 */
double
AT::compute_obj( vector < sub_soln_item > &sub_soln, vector < pair < int, double > >&shortage )
{
    // compute the obj for the first level problem, given the sub_soln and shortage
    double obj = 0.0;
    vector < int >production( Num_Device, 0 );
    int counter = 0;

    for ( int i = 1; i <= Num_Machine; i++ ) {
        int Lambda_id = sub_soln[i - 1].Lambda_id;

        vii p_lot = sub_soln[i - 1].lots.int_vector.begin( );
        double time_used = 0.0;

        while ( p_lot != sub_soln[i - 1].lots.int_vector.end( ) ) {
            int l = (*p_lot);
            int s = max_rate_s( i, l, Lambda_id );

            obj += -w_l[l] + eps[s];
            time_used += n_l_chips[l] / rate[s] + Load_Unload_Time;
            int d = lots_device[l];

            production[d - 1] += n_l_chips[l];
            counter++;
            p_lot++;
        }
    }
    // ---------------------------------------Still need to add the initial lot to the production
    for ( int id = 1; id <= ( int ) initial_running_lot.size( ); id++ ) {

        // include every initial lots even though they might be finished already
        // NOTE That H[] has been updated in process_initial_lot() but changed back to the original H[] in the beginning of machine_resetup()
        // It doesn't matter if the initial lot can be finished or not. (it is possible that some LONG lot cannot be done within a horizon)
        // This also excludes the lots that are setup as initial lot but has already benn finished before Snapshot_time (pretended to be an initial lot)
        obj += -initial_running_lot[id - 1].w_l; // at this point,forget the small amount eps[s]
        int d = initial_running_lot[id - 1].dev_id;

        production[d - 1] += initial_running_lot[id - 1].n_l_chips;
    }
    // compute the penalty of deviation for Key Device
    // -------------------------------------------------Another way to compute the penalty for KD
    for ( int id = 1; id <= ( int ) Key_Devices.size( ); id++ ) {
        int d = Key_Devices[id - 1];
        int diff = n_k_minchips[d] - production[d - 1];

        if ( diff > 0 ) {
            obj += diff / coef * penalty[d];
        }
    }

    // ------------------------------------------------------------------------------------------
    // compute the penalty of deviation for KP and KPP
    vector < int >PKG_production( ( int ) PKG.size( ), 0 );
    vector < int >PIN_PKG_production( ( int ) PKG.size( ) * ( int ) PIN_order.size( ) + 1, 0 );

    for ( int i = 1; i <= Num_Machine; i++ ) {
        int Lambda_id = sub_soln[i - 1].Lambda_id;

        vii p_lot = sub_soln[i - 1].lots.int_vector.begin( );
        while ( p_lot != sub_soln[i - 1].lots.int_vector.end( ) ) {
            int l = (*p_lot);
            int d = lots_device[l];
            int pkg_id = device_PKG[d];
            int pin_num = device_PIN[d];

            vii pfind = find( PIN_order.begin( ), PIN_order.end( ), pin_num );
            int pin_order = pfind - PIN_order.begin( ) + 1;

            PKG_production[pkg_id - 1] += n_l_chips[l];
            int index = (pkg_id - 1) * ( int ) PIN_order.size( ) + pin_order - 1;

            PIN_PKG_production[index] += n_l_chips[l];
            p_lot++;
        }
    }
    // -----------------------------------------------------------------Also need to consider the contribution from the initial lots
    for ( int id = 1; id <= ( int ) initial_running_lot.size( ); id++ ) {

        // include every initial lots even though they might be finished already
        // NOTE That H[] has been updated in process_initial_lot() but is changed back to the original H[] in the beginning of machine_resetup()
        // It doesn't matter if the initial lot can be finished or not. (it is possible that some LONG lot cannot be done within a horizon)
        // This also excludes the lots that are setup as initial lot but has already finished before Snapshot_time (pretended to be an initial lot)
        int d = initial_running_lot[id - 1].dev_id;
        int pkg_id = initial_running_lot[id - 1].pkg_id;
        int pin_num = initial_running_lot[id - 1].PIN_num;

        vii pfind = find( PIN_order.begin( ), PIN_order.end( ), pin_num );
        int pin_order = pfind - PIN_order.begin( ) + 1;

        PKG_production[pkg_id - 1] += initial_running_lot[id - 1].n_l_chips;
        int index = (pkg_id - 1) * ( int ) PIN_order.size( ) + pin_order - 1;

        PIN_PKG_production[index] += initial_running_lot[id - 1].n_l_chips;
    }
    // -----------------------------------------------------------------------------------
    for ( int kp = 1; kp <= ( int ) Key_PKG.size( ); kp++ ) {
        int pkg_id = Key_PKG[kp - 1];
        int diff = n_kp_minchips[pkg_id] - PKG_production[pkg_id - 1];

        if ( diff > 0 ) {
            obj += diff / coef * PKG_penalty[pkg_id];
        }
    }
    for ( int kpp = 1; kpp <= ( int ) Key_PIN_PKG.size( ); kpp++ ) {
        int pkg_id = Key_PIN_PKG[kpp - 1].first.second;
        int pin_num = Key_PIN_PKG[kpp - 1].first.first;
        int target = Key_PIN_PKG[kpp - 1].second;

        vii pfind = find( PIN_order.begin( ), PIN_order.end( ), pin_num );
        int pin_order = pfind - PIN_order.begin( ) + 1;
        int index = (pkg_id - 1) * ( int ) PIN_order.size( ) + pin_order - 1;
        int diff = target - PIN_PKG_production[index];

        if ( diff > 0 ) {
            obj += diff / coef * get_PIN_PKG_penalty( pkg_id, pin_num );
        }
    }
    return obj;
}


/**
 * @brief compute the obj for the enhanced solution after resetting the idle machines
 * 
 * @param enhanced_solution
 * 
 * @return 
 */
double
AT::compute_obj( vector < pair < sub_soln_item, double > >&enhanced_solution )
{
    // ------------------------------------------compute the obj for the enhanced solution after resetting the idle machines
    // NOTE: the lots have been sorted in update_benefit() already
    // NOTE: ACTION 2 is taken care of here
    double obj = 0.0;
    vector < int >production( Num_Device, 0 );

    for ( int j = 1; j <= ( int ) enhanced_solution.size( ); j++ ) { // compute the total lot weights
        double current_time = enhanced_solution[j - 1].second;
        int i = enhanced_solution[j - 1].first.i;
        int Lambda_id = enhanced_solution[j - 1].first.Lambda_id;

        for ( int id = 1; id <= ( int ) enhanced_solution[j - 1].first.lots.int_vector.size( ); id++ ) {
            int l = enhanced_solution[j - 1].first.lots.int_vector[id - 1]; // lot
            int s = max_rate_s( i, l, Lambda_id );
            double time_required = n_l_chips[l] / rate[s] + Load_Unload_Time;

            current_time += time_required;
            if ( current_time <= H[i] ) { // only count the lots that are finished within the horizon (ACTION 2)
                obj += -w_l[l] + eps[s];
                int d = lots_device[l];

                production[d - 1] += n_l_chips[l]; // update the device production
            } else {
                break; // the next lots also exceed the horizon
            }
        }
    }

    // ---------------------------------------Still need to add the initial lot to the production
    for ( int id = 1; id <= ( int ) initial_running_lot.size( ); id++ ) {

        // include every initial lots even though they might be finished already
        // NOTE That H[] has been updated in process_initial_lot() but is changed back to the original H[] in the beginning of machine_resetup()
        // It doesn't matter if the lot can be finished or not. (it is possible that some LONG lot can not be done withn a horizon)
        // This also excludes the lots that are setup as initial lot but has already finished before Snapshot_time (pretended to be an initial lot)
        obj += -initial_running_lot[id - 1].w_l; // at this point,forget the small amount eps[s]
        int d = initial_running_lot[id - 1].dev_id;

        production[d - 1] += initial_running_lot[id - 1].n_l_chips;
    }
    // ----------------------------------------------compute penalties for key devices
    for ( int id = 1; id <= ( int ) Key_Devices.size( ); id++ ) {
        int d = Key_Devices[id - 1];
        int shortage = n_k_minchips[d] - production[d - 1];

        if ( shortage > 0 ) {
            obj += shortage / coef * penalty[d];
        }
    }

    // ----------------------------------------------compute the penalties for key packages and key pin pacakges
    vector < int >PKG_production( ( int ) PKG.size( ), 0 );
    vector < int >PIN_PKG_production( ( int ) PKG.size( ) * ( int ) PIN_order.size( ) + 1, 0 );

    for ( int j = 1; j <= ( int ) enhanced_solution.size( ); j++ ) { // --------------get the production of KP and KPP
        double current_time = enhanced_solution[j - 1].second; // the starting time
        int i = enhanced_solution[j - 1].first.i;
        int Lambda_id = enhanced_solution[j - 1].first.Lambda_id;

        vii p_lot = enhanced_solution[j - 1].first.lots.int_vector.begin( );
        while ( p_lot != enhanced_solution[j - 1].first.lots.int_vector.end( ) ) {
            int l = (*p_lot);
            int s = max_rate_s( i, l, Lambda_id );
            double time_required = n_l_chips[l] / rate[s] + Load_Unload_Time;

            current_time += time_required;
            if ( current_time <= H[i] ) {
                int d = lots_device[l];
                int pkg_id = device_PKG[d];
                int pin_num = device_PIN[d];

                vii pfind = find( PIN_order.begin( ), PIN_order.end( ), pin_num );
                int pin_order = pfind - PIN_order.begin( ) + 1;

                PKG_production[pkg_id - 1] += n_l_chips[l];
                int index = (pkg_id - 1) * ( int ) PIN_order.size( ) + pin_order - 1;

                PIN_PKG_production[index] += n_l_chips[l];
            } else {
                break;
            }
            p_lot++;
        }
    }

    // -----------------------------------------------------------------Also need to consider the contribution from the initial lots
    for ( int id = 1; id <= ( int ) initial_running_lot.size( ); id++ ) {

        // include every initial lots even though they might be finished already
        // NOTE That H[] has been updated in process_initial_lot() but is changed back to the original H[] at the beginning of machine_resetup()
        // It doesn't matter if the lot can be finished in the time horizon or not. (it is possible that some LONG lot can not be done withn a horizon)
        // This also excludes the lots that are setup as initial lot but has already finished before Snapshot_time (pretended to be an initial lot)
        int d = initial_running_lot[id - 1].dev_id;
        int pkg_id = initial_running_lot[id - 1].pkg_id;
        int pin_num = initial_running_lot[id - 1].PIN_num;

        vii pfind = find( PIN_order.begin( ), PIN_order.end( ), pin_num );
        int pin_order = pfind - PIN_order.begin( ) + 1;

        PKG_production[pkg_id - 1] += initial_running_lot[id - 1].n_l_chips;
        int index = (pkg_id - 1) * ( int ) PIN_order.size( ) + pin_order - 1;

        PIN_PKG_production[index] += initial_running_lot[id - 1].n_l_chips;
    }
    // -----------------------------------------------------------------------------------
    // ---------------------------------------------------------now compute the penalties
    for ( int kp = 1; kp <= ( int ) Key_PKG.size( ); kp++ ) {
        int pkg_id = Key_PKG[kp - 1];
        int diff = n_kp_minchips[pkg_id] - PKG_production[pkg_id - 1];

        if ( diff > 0 ) {
            obj += diff / coef * PKG_penalty[pkg_id];
        }
    }
    for ( int kpp = 1; kpp <= ( int ) Key_PIN_PKG.size( ); kpp++ ) {
        int pkg_id = Key_PIN_PKG[kpp - 1].first.second;
        int pin_num = Key_PIN_PKG[kpp - 1].first.first;
        int target = Key_PIN_PKG[kpp - 1].second;

        vii pfind = find( PIN_order.begin( ), PIN_order.end( ), pin_num );
        int pin_order = pfind - PIN_order.begin( ) + 1;
        int index = (pkg_id - 1) * ( int ) PIN_order.size( ) + pin_order - 1;
        int diff = target - PIN_PKG_production[index];

        if ( diff > 0 ) {
            obj += diff / coef * get_PIN_PKG_penalty( pkg_id, pin_num );
        }
    }
    return obj;
}


/**
 * @brief 
 * 
 * @param sub_soln
 */
void
AT::show_sub_soln( vector < sub_soln_item > &sub_soln )
{
    cout << "show sub_soln" << endl;
    for ( int i = 1; i <= Num_Machine; i++ ) {
        cout << "i=" << i << ",Lamdua_id=" << sub_soln[i - 1].Lambda_id << ",time_used=" << sub_soln[i - 1].time_used << ",assign lots=";
        vii p_lot = sub_soln[i - 1].lots.int_vector.begin( );
        while ( p_lot != sub_soln[i - 1].lots.int_vector.end( ) ) {
            cout << (*p_lot) << ",";
            p_lot++;
        }
        cout << endl;
    }
}


/**
 * @brief 
 * 
 * @param M
 * @param cost
 * @param col_lb
 * @param col_ub
 * @param row_lb
 * @param row_ub
 */
void
AT::build_first_level_model_OSI( CoinPackedMatrix * M, double *cost, double *col_lb, double *col_ub, double *row_lb, double *row_ub )
{
    // the arrays are filled in in this routine
    int num_con = 0;
    int num_var = 0;


    // initialize x variables
    cout << "initialize x variables" << endl;
    for ( int i = 1; i <= Num_Machine; i++ ) {
        vii p_L = L_i[i].int_vector.begin( );
        while ( p_L != L_i[i].int_vector.end( ) ) {
            int l = (*p_L);
            int sim = machine_sim[i];
            int d = lots_device[l];
            int index = index_S_sim_l( sim, l );

            vii p_s = S_sim_l[index].second.int_vector.begin( );
            while ( p_s != S_sim_l[index].second.int_vector.end( ) ) {
                int s = (*p_s);
                int x_id = index_x( i, l, s );

                col_lb[x_id] = 0.0;
                col_ub[x_id] = 1.0;
                num_var++;
                p_s++;
            }
            p_L++;
        }
    }
    // initialize y variables
    cout << "initialize y variables" << endl;
    for ( int i = 1; i <= Num_Machine; i++ ) {
        vii p_Lambda = Lambda_i[i].int_vector.begin( );
        while ( p_Lambda != Lambda_i[i].int_vector.end( ) ) {
            int Lambda_id = (*p_Lambda);
            int y_id = index_y( i, Lambda_id );

            col_lb[y_id] = 0.0;
            col_ub[y_id] = 1.0;
            num_var++;
            p_Lambda++;
        }
    }
    // initalize delta variables
    cout << "initialize delta variables" << endl;
    for ( int k = 1; k <= Num_Keydevice; k++ ) {
        string str = "deltaKD";
        stringstream ss;
        ss << "(" << k << ")";
        str += ss.str( );
        char name[20];

        strcpy( name, str.c_str( ) );
        int id = x_limit + k;

        col_lb[id] = 0.0;
        col_ub[id] = DBL_MAX;
        num_var++;
    }
    for ( int k = 1; k <= Num_Package; k++ ) {
        string str = "deltaPD";
        stringstream ss;
        ss << "(" << k << ")";
        str += ss.str( );
        char name[20];

        strcpy( name, str.c_str( ) );
        int id = x_limit + Num_Keydevice + k;

        col_lb[id] = 0.0;
        col_ub[id] = DBL_MAX;
        num_var++;
    }
    for ( int kp = 1; kp <= ( int ) Key_PKG.size( ); kp++ ) {
        int id = x_limit + Num_Keydevice + Num_Package + kp;

        col_lb[id] = 0.0;
        col_ub[id] = DBL_MAX;
        num_var++;
    }
    for ( int kpp = 1; kpp <= ( int ) Key_PIN_PKG.size( ); kpp++ ) {
        int id = x_limit + Num_Keydevice + Num_Package + ( int ) Key_PKG.size( ) + kpp;

        col_lb[id] = 0.0;
        col_ub[id] = DBL_MAX;
        num_var++;
    }
    cout << "num_var=" << num_var << endl;
    M->setDimensions( 0, num_var );
    cout << "build obj" << endl;
    for ( int i = 1; i <= Num_Machine; i++ ) {
        vector < int >::iterator p_L = L_i[i].int_vector.begin( );

        while ( p_L != L_i[i].int_vector.end( ) ) {
            int l = (*p_L);
            int sim = machine_sim[i];
            int d = lots_device[l];
            int index = index_S_sim_l( sim, l );

            vii p_s = S_sim_l[index].second.int_vector.begin( );
            while ( p_s != S_sim_l[index].second.int_vector.end( ) ) {
                int s = (*p_s);
                int x_id = index_x( i, l, s );

                cost[x_id] = -w_l[l] + eps[s];
                p_s++;
            }
            p_L++;
        }
    }
    for ( int k = 1; k <= Num_Keydevice; k++ ) {
        int id = x_limit + k;
        int d = Key_Devices[k - 1];

        cost[id] = penalty[d];
    }
    for ( int p = 1; p <= Num_Package; p++ ) {
        int id = x_limit + Num_Keydevice + p;
        int d = Packages[p - 1];

        cost[id] = penalty[d];
    }
    for ( int kp = 1; kp <= ( int ) Key_PKG.size( ); kp++ ) {
        int pkg = Key_PKG[kp - 1];
        int id = x_limit + Num_Keydevice + Num_Package + kp;

        cost[id] = PKG_penalty[pkg];
    }
    for ( int kpp = 1; kpp <= ( int ) Key_PIN_PKG.size( ); kpp++ ) {
        int pin_num = Key_PIN_PKG[kpp - 1].first.first;
        int pkg_id = Key_PIN_PKG[kpp - 1].first.second;
        int id = x_limit + Num_Keydevice + Num_Package + ( int ) Key_PKG.size( ) + kpp;

        cost[id] = get_PIN_PKG_penalty( pkg_id, pin_num );
    }
    cout << "build constraints (1b)" << endl;

    // This is the lot assignment constraint. Each lot can be assigned to a machine-tooling combination at most once.
    for ( int l = 1; l <= Num_Lot; l++ ) {
        CoinPackedVector row;
        vector < int >::iterator p_M = M_l[l].int_vector.begin( );

        while ( p_M != M_l[l].int_vector.end( ) ) {
            int i = (*p_M);
            int sim = machine_sim[i];
            int d = lots_device[l];
            int index = index_S_sim_l( sim, l );

            vii p_s = S_sim_l[index].second.int_vector.begin( );
            while ( p_s != S_sim_l[index].second.int_vector.end( ) ) {
                int s = (*p_s);
                int x_id = index_x( i, l, s );

                row.insert( x_id, 1.0 );
                p_s++;
            }
            p_M++;
        }
        row_lb[num_con] = -DBL_MAX;
        row_ub[num_con] = 1.0;
        M->appendRow( row );
        num_con++;
        string str = "(";
        stringstream ss;
        ss << "l@" << l << ")";
        char name[100];

        str += ss.str( );
        strcpy( name, str.c_str( ) );
    }
    if ( new_old_model == 2 ) {
        cout << "build constraints (1c)" << endl;

        // build the constraint x(i,l,s)<=y(i,lambda),This set of constraint contains a large number of constraints
        for ( int i = 1; i <= Num_Machine; i++ ) {
            vector < int >::iterator p_Lambda = Lambda_i[i].int_vector.begin( );

            while ( p_Lambda != Lambda_i[i].int_vector.end( ) ) {
                int Lambda_id = (*p_Lambda);
                int simid = machine_sim[i];
                int index = index_L_sim_lambda( simid, Lambda_id );
                vector < int >::iterator p_L = L_sim_lambda[index].second.int_vector.begin( );

                while ( p_L != L_sim_lambda[index].second.int_vector.end( ) ) {
                    int l = (*p_L);

                    vector < tooling_configure > TS;
                    get_S_i_l_Lambda( TS, i, l, Lambda_id );
                    vector < tooling_configure >::iterator p_TS = TS.begin( );
                    while ( p_TS != TS.end( ) ) {
                        CoinPackedVector row;
                        int s = (*p_TS).id;
                        int x_id = index_x( i, l, s );
                        int y_id = index_y( i, Lambda_id );

                        row.insert( x_id, -1.0 );
                        row.insert( y_id, 1.0 );
                        row_lb[num_con] = 0.0;
                        row_ub[num_con] = DBL_MAX;
                        M->appendRow( row );
                        num_con++;
                        string str = "(";
                        stringstream ss;
                        ss << "i@" << i << ",Lambda@" << Lambda_id << ",l@" << l << ",s@" << s << ")";
                        str += ss.str( );
                        char name[100];

                        strcpy( name, str.c_str( ) );
                        p_TS++;
                    }
                    p_L++;
                }
                p_Lambda++;
            }
        }
    }
    cout << "build constraints (1d)" << endl;

    // This is the machine setup constraint. Each machine can setup a lambda at most.
    for ( int i = 1; i <= Num_Machine; i++ ) {
        CoinPackedVector row;
        vector < int >::iterator p_Lambda = Lambda_i[i].int_vector.begin( );

        while ( p_Lambda != Lambda_i[i].int_vector.end( ) ) {
            int Lambda_id = (*p_Lambda);
            int y_id = index_y( i, Lambda_id );

            row.insert( y_id, 1.0 );
            p_Lambda++;
        }
        row_lb[num_con] = -DBL_MAX;
        row_ub[num_con] = 1.0;
        M->appendRow( row );
        num_con++;
        string str = "(";
        stringstream ss;
        ss << "(y)i@" << i << ")";
        str += ss.str( );
        char name[100];

        strcpy( name, str.c_str( ) );
    }
    cout << "build constraints (1e)" << endl;

    // This is the tooling capacity constraint.
    for ( int tf = 1; tf <= Num_Tooling_Family; tf++ ) {
        for ( int n = 1; n <= ( int ) Temperature_Set.size( ); n++ ) {
            vector < t_set >::iterator p_set = Temperature_Set.begin( ) + n - 1;
            CoinPackedVector row;
            for ( int i = 1; i <= Num_Machine; i++ ) {
                vii p_int = (*p_set).set_elements.begin( );
                while ( p_int != (*p_set).set_elements.end( ) ) {
                    int tau = (*p_int);
                    vector < int >Lambda_i_tf_tau;

                    get_Lambda( Lambda_i_tf_tau, i, tf, tau );
                    vii p_Lambda = Lambda_i_tf_tau.begin( );
                    while ( p_Lambda != Lambda_i_tf_tau.end( ) ) {
                        int Lambda_id = (*p_Lambda);

                        vector < Lambda_item >::iterator pL = Lambda.begin( ) + Lambda_id - 1;
                        vii p_find = find( (*pL).tooling_vec.begin( ), (*pL).tooling_vec.end( ), tf );
                        int offset = p_find - (*pL).tooling_vec.begin( );

                        vii pb = (*pL).b.begin( ) + offset;
                        int y_id = index_y( i, Lambda_id );

                        row.insert( y_id, (*pb) );
                        p_Lambda++;
                    } // lambda_iteration
                    p_int++;
                } // tau_iteration
            } // i_iteration
            vector < t_set > inter_set;
            get_inter_set( (*p_set), inter_set );
            vector < t_set >::iterator pm = inter_set.begin( );
            int sum = 0;

            while ( pm != inter_set.end( ) ) {
                int set_id = get_set_id( *pm );
                int pos = tf * Max_Num_Temperature + set_id;

                sum += n_t_n_tooling[pos];
                pm++;
            }
            row_lb[num_con] = -DBL_MAX;
            row_ub[num_con] = sum;
            M->appendRow( row );
            num_con++;
            string str = "(";
            stringstream ss;
            ss << "tf@" << tf << ",n@" << n << ")";
            str += ss.str( );
            char name[100];

            strcpy( name, str.c_str( ) );
        }
    }
    if ( new_old_model == 1 ) {
        cout << "build updated constraints (1f)" << endl;

        // This is the machine time constraint. The x<->y relationship is also taken into account in this constraint.
        // Though this constraint is not as tight as the pure x<->y constraint, it helps to reduce the number of constraints a lot
        // In ACTION 3 of the AT enhancement,the Load_Unload_Time need to be considered in this constraint
        for ( int i = 1; i <= Num_Machine; i++ ) {
            vector < int >::iterator p_Lambda = Lambda_i[i].int_vector.begin( );

            while ( p_Lambda != Lambda_i[i].int_vector.end( ) ) {
                int Lambda_id = (*p_Lambda);

                CoinPackedVector row;
                int index = index_L_sim_lambda( machine_sim[i], Lambda_id );
                vector < int >::iterator p_L = L_sim_lambda[index].second.int_vector.begin( );

                while ( p_L != L_sim_lambda[index].second.int_vector.end( ) ) {
                    int l = (*p_L);

                    vector < tooling_configure > TS;
                    get_S_i_l_Lambda( TS, i, l, Lambda_id );
                    vector < tooling_configure >::iterator p_TS = TS.begin( );
                    while ( p_TS != TS.end( ) ) {
                        int s = (*p_TS).id;
                        int x_id = index_x( i, l, s );


                        // modify this constraint to take into account the loading and unloading time
                        row.insert( x_id, n_l_chips[l] / rate[s] + Load_Unload_Time );
                        p_TS++;
                    }
                    p_L++;
                }
                int y_id = index_y( i, Lambda_id );

                row.insert( y_id, -H[i] );
                row_lb[num_con] = -DBL_MAX;
                row_ub[num_con] = 0;
                M->appendRow( row );
                num_con++;
                string str = "(";
                stringstream ss;
                ss << "i@" << i << ",Lambda@" << Lambda_id << ")";
                str += ss.str( );
                char name[100];

                strcpy( name, str.c_str( ) );
                p_Lambda++;
            }
        }
    }
    if ( new_old_model == 2 ) {
        cout << "build constraints (1f)" << endl;

        // This is the original machine time constraint
        // In ACTION 3 of the AT enhancement,the Load_Unload_Time need to be considered in this constraint
        for ( int i = 1; i <= Num_Machine; i++ ) {
            CoinPackedVector row;
            vector < int >::iterator p_L = L_i[i].int_vector.begin( );

            while ( p_L != L_i[i].int_vector.end( ) ) {
                int l = (*p_L);
                int sim = machine_sim[i];
                int d = lots_device[l];
                int index = index_S_sim_l( sim, l );

                vii p_s = S_sim_l[index].second.int_vector.begin( );
                while ( p_s != S_sim_l[index].second.int_vector.end( ) ) {
                    int s = (*p_s);
                    int x_id = index_x( i, l, s );


                    // modify this constraint to take into account the loading and unloading time
                    row.insert( x_id, n_l_chips[l] / rate[s] + Load_Unload_Time );
                    p_s++;
                }
                p_L++;
            }
            row_lb[num_con] = -DBL_MAX;
            row_ub[num_con] = H[i];
            M->appendRow( row );
            num_con++;
            string str = "(";
            stringstream ss;
            str += ss.str( );
            char name[100];

            strcpy( name, str.c_str( ) );
        }
    }
    cout << "build constraints (1g)" << endl;

    // this is the deviation constraint for key device
    for ( int k = 1; k <= Num_Keydevice; k++ ) {
        vector < int >::iterator p_int = Key_Devices.begin( ) + k - 1;
        int d = (*p_int);

        CoinPackedVector row;
        for ( int i = 1; i <= Num_Machine; i++ ) {
            int pos = i * Max_Num_Device + d;
            vector < int >::iterator p_L = L_i_d[pos].int_vector.begin( );

            while ( p_L != L_i_d[pos].int_vector.end( ) ) {
                int l = (*p_L);
                int sim = machine_sim[i];
                int index = index_S_sim_l( sim, l );

                vii p_s = S_sim_l[index].second.int_vector.begin( );
                while ( p_s != S_sim_l[index].second.int_vector.end( ) ) {
                    int s = (*p_s);
                    int x_id = index_x( i, l, s );

                    row.insert( x_id, n_l_chips[l] );
                    p_s++;
                }
                p_L++;
            }
        }
        int delta_id = x_limit + k;

        row.insert( delta_id, coef );
        row_lb[num_con] = n_k_minchips[d];
        row_ub[num_con] = DBL_MAX;
        M->appendRow( row );
        num_con++;
        string str = "(";
        stringstream ss;
        ss << "k@" << k << ",dev@" << d << ")";
        str += ss.str( );
        char name[100];

        strcpy( name, str.c_str( ) );
    }
    cout << "build constraints (1h)" << endl;

    // this is the deviation constraint for package device. NOTE it is not activated any more since Num_Package=0
    for ( int p = 1; p <= Num_Package; p++ ) {
        vector < int >::iterator p_int = Packages.begin( ) + p - 1;
        int d = (*p_int);

        CoinPackedVector row;
        for ( int i = 1; i <= Num_Machine; i++ ) {
            int pos = i * Max_Num_Device + d;
            vector < int >::iterator p_L = L_i_d[pos].int_vector.begin( );

            while ( p_L != L_i_d[pos].int_vector.end( ) ) {
                int l = (*p_L);
                int sim = machine_sim[i];
                int index = index_S_sim_l( sim, l );

                vii p_s = S_sim_l[index].second.int_vector.begin( );
                while ( p_s != S_sim_l[index].second.int_vector.end( ) ) {
                    int s = (*p_s);
                    int x_id = index_x( i, l, s );

                    row.insert( x_id, n_l_chips[l] );
                    p_s++;
                }
                p_L++;
            }
        }
        int delta_id = x_limit + Num_Keydevice + p;

        row.insert( delta_id, coef );
        row_lb[num_con] = n_p_minchips[d];
        row_ub[num_con] = DBL_MAX;
        M->appendRow( row );
        num_con++;
        string str = "(";
        stringstream ss;
        ss << "p@" << p << ",dev@" << d << ")";
        str += ss.str( );
        char name[100];

        strcpy( name, str.c_str( ) );
    }
    // constriants for deviation of KP
    cout << "build constraints (1i)" << endl;

    // This is the deviation constraint for key package
    for ( int id = 1; id <= ( int ) Key_PKG.size( ); id++ ) {
        int pkg_id = Key_PKG[id - 1];
        vector < int >dev;

        for ( int d = 1; d <= Num_Device; d++ ) {
            if ( device_PKG[d] == pkg_id ) {
                dev.push_back( d );
            }
        }
        CoinPackedVector row;
        for ( int i = 1; i <= Num_Machine; i++ ) {
            for ( int id2 = 1; id2 <= ( int ) dev.size( ); id2++ ) {
                int d = dev[id2 - 1];
                int pos = i * Max_Num_Device + d;
                vector < int >::iterator p_L = L_i_d[pos].int_vector.begin( );

                while ( p_L != L_i_d[pos].int_vector.end( ) ) {
                    int l = (*p_L);
                    int sim = machine_sim[i];
                    int index = index_S_sim_l( sim, l );

                    vii p_s = S_sim_l[index].second.int_vector.begin( );
                    while ( p_s != S_sim_l[index].second.int_vector.end( ) ) {
                        int s = (*p_s);
                        int x_id = index_x( i, l, s );

                        row.insert( x_id, n_l_chips[l] );
                        p_s++;
                    }
                    p_L++;
                }
            }
        }
        int delta_id = x_limit + Num_Keydevice + Num_Package + id;

        row.insert( delta_id, coef );
        row_lb[num_con] = n_kp_minchips[pkg_id];
        row_ub[num_con] = DBL_MAX;
        M->appendRow( row );
        num_con++;
        string str = "(";
        stringstream ss;
        ss << "id@" << id << ",kp@" << pkg_id << ")";
        str += ss.str( );
        char name[100];

        strcpy( name, str.c_str( ) );
    }
    // constriants for deviation of KPP
    cout << "build constraints (1j)" << endl;

    // This is the deviation constraint for key pin package
    for ( int id = 1; id <= ( int ) Key_PIN_PKG.size( ); id++ ) {
        int pin = Key_PIN_PKG[id - 1].first.first;
        int pkg_id = Key_PIN_PKG[id - 1].first.second;
        int target = Key_PIN_PKG[id - 1].second;
        vector < int >dev;

        for ( int d = 1; d <= Num_Device; d++ ) {
            if ( device_PKG[d] == pkg_id && device_PIN[d] == pin ) {
                dev.push_back( d );
            }
        }
        CoinPackedVector row;
        for ( int i = 1; i <= Num_Machine; i++ ) {
            for ( int id2 = 1; id2 <= ( int ) dev.size( ); id2++ ) {
                int d = dev[id2 - 1];
                int pos = i * Max_Num_Device + d;
                vector < int >::iterator p_L = L_i_d[pos].int_vector.begin( );

                while ( p_L != L_i_d[pos].int_vector.end( ) ) {
                    int l = (*p_L);
                    int sim = machine_sim[i];
                    int index = index_S_sim_l( sim, l );

                    vii p_s = S_sim_l[index].second.int_vector.begin( );
                    while ( p_s != S_sim_l[index].second.int_vector.end( ) ) {
                        int s = (*p_s);
                        int x_id = index_x( i, l, s );

                        row.insert( x_id, n_l_chips[l] );
                        p_s++;
                    }
                    p_L++;
                }
            }
        }
        int delta_id = x_limit + Num_Keydevice + Num_Package + ( int ) Key_PKG.size( ) + id;

        row.insert( delta_id, coef );
        row_lb[num_con] = target;
        row_ub[num_con] = DBL_MAX;
        M->appendRow( row );
        num_con++;
        string str = "(";
        stringstream ss;
        ss << "id@" << id << ",pkg@" << pkg_id << ",pin@" << pin << ")";
        str += ss.str( );
        char name[100];

        strcpy( name, str.c_str( ) );
    }
    cout << "num_con=" << num_con << endl;
}


/**
 * @brief 
 * 
 * @param M
 * @param cost
 * @param col_lb
 * @param col_ub
 * @param row_lb
 * @param row_ub
 */
void
AT::build_update_benefit_model( CoinPackedMatrix * M, double *cost, double *col_lb, double *col_ub, double *row_lb, double *row_ub )
{
    int num_con = 0;
    int num_var = 0;


    // initialize x variables
    for ( int l = 0; l <= Num_Lot - 1; l++ ) {
        col_lb[l] = 0.0;
        col_ub[l] = 1.0;
    }
    // initialize delta variables
    for ( int k = Num_Lot; k <= Num_Lot + Num_Keydevice + Num_Package - 1; k++ ) {
        col_lb[k] = 0.0;
        col_ub[k] = DBL_MAX;
    }
    M->setDimensions( 0, Num_Lot + Num_Keydevice + Num_Package );
    for ( int l = 0; l <= Num_Lot - 1; l++ ) {
        cost[l] = -w_l[l];
    }
    for ( int k = Num_Lot; k <= Num_Lot + Num_Keydevice - 1; k++ ) {
        int d = Key_Devices[k - Num_Lot];

        cost[k] = penalty[d];
    }
    for ( int k = Num_Lot + Num_Keydevice; k <= Num_Lot + Num_Keydevice + Num_Package - 1; k++ ) {
        int d = Packages[k - Num_Lot - Num_Keydevice];

        cost[k] = penalty[d];
    }
    for ( int k = 1; k <= Num_Keydevice; k++ ) {
        vector < int >::iterator p_int = Key_Devices.begin( ) + k - 1;
        int d = (*p_int);

        CoinPackedVector row;
        vii p_lot = Devices[d - 1].device_lots.begin( );
        while ( p_lot != Devices[d - 1].device_lots.end( ) ) {
            int l = (*p_lot);

            row.insert( l - 1, n_l_chips[l] );
            p_lot++;
        }
        row.insert( Num_Lot + k - 1, coef );
        row_lb[num_con] = n_k_minchips[d];
        row_ub[num_con] = DBL_MAX;
        M->appendRow( row );
        num_con++;
    }
    for ( int p = 1; p <= Num_Package; p++ ) {
        vector < int >::iterator p_int = Packages.begin( ) + p - 1;
        int d = (*p_int);

        CoinPackedVector row;
        vii p_lot = Devices[d - 1].device_lots.begin( );
        while ( p_lot != Devices[d - 1].device_lots.end( ) ) {
            int l = (*p_lot);

            row.insert( l - 1, n_l_chips[l] );
            p_lot++;
        }
        row.insert( Num_Lot + Num_Keydevice + p - 1, coef );
        row_lb[num_con] = n_p_minchips[d];
        row_ub[num_con] = DBL_MAX;
        M->appendRow( row );
        num_con++;
    }
}


/**
 * @brief get the index of element of vector L_sim_lambda given simid and Lamdua_id
 * 
 * @param simid
 * @param Lambda_id
 * 
 * @return 
 */
int
AT::index_L_sim_lambda( int simid, int Lambda_id )
{
    // get the index of element of vector L_sim_lambda given simid and Lamdua_id
    int index = -1;
    vector < pair < pair < int, int >, vec_int > >::iterator p = L_sim_lambda.begin( );

    while ( p != L_sim_lambda.end( ) ) {
        if ( (*p).first.first == simid && (*p).first.second == Lambda_id ) {
            index = p - L_sim_lambda.begin( );
        }
        p++;
    }

    // index=-1,cannot find the combination
    if ( index == -1 ) {
        cout << "sim=" << simid << ",Lambda_id=" << Lambda_id << ",WRONG index in index_L_sim_lambda()!" << endl;
    }
    return index;
}


/**
 * @brief greed assignment to solve the second level IP, in order to replace the LP part
 * 
 * @param fix_y
 * @param sub_soln
 * @param shortage
 * @param unassigned_lots
 * 
 * @return 
 */
double
AT::second_level_greedy( int fix_y[], vector < sub_soln_item > &sub_soln, vector < pair < int, double > >&shortage, vector < pair < pair < int, double >, double > >&unassigned_lots )
{
    // greed assignment to solve the second level IP, in order to replace the LP part
    // unassigned_lots   < <lot,shortage>,unit_price>, shortage is the shortage of the device the lot contains

    // initialize sub_soln
    // < < <i,Lambda_id>,time_used>,lot1,lot2,...>
    sub_soln.clear( );
    for ( int i = 1; i <= Num_Machine; i++ ) {
        sub_soln_item one_item;
        one_item.i = i;
        if ( fix_y[i] > 0 ) {
            one_item.Lambda_id = fix_y[i];
        } else {
            one_item.Lambda_id = -1;
        }
        one_item.time_used = 0.0;
        sub_soln.push_back( one_item );
    }

    // initialize shortage
    shortage.clear( );
    for ( int d = 1; d <= Num_Device; d++ ) {
        vii pfind = find( Key_Devices.begin( ), Key_Devices.end( ), d );
        if ( pfind != Key_Devices.end( ) ) { // d is a key device
            shortage.push_back( make_pair( d, n_k_minchips[d] ) );
        } else {
            vii pfind = find( Packages.begin( ), Packages.end( ), d );
            if ( pfind != Packages.end( ) ) { // d is a package device
                shortage.push_back( make_pair( d, n_p_minchips[d] ) );
            } else { // d is neither a key nor package device
                shortage.push_back( make_pair( d, -1E+10 ) );
            }
        }
    }

    // initialize unassigned_lots
    unassigned_lots.clear( );
    for ( int l = 1; l <= Num_Lot; l++ ) {
        pair < pair < int, double >, double >one_pair;

        one_pair.first.first = l;
        int dev = lots_device[l];

        if ( shortage[dev - 1].second > 0 ) {
            one_pair.first.second = w_l[l] + penalty[dev] / coef * n_l_chips[l];
        } else {
            one_pair.first.second = w_l[l];
        }
        one_pair.second = w_l[l] / n_l_chips[l];
        unassigned_lots.push_back( one_pair );
    }

    // construct benefit of machine i that already setup
    double *benefit = new double[Num_Machine + 1];

    for ( int i = 0; i <= Num_Machine; i++ ) {
        benefit[i] = 0.0;
    }
    // ------------------------------------------------------------------------------------
    vector < pair < pair < int, double >, double > > ::iterator p_lot = unassigned_lots.begin( );

    while ( p_lot != unassigned_lots.end( ) ) {
        int l = (*p_lot).first.first;

        for ( int i = 1; i <= Num_Machine; i++ ) {
            vector < pair < int, int > > ::iterator p_pair = sim_lambda_L[l - 1].second.sim_lambda_pairs.begin( );

            while ( p_pair != sim_lambda_L[l - 1].second.sim_lambda_pairs.end( ) ) {
                if ( machine_sim[i] == (*p_pair).first && sub_soln[i - 1].Lambda_id == (*p_pair).second ) { // the machine can be used to processed the lot
                    benefit[i] += n_l_chips[l];
                }
                p_pair++;
            }
        }
        p_lot++;
    }

    // ------------------------------------------------------------------------------------assign in a greedy way
    p_lot = unassigned_lots.begin( );
    while ( p_lot != unassigned_lots.end( ) ) {
        int erase_flag = 0;
        int l = (*p_lot).first.first;
        int i_selected = -1;
        double best_ben = -1E+6;
        double time_required_save = 0.0;

        for ( int i = 1; i <= Num_Machine; i++ ) {
            int s = max_rate_s( i, l, sub_soln[i - 1].Lambda_id );
            double time_required = n_l_chips[l] / rate[s] + Load_Unload_Time;
            vector < pair < int, int > > ::iterator p_pair = sim_lambda_L[l - 1].second.sim_lambda_pairs.begin( );

            while ( p_pair != sim_lambda_L[l - 1].second.sim_lambda_pairs.end( ) ) {
                if ( machine_sim[i] == (*p_pair).first && sub_soln[i - 1].Lambda_id == (*p_pair).second && sub_soln[i - 1].time_used + time_required <= H[i] ) { // the machine can be used to processed the lot
                    if ( benefit[i] > best_ben ) {
                        best_ben = benefit[i];
                        i_selected = i;
                        time_required_save = time_required;
                    }
                }
                p_pair++;
            }
        }
        if ( i_selected > 0 ) { // a machine is selected finally to process the lot
            sub_soln[i_selected - 1].lots.int_vector.push_back( l );
            sub_soln[i_selected - 1].time_used += time_required_save;
            int dev = lots_device[l];

            shortage[dev - 1].second -= n_l_chips[l];
            p_lot = unassigned_lots.erase( p_lot );
            erase_flag = 1;
            benefit[i_selected] -= n_l_chips[l];
        }
        if ( !erase_flag ) {
            p_lot++;
        }
    }

    // ------------------------------------------------------------------------------------
    double obj_greedy = compute_obj( sub_soln, shortage );

    cout << "obj_greedy=" << obj_greedy << endl;
    return obj_greedy;
    delete[]benefit;
}


/**
 * @brief 
 */
void
AT::get_sum_weight( )
{
    sum_weight = 0.0;
    double max_weight = -1000.0;

    for ( int l = 1; l <= Num_Lot; l++ ) {
        sum_weight += w_l[l];
        if ( w_l[l] > max_weight ) {
            max_weight = w_l[l];
        }
    }
    double max = -1E+6;

    for ( int l = 1; l <= Num_Lot; l++ ) {
        double temp = w_l[l] / n_l_chips[l];

        if ( temp > max ) {
            max = temp;
        }
    }
    coef = sum_weight / (10 * max);

    // initialize the penalty for key and package devices, these will be coefficients in the obj function
    for ( int d = 1; d <= Num_Device; d++ ) {
        penalty[d] = 0.0;
        int type = is_KD_PD( d );

        if ( type > 0 ) { // d is a key or package device
            penalty[d] = sum_weight;
            for ( int id = 1; id <= ( int ) Devices[d - 1].device_lots.size( ); id++ ) { // for all the lots containing the device
                int l = Devices[d - 1].device_lots[id - 1];

                penalty[d] += w_l[l];
            }
        }
    }
    // initialize the penalty for the key packages
    for ( int pkg = 1; pkg <= ( int ) PKG.size( ); pkg++ ) {
        PKG_penalty[pkg] = 0.0;
        double temp1 = 0.0, temp2 = 0.0;

        for ( int d = 1; d <= Num_Device; d++ ) {
            if ( device_PKG[d] == pkg ) {
                int qty = 0;

                for ( int l = 1; l <= Num_Lot; l++ ) {
                    if ( lots_device[l] == d ) {
                        qty += n_l_chips[l];
                    }
                }
                temp1 += penalty[d] * qty;
                temp2 += qty;
            }
        }
        if ( temp2 > 1 ) {
            PKG_penalty[pkg] = temp1 / temp2;
        } else {
            PKG_penalty[pkg] = 0.0;
        }
    }

    // initialize the penalty for the key pin packages
    // !! PIN_PKG_penalty [pkg_id][pin_id], NOTE!! pin_id!=pin number, it is the order id
    for ( int d = 1; d <= Num_Device; d++ ) {
        int temp = device_PIN[d];

        vii pfind = find( PIN_order.begin( ), PIN_order.end( ), temp );
        if ( pfind == PIN_order.end( ) ) {
            PIN_order.push_back( temp );
        }
    }
    PIN_PKG_penalty = new double[( int ) PKG.size( ) * ( int ) PIN_order.size( ) + 1];

    for ( int pkg = 1; pkg <= ( int ) PKG.size( ); pkg++ ) {
        for ( int id = 1; id <= ( int ) PIN_order.size( ); id++ ) {
            int index = (pkg - 1) * ( int ) PIN_order.size( ) + id - 1;

            PIN_PKG_penalty[index] = 0.0;
            double temp1 = 0.0, temp2 = 0.0;

            for ( int d = 1; d <= Num_Device; d++ ) {
                if ( device_PKG[d] == pkg && device_PIN[d] == PIN_order[id - 1] ) {
                    int qty = 0;

                    for ( int l = 1; l <= Num_Lot; l++ ) {
                        if ( lots_device[l] == d ) {
                            qty += n_l_chips[l];
                        }
                    }
                    temp1 += penalty[d] * qty;
                    temp2 += qty;
                }
            }
            if ( temp2 > 1 ) {
                PIN_PKG_penalty[index] = temp1 / temp2;
            } else {
                PIN_PKG_penalty[index] = 0.0;
            }
        }
    }
}


/**
 * @brief 
 * 
 * @param pkg_id package order in PKG (start from 1)
 * @param pin_num number of pins (not the order in PIN_order)
 * 
 * @return 
 */
double
AT::get_PIN_PKG_penalty( int pkg_id, int pin_num )
{
    // first parameter: package order in PKG (start from 1)
    // second parameter: number of pins (not the order in PIN_order)
    int pin_id = 0;

    for ( int id = 1; id <= ( int ) PIN_order.size( ); id++ ) {
        pin_id++;
        if ( PIN_order[id - 1] == pin_num ) {
            break;
        }
    }
    int index = (pkg_id - 1) * ( int ) PIN_order.size( ) + pin_id - 1;

    return PIN_PKG_penalty[index];
}


/**
 * @brief 
 * 
 * @param solution
 */
void
AT::adjust_LP_solution( double *solution )
{
    // truncate the LP solution
    for ( int id = 0; id <= x_limit; id++ ) {
        if ( solution[id] > 1E-06 && solution[id] < 1 - 1E-06 ) {
            double portion = solution[id];

            solution[id] = 0.0; // discard the lot
        }
    }
}


/**
 * @brief 
 * 
 * @param si
 * @param soln_A
 * @param K
 * 
 * @return 
 */
double
AT::local_branch_LP( OsiXxxSolverInterface * si, struct soln_pool_item &soln_A, int K )
{
    CoinPackedVector row;
    int num = 0;

    for ( int i = 1; i <= Num_Machine; i++ ) {
        int Lambda_A = soln_A.sub_soln[i - 1].Lambda_id;

        if ( Lambda_A > 0 ) {
            int id_A = index_y( i, Lambda_A );

            row.insert( id_A, -1 );
            num++;
        }
    }
    // add the local branch cuts
    si->addRow( row, -DBL_MAX, K - num );
    si->setHintParam( OsiDoDualInResolve, false, OsiHintDo );
    si->resolve( );
    Num_LP_solved++;
    double *solution = new double[y_limit + 1];

    if ( si->isProvenOptimal( ) ) {

        // get the LP solution
        CoinDisjointCopyN( si->getColSolution( ), y_limit + 1, solution );
    }
    int index = si->getNumRows( ) - 1;

    si->deleteRows( 1, &index );
    for ( int id = x_limit + Num_Keydevice + Num_Package + 1; id <= y_limit; id++ ) {
        si->setColBounds( id, 0, 0 );
    }
    int *fix_y = new int[Num_Machine + 1];

    for ( int i = 1; i <= Num_Machine; i++ ) {
        fix_y[i] = -1;
    }
    vector < vector < int > > Lambda_list; // <i,<Lambda_id> >

    Lambda_list.resize( Num_Machine );
    vector < vector < double > > Prob_list; // <i,<probability> >

    Prob_list.resize( Num_Machine );
    bool int_flag = true;
    for ( int id = x_limit + Num_Keydevice + Num_Package + 1; id <= y_limit; id++ ) {
        if ( solution[id] > 1E-06 ) {
            vector < index_node >::iterator p_node = index_vector.begin( ) + id;
            int i = (*p_node).i;
            int Lambda_id = (*p_node).Lambda_id;

            Lambda_list[i - 1].push_back( Lambda_id );
            Prob_list[i - 1].push_back( solution[id] );
        }
        if ( solution[id] > 1E-06 && solution[id] < 1 - 1E-06 ) {
            int_flag = false;
        }
    }
    bool primal_dual = false;
    int iter_counter = 0;
    double best_obj = soln_A.obj;

    while ( iter_counter <= 10 ) {
        if ( iter_counter == 0 ) {
            primal_dual = true;
        }

        // -----------------------------------------------------randomly selected fix_y[]
        for ( int i = 1; i <= Num_Machine; i++ ) {
            double rnd = rand( ) * 1.0 / RAND_MAX;
            double sum_prob = 0.0;

            for ( int j = 1; j <= ( int ) Lambda_list[i - 1].size( ); j++ ) {
                vector < double >::iterator pp = Prob_list[i - 1].begin( ) + j - 1;

                if ( rnd >= sum_prob && rnd < sum_prob + (*pp) ) {
                    fix_y[i] = (*(Lambda_list[i - 1].begin( ) + j - 1));
                    break;
                }
                sum_prob += (*pp);
            }
        }
        Num_Simulated++;
        for ( int i = 0; i <= y_limit; i++ ) {
            solution[i] = 0.0;
        }
        // ----------------------------------------------------
        if ( make_feasible( fix_y ) ) {

            // ---------------------------------------------------------------------------solve the proble with fix_y[] as LP
            // set the fix_y[] values
            vector < int >index_record;

            for ( int i = 1; i <= Num_Machine; i++ ) {
                if ( fix_y[i] > 0 ) {
                    int y_id = index_y( i, fix_y[i] );

                    si->setColBounds( y_id, 1, 1 );
                    index_record.push_back( y_id );
                }
            }
            if ( primal_dual ) {
                primal_dual = false;
                si->setHintParam( OsiDoDualInResolve, false, OsiHintDo );
            } else {
                si->setHintParam( OsiDoDualInResolve, true, OsiHintDo );
            }
            if ( LP_IP == 1 ) {
                si->resolve( );
                Num_LP_solved++;
            } else {
                si->branchAndBound( );
            }
            if ( si->isProvenOptimal( ) && si->getObjValue( ) < soln_A.obj ) { // only if the LP relaxation soln is better
                // get the LP solution
                CoinDisjointCopyN( si->getColSolution( ), y_limit + 1, solution );

                // ---------------------------------------------------------------------------adjust solution[]
                adjust_LP_solution( solution );
                vector < sub_soln_item > sub_soln;
                vector < pair < int, double > > shortage;
                vector < pair < pair < int, double >, double > > unassigned_lots;


                // -----------------------------------------------------------------------solve this subproblem heuristically
                double local_branch_obj = second_level_heuristic( solution, sub_soln, shortage, unassigned_lots, 2 );

                if ( local_branch_obj < best_obj ) {
                    best_obj = local_branch_obj;
                    copy( sub_soln.begin( ), sub_soln.end( ), soln_A.sub_soln.begin( ) );
                    copy( shortage.begin( ), shortage.end( ), soln_A.shortage.begin( ) );
                    soln_A.unassigned_lots.clear( );
                    soln_A.unassigned_lots.resize( ( int ) unassigned_lots.size( ) );
                    copy( unassigned_lots.begin( ), unassigned_lots.end( ), soln_A.unassigned_lots.begin( ) );
                    soln_A.obj = best_obj;
                }
            } // end_if
            // --------------------------------------------------------------------------set back the fix_y values
            for ( int i = 1; i <= ( int ) index_record.size( ); i++ ) {
                int y_id = index_record[i - 1];

                si->setColBounds( y_id, 0, 0 );
            }
        } else {
            cout << "infeasible setup" << endl;
            Num_Discarded++;
        }
        if ( int_flag ) {
            break;
        }
        iter_counter++;
    }
    delete[]solution;
    delete[]fix_y;
    return best_obj;
}


/**
 * @brief 
 * 
 * @param fix_y
 * 
 * @return 
 */
bool AT::make_feasible( int fix_y[] )
{
    // //---------------------------------------------------------------tooling_used[tf][tau]
    int *
    tooling_used = new int[Num_Tooling_Family * Num_Temperature];

    for ( int id = 0; id <= Num_Tooling_Family * Num_Temperature - 1; id++ ) {
        tooling_used[id] = 0;
    }
    for ( int i = 1; i <= Num_Machine; i++ ) {
        int
        Lambda_id = fix_y[i];

        if ( Lambda_id >= 1 ) {
            vector < Lambda_item >::iterator pL = Lambda.begin( ) + Lambda_id - 1;
            int
            tau = (*pL).temperature;


            // -----------------------------------------------
            vii p_tf = (*pL).tooling_vec.begin( );
            if ( (*p_tf) > 0 ) {
                while ( p_tf != (*pL).tooling_vec.end( ) ) {
                    int
                    tf = (*p_tf);
                    int
                    offset = p_tf - (*pL).tooling_vec.begin( );

                    vii p_b = (*pL).b.begin( ) + offset;
                    int
                    id = (tf - 1) * Num_Temperature + tau - 1;

                    tooling_used[id] += (*p_b);
                    p_tf++;
                }
            }
        }
    }
    bool feasible_flag = true;
    for ( int tf = 1; tf <= Num_Tooling_Family; tf++ ) {
        for ( int n = 1; n <= ( int ) Temperature_Set.size( ); n++ ) {
            int
            lhs = 0;

            vector < t_set >::iterator p_set = Temperature_Set.begin( ) + n - 1;
            vii p_int = (*p_set).set_elements.begin( );
            while ( p_int != (*p_set).set_elements.end( ) ) {
                int
                tau = (*p_int);
                int
                id = (tf - 1) * Num_Temperature + tau - 1;

                lhs += tooling_used[id];
                p_int++;
            }
            int
            id2 = (tf - 1) * ( int ) Temperature_Set.size( ) + n - 1;

            if ( lhs > tooling_sum_rhs[id2].second ) {
                feasible_flag = false;
                break;
            }
        }
    }
    delete[]tooling_used;
    return feasible_flag;
}


/**
 * @brief 
 */
void
AT::initialize_sil( )
{
    for ( int i = 1; i <= Num_Machine; i++ ) {
        vector < int >::iterator p_lot = L_i[i].int_vector.begin( );

        while ( p_lot != L_i[i].int_vector.end( ) ) {
            int l = (*p_lot);
            int sim = machine_sim[i];
            int d = lots_device[l];
            double max_rate = -1E+6;
            int max_rate_s = -1;
            int index = index_S_sim_l( sim, l );

            vii p_s = S_sim_l[index].second.int_vector.begin( );
            while ( p_s != S_sim_l[index].second.int_vector.end( ) ) {
                int s = (*p_s);

                if ( rate[s] > max_rate ) {
                    max_rate = rate[s];
                    max_rate_s = s;
                }
                p_s++;
            }
            pair < pair < int, int >, int >one_pair;

            one_pair.first.first = i;
            one_pair.first.second = l;
            one_pair.second = max_rate_s;
            sil.push_back( one_pair );
            p_lot++;
        }
    }
}


/**
 * @brief 
 */
void
AT::show_sil( )
{
    ofstream fout( "Debug/debug_sil.txt" );
    for ( int id = 0; id <= ( int ) sil.size( ) - 1; id++ ) {
        fout << "id=" << id << ",i=" << sil[id].first.first << ",l=" << sil[id].first.second << ",sil=" << sil[id].second << endl;
    }
    fout.close( );
}


/**
 * @brief 
 */
void
AT::initialize_S_sim_l( )
{
    for ( int sim = 1; sim <= ( int ) SIM.size( ); sim++ ) {
        int i = SIM[sim - 1].represented_machine_id;

        for ( int l = 1; l <= Num_Lot; l++ ) {
            vector < tooling_configure > TS;
            get_S( TS, i, l );
            if ( ( int ) TS.size( ) > 0 ) {
                pair < pair < int, int >, vec_int > one_pair;

                one_pair.first.first = sim;
                one_pair.first.second = l;
                vector < tooling_configure >::iterator p_TS = TS.begin( );
                while ( p_TS != TS.end( ) ) {
                    int s = (*p_TS).id;

                    one_pair.second.int_vector.push_back( s );
                    p_TS++;
                }
                S_sim_l.push_back( one_pair );
            }
        }
    }
}


/**
 * @brief 
 * 
 * @param sim
 * @param l
 * 
 * @return 
 */
int
AT::index_S_sim_l( int sim, int l )
{
    int index = -1;

    for ( int id = 1; id <= ( int ) S_sim_l.size( ); id++ ) {
        if ( S_sim_l[id - 1].first.first == sim && S_sim_l[id - 1].first.second == l ) {
            index = id - 1;
            break;
        }
    }
    if ( index < 0 ) {
        cout << "sim=" << sim << ",l=" << l << ",WRONG index!!! in index_S_sim_l()" << endl;
    }
    return index;
}


/**
 * @brief 
 */
void
AT::show_S_sim_l( )
{
    ofstream fout( "Debug/debug_S_sim_l.txt" );
    for ( int id = 1; id <= ( int ) S_sim_l.size( ); id++ ) {
        fout << "id=" << id - 1 << ",sim=" << S_sim_l[id - 1].first.first << ",l=" << S_sim_l[id - 1].first.second << ",s(sim,l)=";
        vii p = S_sim_l[id - 1].second.int_vector.begin( );
        while ( p != S_sim_l[id - 1].second.int_vector.end( ) ) {
            fout << (*p) << ",";
            p++;
        }
        fout << endl;
    }
    fout.close( );
}


/**
 * @brief 
 * 
 * @param prob_list
 * @param length
 * 
 * @return 
 */
int
AT::select_alpha( double prob_list[], int length )
{
    int selected = -100;
    double rnd = rand( ) * 1.0 / RAND_MAX;
    double sum = 0;

    for ( int i = 0; i <= length - 1; i++ ) {
        if ( sum - 1E-06 < rnd && rnd <= sum + prob_list[i] + 1E-06 ) {
            selected = i;
            break;
        }
        sum += prob_list[i];
    }
    return selected;
}


/**
 * @brief 
 * 
 * @param prob_list
 * @param avg_list
 * @param length
 * @param best_so_far
 * @param delta
 */
void
AT::update_alpha_prob( double prob_list[], double avg_list[], int length, double best_so_far, double delta )
{
    double *q = new double[length];
    double sum = 0;

    for ( int i = 0; i <= length - 1; i++ ) {
        q[i] = (best_so_far / avg_list[i]);
        q[i] = pow( q[i], delta );
        sum += q[i];
    }
    for ( int i = 0; i <= length - 1; i++ ) {
        prob_list[i] = q[i] / sum;
    }
    delete[]q;
}


/**
 * @brief 
 * 
 * @param candidate_list
 * @param RCL_length
 * @param SL_avg
 * @param SL_best
 * @param best_obj
 * @param delta
 * 
 * @return 
 */
int
AT::pick( vector < pair < pair < int, int >, double > >&candidate_list, int RCL_length, vector < double >&SL_avg, vector < double >&SL_best, double best_obj, double delta )
{
    cout << "SL_avg length=" << SL_avg.size( ) << endl;
    vector < double >q;
    double sum = 0;

    for ( int j = 1; j <= RCL_length; j++ ) {
        int sim = candidate_list[j - 1].first.first;
        int Lambda_id = candidate_list[j - 1].first.second;
        int index = index_L_sim_lambda( sim, Lambda_id );
        double temp;

        if ( SL_avg[index] < 1 ) { // this sim_lambda combination never be used before
            temp = 1;
        } else {
            temp = pow( (best_obj / SL_avg[index]) * pow( best_obj / SL_best[index], 2.0 ), delta );
        }
        q.push_back( temp );
        sum += temp;
    }
    vector < double >p( ( int ) q.size( ), 0 );

    for ( int j = 1; j <= ( int ) q.size( ); j++ ) {
        p[j - 1] = q[j - 1] / sum;
    }
    // adjust the probability
    double sum_p = 0;
    vector < int >indicator( ( int ) p.size( ), 0 );

    for ( int j = 1; j <= ( int ) p.size( ); j++ ) {
        if ( p[j - 1] < 0.01 ) {
            p[j - 1] = 0.01;
            indicator[j - 1] = 1;
            sum_p += p[j - 1];
        }
    }
    double min_p = 100;

    for ( int j = 1; j <= ( int ) p.size( ); j++ ) {
        if ( p[j - 1] < min_p && indicator[j - 1] < 1 ) {
            min_p = p[j - 1];
        }
    }
    double sum2 = 0;

    for ( int j = 1; j <= ( int ) p.size( ); j++ ) {
        if ( indicator[j - 1] < 1 ) {
            p[j - 1] = p[j - 1] / min_p;
            sum2 += p[j - 1];
        }
    }
    for ( int j = 1; j <= ( int ) p.size( ); j++ ) {
        if ( indicator[j - 1] < 1 ) {
            p[j - 1] = p[j - 1] / sum2 * (1 - sum_p);
        }
    }

    // now we have probability
    double rnd = rand( ) * 1.0 / RAND_MAX;

    sum = 0;
    int id = -100;

    for ( int j = 1; j <= ( int ) p.size( ); j++ ) {
        if ( sum - (1e-06) <= rnd && rnd < sum + p[j - 1] + (1e-06) ) {
            id = j - 1;
            break;
        }
        sum += p[j - 1];
    }
    return id;
}


/**
 * @brief 
 * 
 * @param RCL_length
 * 
 * @return 
 */
int
AT::pick( int RCL_length )
{
    // pick one randomly from RCL
    double delta = 1.0 / RCL_length;
    double rnd = rand( ) * 1.0 / RAND_MAX;
    int id;
    int found = -1;

    for ( id = 0; id <= RCL_length - 1; id++ ) {
        if ( delta * id <= rnd && rnd < delta * (id + 1) ) {
            found = id;
            break;
        }
    }
    return found;
}


/**
 * @brief based on the current simiid and tooling_used[] (NOTE: these are feasible) see if applying Lambda_id(tf,num,temperature) is feasible or not
 * 
 * @param simid
 * @param Lambda_id
 * @param tooling_used
 * @param sim_used
 * @param SIM_number
 * 
 * @return is feasible?
 * @retval 0 if infeasible
 * @retval 1 if feasible
 */
int
AT::is_sim_lambda_feasible( int simid, int Lambda_id, int *tooling_used, int *sim_used, int *SIM_number )
{
    // based on the current simiid and tooling_used[] (NOTE: these are feasible)
    // see if applying Lambda_id(tf,num,temperature) is feasible or not
    // return 0 if infeasible; 1 if feasible
    int flag_machine = 0, flag_tooling = 0;

    vector < Lambda_item >::iterator pL = Lambda.begin( ) + Lambda_id - 1;

    // can we find the machine?
    if ( sim_used[simid] + 1 <= SIM_number[simid] ) {
        flag_machine = 1;
    } else {
        return 0;
    }

    // can we find the tooling?
    // ---------------------------------------------------
    // ---------------------------------------------------
    vii p_tf = (*pL).tooling_vec.begin( );
    if ( (*p_tf) == 0 && ( int ) (*pL).tooling_vec.size( ) == 1 ) { // not require any tooling
        flag_tooling = 1;
    } else {
        while ( p_tf != (*pL).tooling_vec.end( ) ) {
            int tf = (*p_tf);
            int offset = p_tf - (*pL).tooling_vec.begin( );

            vii p_b = (*pL).b.begin( ) + offset;
            flag_tooling = 1;
            for ( int n = 1; n <= ( int ) Temperature_Set.size( ); n++ ) {
                vii pfind = find( Temperature_Set[n - 1].set_elements.begin( ), Temperature_Set[n - 1].set_elements.end( ), (*pL).temperature );
                if ( pfind != Temperature_Set[n - 1].set_elements.end( ) ) {
                    int lhs = 0;

                    for ( int j = 1; j <= ( int ) Temperature_Set[n - 1].set_elements.size( ); j++ ) {
                        int tau = Temperature_Set[n - 1].set_elements[j - 1];
                        int id = (tf - 1) * Num_Temperature + tau - 1;

                        lhs += tooling_used[id];
                    }
                    lhs += (*p_b);
                    int id2 = (tf - 1) * ( int ) Temperature_Set.size( ) + n - 1;

                    if ( lhs > tooling_sum_rhs[id2].second ) {
                        flag_tooling = 0;
                        break;
                    }
                }
            }
            if ( !flag_tooling ) {
                break;
            }
            p_tf++;
        }
    }
    if ( flag_machine && flag_tooling ) {
        return 1;
    } else {
        return 0;
    }
}


/**
 * @brief 
 * 
 * @param solution
 */
void
AT::generate_reports( const double *solution )
{
    double total_shortage = 0.0;

    for ( int id = x_limit + 1; id <= x_limit + Num_Keydevice + Num_Package; id++ ) {
        total_shortage += solution[id];
    }
    total_shortage = total_shortage * coef;
    double total_weight = 0.0;

    ofstream f_soln( "Debug/debug_solution.csv" );
    f_soln << "Machine_Instance_ID,Machine_Family_ID,Machine_Instance_Name,Lot_ID,Lot_Name,Quantity,Lot_Weight,Device ID,Device_Name,Route_ID,Tooling_Family_ID,Tooling_Family_Name,Certification,Value" << endl;
    int count = 0;

    for ( int iColumn = 0; iColumn <= x_limit; iColumn++ ) {
        double value = solution[iColumn];

        if ( value > 0.001 ) {
            count++;
            vector < index_node >::iterator p_ind = index_vector.begin( ) + iColumn;
            int i = (*p_ind).i;
            int l = (*p_ind).l;
            int s = (*p_ind).s;

            total_weight += w_l[l] * value;
            f_soln << i << "," << machine_mg[i] << ",";
            f_soln << MI[i - 1] << "," << l << ",";
            f_soln << LOT[l - 1] << "," << n_l_chips[l] << "," << w_l[l] << ",";
            int d = lots_device[l];

            f_soln << d << ",";
            f_soln << DEV[d - 1] << "," << s << ",";
            vector < tooling_configure >::iterator p_S = S.begin( ) + s - 1;
            vii p_int = (*p_S).tf.tools.begin( );
            int tf = (*p_int);

            f_soln << tf << ",";
            if ( tf > 0 ) {
                f_soln << TF[tf - 1] << "," << (*p_S).temperature << "," << value << endl;
            } else { // no tooling requirement
                f_soln << "," << (*p_S).temperature << "," << value << endl;
            }
            p_int++;
            while ( p_int != (*p_S).tf.tools.end( ) ) { // append other tooling
                for ( int m = 1; m <= 9; m++ ) {
                    f_soln << ",";
                }
                int tf = (*p_int);

                f_soln << tf << ",";
                if ( tf > 0 ) {
                    f_soln << TF[tf - 1] << "," << (*p_S).temperature << endl;
                } else {
                    f_soln << "," << (*p_S).temperature << "," << value << endl;
                }
                p_int++;
            }
            if ( value > 0 ) { // initialize lot_set_heur vector
                vii p_find = find( lot_set_heur.begin( ), lot_set_heur.end( ), l );

                if ( p_find == lot_set_heur.end( ) ) {
                    lot_set_heur.push_back( l );
                }
            }
        }
    }
    f_soln.close( );
    f_soln.clear( );

    // -------------------------------------------------
    total_weight = 0.0;
    f_soln.open( "Debug/solution.csv" );
    f_soln << "Machine_Instance,Machine_Family_Name,Lot_Name,Quantity,Lot_Weight,Device_Name,Tooling_Family_Name,Certification" << endl;
    count = 0;
    for ( int iColumn = 0; iColumn <= x_limit; iColumn++ ) {
        double value = solution[iColumn];

        if ( value > 0.001 ) {
            count++;
            vector < index_node >::iterator p_ind = index_vector.begin( ) + iColumn;
            int i = (*p_ind).i;
            int l = (*p_ind).l;
            int s = (*p_ind).s;

            total_weight += w_l[l] * value;
            int mach = 0;

            for ( int id = 1; id <= ( int ) Machine_vector.size( ); id++ ) {
                if ( Machine_vector[id - 1].id == i ) {
                    mach = id;
                }
            }
            int mg = machine_mg[i];

            f_soln << Machine_vector[mach - 1].name << "," << MF[mg - 1] << ",";
            vector < Machine >::iterator p_M = Machine_vector.begin( );
            vector < ch_array >::iterator p_ch = lot_name.begin( );
            while ( p_ch != lot_name.end( ) ) {
                if ( (*p_ch).id == l ) {
                    break;
                }
                p_ch++;
            }
            f_soln << (*p_ch).char_arry << "," << n_l_chips[l] << "," << w_l[l] << ",";
            int d = lots_device[l];

            p_ch = device_name.begin( );
            while ( p_ch != device_name.end( ) ) {
                if ( (*p_ch).id == d ) {
                    break;
                }
                p_ch++;
            }
            f_soln << (*p_ch).char_arry << ",";
            vector < tooling_configure >::iterator p_S = S.begin( ) + s - 1;
            vii p_int = (*p_S).tf.tools.begin( );
            int tf = (*p_int);

            if ( tf > 0 ) { // It is possible that no tooling is required for the operation
                f_soln << TF[tf - 1] << "," << (*p_S).temperature << endl;
            } else {
                f_soln << "," << (*p_S).temperature << endl;
            }
            p_int++;
            while ( p_int != (*p_S).tf.tools.end( ) ) {
                for ( int m = 1; m <= 6; m++ ) {
                    f_soln << ",";
                }
                int tf = (*p_int);

                if ( tf > 0 ) { // it is possible that no tooling is requrired for the operation
                    f_soln << TF[tf - 1] << "," << (*p_S).temperature << endl;
                } else {
                    f_soln << "," << (*p_S).temperature << endl;
                }
                p_int++;
            }
            if ( value > 0 ) { // initialize lot_set_heur vector
                vii p_find = find( lot_set_heur.begin( ), lot_set_heur.end( ), l );

                if ( p_find == lot_set_heur.end( ) ) {
                    lot_set_heur.push_back( l );
                }
            }
        }
    }
    f_soln.close( );

    // ----------------------------------------------------------------------
    show_lot_set_heur( );

    // --------------------------------------------------------------------------
    ofstream f_keydevice( "Debug/keydevice_production.csv" );
    f_keydevice << "Device,Target amount,Finished amount,Shortage" << endl;
    vii p_keydevice = Key_Devices.begin( );
    while ( p_keydevice != Key_Devices.end( ) ) {
        int d = (*p_keydevice);
        double production = 0.0;

        f_keydevice << DEV[d - 1] << "," << n_k_minchips[d] << ",";
        vii p_lot = (*(Devices.begin( ) + d - 1)).device_lots.begin( );
        while ( p_lot != (*(Devices.begin( ) + d - 1)).device_lots.end( ) ) {
            int l = (*p_lot);

            vii p_m = M_l[l].int_vector.begin( );
            while ( p_m != M_l[l].int_vector.end( ) ) {
                int i = (*p_m);
                int sim = machine_sim[i];
                int index = index_S_sim_l( sim, l );

                vii p_s = S_sim_l[index].second.int_vector.begin( );
                while ( p_s != S_sim_l[index].second.int_vector.end( ) ) {
                    int s = (*p_s);
                    int index = index_x( i, l, s );
                    double value = solution[index];

                    production += value * n_l_chips[l];
                    p_s++;
                }
                p_m++;
            }
            p_lot++;
        }
        f_keydevice << production << "," << n_k_minchips[d] - production << endl;
        p_keydevice++;
    }
    f_keydevice.close( );

    // --------------------------------------------------------------------------
    ofstream f_time( "Debug/time.csv" );
    f_time << "Machine,Time" << endl;
    for ( int i = 1; i <= Num_Machine; i++ ) {
        vector < int >::iterator p_Lambda = Lambda_i[i].int_vector.begin( );

        while ( p_Lambda != Lambda_i[i].int_vector.end( ) ) {
            int Lambda_id = (*p_Lambda);
            int offset = index_y( i, Lambda_id ) - x_limit - Num_Keydevice - Num_Package - ( int ) Key_PKG.size( ) -( int ) Key_PIN_PKG.size( ) - 1;
            int index = y_limit + 1 + offset;

            if ( solution[index] > 1E-06 ) {
                f_time << MI[i - 1] << "," << solution[index] << endl;
            }
            p_Lambda++;
        }
    }
    f_time.close( );

    // --------------------------------------------------------------------------
    ofstream f_kp( "Debug/key_package_production.csv" );
    f_kp << "Key_Package_Name,Target_amount,Finished_amount,Shortage" << endl;
    for ( int kp = 1; kp <= ( int ) Key_PKG.size( ); kp++ ) {
        int pkg_id = Key_PKG[kp - 1];
        int production = 0;

        for ( int l = 1; l <= Num_Lot; l++ ) {
            int d = lots_device[l];

            if ( device_PKG[d] == pkg_id ) {
                for ( int id = 1; id <= ( int ) M_l[l].int_vector.size( ); id++ ) {
                    int i = M_l[l].int_vector[id - 1];
                    int sim = machine_sim[i];
                    int index = index_S_sim_l( sim, l );

                    for ( int id2 = 1; id2 <= ( int ) S_sim_l[index].second.int_vector.size( ); id2++ ) {
                        int s = S_sim_l[index].second.int_vector[id2 - 1];
                        int x_id = index_x( i, l, s );

                        production += solution[x_id] * n_l_chips[l];
                    }
                }
            }
        }
        f_kp << PKG[pkg_id - 1] << "," << n_kp_minchips[pkg_id] << "," << production << "," << n_kp_minchips[pkg_id] - production << endl;
    }
    f_kp.close( );

    // --------------------------------------------------------------------------
    ofstream f_kpp( "Debug/key_pin_package_production.csv" );
    f_kpp << "Package_Name,Pin,Target_amount,Finished_amount,Shortage" << endl;
    for ( int kpp = 1; kpp <= ( int ) Key_PIN_PKG.size( ); kpp++ ) {
        int pkg_id = Key_PIN_PKG[kpp - 1].first.second;
        int pin = Key_PIN_PKG[kpp - 1].first.first;
        int target = Key_PIN_PKG[kpp - 1].second;
        int production = 0;

        for ( int l = 1; l <= Num_Lot; l++ ) {
            int d = lots_device[l];

            if ( device_PKG[d] == pkg_id && device_PIN[d] == pin ) {
                for ( int id = 1; id <= ( int ) M_l[l].int_vector.size( ); id++ ) {
                    int i = M_l[l].int_vector[id - 1];
                    int sim = machine_sim[i];
                    int index = index_S_sim_l( sim, l );

                    for ( int id2 = 1; id2 <= ( int ) S_sim_l[index].second.int_vector.size( ); id2++ ) {
                        int s = S_sim_l[index].second.int_vector[id2 - 1];
                        int x_id = index_x( i, l, s );

                        production += solution[x_id] * n_l_chips[l];
                    }
                }
            }
        }
        f_kpp << PKG[pkg_id - 1] << "," << pin << "," << target << "," << production << "," << target - production << endl;
    }
    f_kpp.close( );
}


/**
 * @brief convert a solution_pool_item to a solution
 * 
 * @param soln
 * @param solution
 */
void
AT::soln_pool_item_to_solution( struct soln_pool_item &soln, double *solution )
{
    // convert a solution_pool_item to a solution
    for ( int id = 0; id <= y_limit + (y_limit - x_limit); id++ ) {
        solution[id] = 0.0;
    }
    vector < pair < int, int > > production;

    for ( int d = 1; d <= Num_Device; d++ ) {
        production.push_back( make_pair( d, 0 ) );
    }
    // file x_ils and y_i Lambda
    for ( int id = 1; id <= ( int ) soln.sub_soln.size( ); id++ ) {
        int i = soln.sub_soln[id - 1].i;
        int Lambda_id = soln.sub_soln[id - 1].Lambda_id;

        if ( Lambda_id > 0 ) { // the machine is in used
            for ( int id2 = 1; id2 <= ( int ) soln.sub_soln[id - 1].lots.int_vector.size( ); id2++ ) {
                int l = soln.sub_soln[id - 1].lots.int_vector[id2 - 1];
                int s = max_rate_s( i, l, Lambda_id );
                int index = index_x( i, l, s );

                solution[index] = 1.0;
                index = index_y( i, Lambda_id );
                solution[index] = 1.0;
                index = y_limit + index_y( i, Lambda_id ) - x_limit - Num_Keydevice - Num_Package - ( int ) Key_PKG.size( ) -( int ) Key_PIN_PKG.size( );
                solution[index] = soln.sub_soln[id - 1].time_used;
                int d = lots_device[l];

                production[d - 1].second += n_l_chips[l];
            }
        }
    }
    // fill delta
    int solution_id = x_limit;

    for ( int id = 1; id <= ( int ) Key_Devices.size( ); id++ ) {
        int d = Key_Devices[id - 1];

        solution_id++;
        if ( production[d - 1].second >= n_k_minchips[d] ) {
            solution[solution_id] = 0.0;
        } else {
            solution[solution_id] = n_k_minchips[d] - production[d - 1].second;
            solution[solution_id] = solution[solution_id] / coef;
        }
    }
    for ( int id = 1; id <= ( int ) Packages.size( ); id++ ) {
        int d = Packages[id - 1];

        solution_id++;
        if ( production[d - 1].second >= n_p_minchips[d] ) {
            solution[solution_id] = 0.0;
        } else {
            solution[solution_id] = n_p_minchips[d] - production[d - 1].second;
            solution[solution_id] = solution[solution_id] / coef;
        }
    }

    // get the production for KP and KPP
    vector < int >PKG_production( ( int ) PKG.size( ), 0 );
    vector < int >PIN_PKG_production( ( int ) PKG.size( ) * ( int ) PIN_order.size( ) + 1, 0 );

    for ( int i = 1; i <= Num_Machine; i++ ) {
        int Lambda_id = soln.sub_soln[i - 1].Lambda_id;

        vii p_lot = soln.sub_soln[i - 1].lots.int_vector.begin( );
        while ( p_lot != soln.sub_soln[i - 1].lots.int_vector.end( ) ) {
            int l = (*p_lot);
            int d = lots_device[l];
            int pkg_id = device_PKG[d];
            int pin_num = device_PIN[d];

            vii pfind = find( PIN_order.begin( ), PIN_order.end( ), pin_num );
            int pin_order = pfind - PIN_order.begin( ) + 1;

            PKG_production[pkg_id - 1] += n_l_chips[l];
            int index = (pkg_id - 1) * ( int ) PIN_order.size( ) + pin_order - 1;

            PIN_PKG_production[index] += n_l_chips[l];
            p_lot++;
        }
    }
    for ( int kp = 1; kp <= ( int ) Key_PKG.size( ); kp++ ) {
        solution_id++;
        int pkg_id = Key_PKG[kp - 1];
        int diff = n_kp_minchips[pkg_id] - PKG_production[pkg_id - 1];

        if ( diff > 0 ) {
            solution[solution_id] = diff / coef;
        } else {
            solution[solution_id] = 0.0;
        }
    }
    for ( int kpp = 1; kpp <= ( int ) Key_PIN_PKG.size( ); kpp++ ) {
        solution_id++;
        int pkg_id = Key_PIN_PKG[kpp - 1].first.second;
        int pin_num = Key_PIN_PKG[kpp - 1].first.first;

        vii pfind = find( PIN_order.begin( ), PIN_order.end( ), pin_num );
        int pin_order = pfind - PIN_order.begin( ) + 1;
        int index = (pkg_id - 1) * PIN_order.size( ) + pin_order - 1;
        int diff = Key_PIN_PKG[kpp - 1].second - PIN_PKG_production[index];

        if ( diff > 0 ) {
            solution[solution_id] = diff / coef;
        } else {
            solution[solution_id] = 0.0;
        }
    }
}


/**
 * @brief 
 * 
 * @param soln
 */
void
AT::minimize_makespan( struct soln_pool_item &soln )
{
    bool exit_flag = false;
    while ( !exit_flag ) {

        // get the makespan
        double makespan = 0.0;
        int makespan_id = -1;

        for ( int id = 1; id <= ( int ) soln.sub_soln.size( ); id++ ) {
            int i = soln.sub_soln[id - 1].i;
            int Lambda_id = soln.sub_soln[id - 1].Lambda_id;

            if ( Lambda_id > 0 ) { // the machine is in used
                double time_used = soln.sub_soln[id - 1].time_used;

                if ( time_used > makespan ) {
                    makespan = time_used;
                    makespan_id = id;
                }
            }
        }
        cout << "current makespan=" << makespan << endl;
        if ( makespan_id > 0 ) {
            exit_flag = true;
            for ( int id = 1; id <= ( int ) soln.sub_soln[makespan_id - 1].lots.int_vector.size( ); id++ ) {
                int l = soln.sub_soln[makespan_id - 1].lots.int_vector[id - 1];


                // try to assign lot l to some other machine
                vector < int >assignable;

                for ( int id2 = 1; id2 <= ( int ) soln.sub_soln.size( ); id2++ ) {
                    int i = soln.sub_soln[id2 - 1].i;
                    int sim = machine_sim[i];
                    int Lambda_id = soln.sub_soln[id2 - 1].Lambda_id;

                    if ( Lambda_id > 0 ) {
                        vector < pair < int, int > > ::iterator p_pair = sim_lambda_L[l - 1].second.sim_lambda_pairs.begin( );

                        while ( p_pair != sim_lambda_L[l - 1].second.sim_lambda_pairs.end( ) ) {
                            if ( (*p_pair).first == sim && (*p_pair).second == Lambda_id ) {
                                assignable.push_back( id2 );
                                break;
                            }
                            p_pair++;
                        }
                    }
                }
                if ( ( int ) assignable.size( ) >= 1 ) { // lot l can be assgined to the vector
                    int s_from = max_rate_s( soln.sub_soln[makespan_id - 1].i, l, soln.sub_soln[makespan_id - 1].Lambda_id );
                    double time_from = n_l_chips[l] / rate[s_from] + Load_Unload_Time;
                    double best_time = 1E+10;
                    double best_ID = -1;

                    for ( int id3 = 1; id3 <= ( int ) assignable.size( ); id3++ ) {
                        int ID = assignable[id3 - 1];
                        int s_to = max_rate_s( soln.sub_soln[ID - 1].i, l, soln.sub_soln[ID - 1].Lambda_id );
                        double time_to = n_l_chips[l] / rate[s_to] + Load_Unload_Time;

                        if ( soln.sub_soln[ID - 1].time_used + time_to <= H[soln.sub_soln[ID - 1].i] && soln.sub_soln[ID - 1].time_used + time_to < makespan - 0.0001 ) {
                            double new_time = soln.sub_soln[ID - 1].time_used + time_to;

                            if ( new_time < soln.sub_soln[makespan_id - 1].time_used - time_from ) {
                                new_time = soln.sub_soln[makespan_id - 1].time_used - time_from;
                            }
                            if ( new_time < best_time ) {
                                best_time = new_time;
                                best_ID = ID;
                            }
                        }
                    }
                    if ( best_ID > 0 ) {
                        vii pfind = find( soln.sub_soln[makespan_id - 1].lots.int_vector.begin( ), soln.sub_soln[makespan_id - 1].lots.int_vector.end( ), l );
                        soln.sub_soln[makespan_id - 1].lots.int_vector.erase( pfind );
                        soln.sub_soln[makespan_id - 1].time_used -= time_from;
                        soln.sub_soln[best_ID - 1].lots.int_vector.push_back( l );
                        int s_to_best = max_rate_s( soln.sub_soln[best_ID - 1].i, l, soln.sub_soln[best_ID - 1].Lambda_id );
                        double time_to_best = n_l_chips[l] / rate[s_to_best] + Load_Unload_Time;

                        soln.sub_soln[best_ID - 1].time_used += time_to_best;
                        exit_flag = false;
                        break;
                    }
                }
            }
        } else {
            cout << "Wrong makespan id,probably no machine assignment" << endl;
            abort( );
        }
    }
}


/**
 * @brief 
 */
void
AT::show_targets( )
{
    ofstream f_target( "Debug/debug_Targets.txt" );
    f_target << "Target for key devices" << endl;
    for ( int id = 1; id <= ( int ) Key_Devices.size( ); id++ ) {
        int dev = Key_Devices[id - 1];

        f_target << DEV[dev - 1] << "," << n_k_minchips[dev] << endl;
    }
    f_target << "Target for key packages" << endl;
    for ( int id = 1; id <= ( int ) Key_PKG.size( ); id++ ) {
        int pkg = Key_PKG[id - 1];

        f_target << PKG[pkg - 1] << "," << n_kp_minchips[pkg] << endl;
    }
    f_target << "Target for key pin packages" << endl;
    for ( int id = 1; id <= ( int ) Key_PIN_PKG.size( ); id++ ) {
        int pin = Key_PIN_PKG[id - 1].first.first;
        int pkg = Key_PIN_PKG[id - 1].first.second;
        int target = Key_PIN_PKG[id - 1].second;

        f_target << PKG[pkg - 1] << "," << pin << "," << target << endl;
    }
    f_target.close( );
}


/**
 * @brief 
 */
void
AT::show_PIN_PKG( )
{
    ofstream fpkg( "Debug/debug_PIN_PKG.txt" );
    fpkg << "ID,PKG Name,PKG_penalty" << endl;
    for ( int id = 1; id <= ( int ) PKG.size( ); id++ ) {
        fpkg << id << "," << PKG[id - 1] << "," << PKG_penalty[id] << endl;
    }
    fpkg << endl;
    for ( int id = 1; id <= ( int ) PIN_order.size( ); id++ ) {
        fpkg << PIN_order[id - 1] << ",";
    }
    fpkg << endl;
    fpkg << "Device ID,Device Name,PKG Name,PIN" << endl;
    cout << "DEV.size is: " << ( int ) DEV.size( ) << endl;
    for ( int d = 1; d <= Num_Device; d++ ) {
        fpkg << d << "," << DEV[d - 1] << "," << (device_PKG[d] < 1 ? "__no pkg__" : PKG[device_PKG[d] - 1]) << "," << device_PIN[d] << endl;
    }
    fpkg.close( );
}


/**
 * @brief 
 * 
 * @param best_soln
 */
void
AT::machine_resetup( struct soln_pool_item &best_soln )
{
    // Enhancement Action 1
    // If a setup (unique machine + tooling combination) runs out of WIP, the model will re-setup that specific machine(s)
    // by choosing the NEXT BEST SETUP to run from the WIP that has not been allocated yet
    // ---------------------------------------------------------------Need to recover the time horizone H[] due the change for initial lots
    for ( int j = 1; j <= Num_Machine; j++ ) {
        if ( effective_starting_time[j] <= 10000 ) { // if the initial lot can be processed by the machine
            H[j] += effective_starting_time[j]; //Mike: sums all the machine start time; Initial lots will have value.; Populated by process_initial_lot
        } else {
            H[j] = 0.0;
        }
    }
    cout << "---------------------------------------------------------- Enhancement to resetup the machines when they are idle" << endl;
    double eps = 1E-06;
    vector < int >mc_no_GRASP_initial; // this vector stores the machines that are not used in GRASP solution but used to process initial lots
    struct soln_pool_item GRASP_soln = best_soln; // don't want to modify the original best solution

    for ( int j = 1; j <= ( int ) GRASP_soln.sub_soln.size( ); j++ ) { //Mike: loops to all solution
        if ( GRASP_soln.sub_soln[j - 1].Lambda_id > 0 ) { //Mike: Checks if lambda is used in the solution
            pair < sub_soln_item, double >one_pair; // the second double component stores the info of starting time

            one_pair.first = GRASP_soln.sub_soln[j - 1];
            int i = one_pair.first.i;

            if ( effective_starting_time[i] < 10000 ) { // if the initial lot can be processed by the machine
                one_pair.second = effective_starting_time[i]; // this is the starting time of the solution except the initial lots
            } else {
                one_pair.second = H[i];
            }
            enhanced_solution.push_back( one_pair ); //Mike: push back starting time. for non initial lots, same with machine hours. for machine with inital lots, concider effective_starting_time
        } else { // for the machines that not used in the GRASP solution
            int i = GRASP_soln.sub_soln[j - 1].i;

            for ( int id = 1; id <= ( int ) initial_running_lot.size( ); id++ ) {
                if ( i == initial_running_lot[id - 1].machine_id ) { // if the machine is used to process initial lots
                    mc_no_GRASP_initial.push_back( i );
                    break;
                }
            }
        }
    }
    cout << "output mc_no_GRASP_initial" << endl;
    for ( int j = 1; j <= ( int ) mc_no_GRASP_initial.size( ); j++ ) {
        cout << mc_no_GRASP_initial[j - 1] << ",";
    }
    cout << endl;

    // malloc the following arrays for spare machine/tooling pieces
    int *tooling_used = new int[Num_Tooling_Family * Num_Temperature]; //Mike possible: might need to include package.
    int *sim_used = new int[( int ) SIM.size( ) + 1];
    int *SIM_number = new int[( int ) SIM.size( ) + 1];


    // clear the arrays
    for ( int id = 0; id <= Num_Tooling_Family * Num_Temperature - 1; id++ ) {
        tooling_used[id] = 0;
    }
    for ( int id = 0; id <= ( int ) SIM.size( ); id++ ) {
        sim_used[id] = 0;
        SIM_number[id] = 0;
    }
    // modify the arrays according to the current soln GRASP_soln
    vector < int >idle_machines;

    for ( int j = 1; j <= ( int ) GRASP_soln.sub_soln.size( ); j++ ) { // loop over all the machines
        int machine_id = GRASP_soln.sub_soln[j - 1].i;

        if ( GRASP_soln.sub_soln[j - 1].time_used < eps && GRASP_soln.sub_soln[j - 1].Lambda_id < 1 && effective_starting_time[machine_id] < eps ) { // the machine is idle
            // The reason to add the condition "effective_starting_time[machine_id]<eps" is b/c it is possible that a machine is processing an initial lot.
            // However,it is not activated in the GRASP solution. Such machine is actually NOT idle.
            idle_machines.push_back( machine_id );
        } else { // the machine is running
            // -----------------------------------------------------------------update tooling_used[]
            int Lambda_id = GRASP_soln.sub_soln[j - 1].Lambda_id;

            if ( Lambda_id >= 1 ) { // If a machine is used to process initial lots and it is not used in the GRASP solution, then there is no tooling info
                vector < Lambda_item >::iterator pL = Lambda.begin( ) + Lambda_id - 1;
                int temperature = (*pL).temperature;

                for ( int id = 1; id <= ( int ) (*pL).tooling_vec.size( ); id++ ) {
                    int tf = (*pL).tooling_vec[id - 1];
                    int b = (*pL).b[id - 1];
                    int pos = (tf - 1) * Num_Temperature + temperature - 1;

                    tooling_used[pos] += b;
                }
            }

            // ------------------------------------------------------------------update sim_used
            int simid = machine_sim[machine_id];

            sim_used[simid]++;
        }
    }
    cout << "idle_machines:" << endl;
    for ( int j = 1; j <= ( int ) idle_machines.size( ); j++ ) {
        cout << idle_machines[j - 1] << ",";
    }
    cout << endl;

    // //------------------------------------------------------------------------initialize SIM_number[];
    for ( int i = 1; i <= Num_Machine; i++ ) {
        int simid = machine_sim[i];

        SIM_number[simid]++;
    }
    // ------------------------------------------------------------------------------------------------------------
    // ------------------------------------------------------------------------------------------------------------
    // generate lot_remain---------------------------------------------
    vector < int >lot_remain;
    vector < int >assigned_lots;

    for ( int j = 1; j <= ( int ) GRASP_soln.sub_soln.size( ); j++ ) {//Mike: loop to all sub solutions
        for ( int id = 1; id <= ( int ) GRASP_soln.sub_soln[j - 1].lots.int_vector.size( ); id++ ) { //Mike: loop to lots in sub solution
            int l = GRASP_soln.sub_soln[j - 1].lots.int_vector[id - 1];

            assigned_lots.push_back( l ); //Mike: store lots in sub solution
        }
    }
    for ( int j = 1; j <= Num_Lot; j++ ) {//Mike: find lots that has not been assigned in grasp solution. and store to lot_remain
        vii pfind = find( assigned_lots.begin( ), assigned_lots.end( ), j );
        if ( pfind == assigned_lots.end( ) ) {
            lot_remain.push_back( j );
        }
    }

    // generate production for each device-----------------------------
    vector < int >production( Num_Device, 0 );

    for ( int j = 1; j <= ( int ) GRASP_soln.sub_soln.size( ); j++ ) { //Mike: get all lots in sub solution and get total number of chips for each device
        for ( int id = 1; id <= ( int ) GRASP_soln.sub_soln[j - 1].lots.int_vector.size( ); id++ ) {
            int l = GRASP_soln.sub_soln[j - 1].lots.int_vector[id - 1]; //Mike: get lots
            int d = lots_device[l];//Mike: get devices in lots

            production[d - 1] += n_l_chips[l]; //Mike: Store total number of chips of each device
        }
    }
    vector < pair < double, vec_int > >machine_lambda_benefit; // it is used for machine-lambda combination

    for ( int machine_id = 1; machine_id <= ( int ) Machine_vector.size( ); machine_id++ ) {
        for ( int id = 1; id <= ( int ) Lambda_i[machine_id].int_vector.size( ); id++ ) {
            pair < double, vec_int > one_pair;

            one_pair.first = 0;
            one_pair.second.int_vector.clear( );
            machine_lambda_benefit.push_back( one_pair );//Mike: not sure what is the use
        }
    }
    // --------------------
    vector < pair < int, pair < int, double > > >uptime; // this vector keep a records of the current uptime

    // Type 1: the machine is used in the GRASP solution and thus in enhanced_solution (it doesn't matter if the machine is used to process initial lot or not)
    // Type 2: the machine is used to process initial lot but not used in the GRASP solution. In other words, the machine can be available sometime later.
    for ( int id = 1; id <= ( int ) enhanced_solution.size( ); id++ ) { // NOTE: it is the position in the vector <enhanced_solution>
        double time = enhanced_solution[id - 1].first.time_used + enhanced_solution[id - 1].second; // time->when the machine will be available

        uptime.push_back( make_pair( 1, make_pair( id, time ) ) ); // record the id-th used time in the vector <enhanced_solution>
    }
    for ( int id = 1; id <= ( int ) mc_no_GRASP_initial.size( ); id++ ) {
        int i = mc_no_GRASP_initial[id - 1];

        uptime.push_back( make_pair( 2, make_pair( i, effective_starting_time[i] ) ) );
    }
    sort( uptime.begin( ), uptime.end( ), compare_int_int_double ); // sort the vector <uptime> in aescending order
    // ----------------------
    while ( ( int ) uptime.size( ) >= 1 ) {
        pair < int, pair < int, double > > next_uptime; // prepare for the resetup machine' next uptime
        double time_used = uptime[0].second.second;

        cout << "time_used:" << time_used << endl;
        if ( time_used > eps ) { // if time_used=0, then the machine is idle
            // for the machines that are being run and will be the first to finish the job
            int type = uptime[0].first; // get the type of the element
            int machine_id = -100;
            int Lambda_id = -100;

            if ( type == 1 ) {
                int id = uptime[0].second.first;


                // need to detach the tooling from the machine, reduce tooling_used[] and sim_used[]
                machine_id = enhanced_solution[id - 1].first.i;
                idle_machines.push_back( machine_id ); // append machine_id as a new idle machine
                Lambda_id = enhanced_solution[id - 1].first.Lambda_id;
                struct date_time one_dt = increase_date_time( General_Snapshot_time, time_used );

                cout << "Try to reset the machine " << machine_id << " at time " << one_dt.str << "(" << time_used << "hr) with" << " (simid=" << machine_sim[machine_id] << " and Lambda_id=" << Lambda_id << ")" << endl;
                vector < Lambda_item >::iterator pL = Lambda.begin( ) + Lambda_id - 1;
                int temperature = (*pL).temperature;

                for ( int j = 1; j <= ( int ) (*pL).tooling_vec.size( ); j++ ) {
                    int tf = (*pL).tooling_vec[j - 1];
                    int b = (*pL).b[j - 1];
                    int pos = (tf - 1) * Num_Temperature + temperature - 1;

                    tooling_used[pos] -= b;
                }
                int simid = machine_sim[machine_id];

                sim_used[simid]--;

                // the process of type 2 is wrong now because we have known the initial setup in Yufen's code.
                // So the tooling info of type 2 machine has been known.
                // actaully we don't need to consider type 2 anymore. we need to change all type 2 back to type 1.
            } else { // type==2
                // the next available machine will be a machine processing initial lots
                machine_id = uptime[0].second.first;
                struct date_time one_dt = increase_date_time( General_Snapshot_time, time_used );

                cout << "Try to reset the machine " << machine_id << " at time " << one_dt.str << "(" << time_used << "hr) with" << " (simid=" << machine_sim[machine_id] << " and no tooling requirement)" << endl;

                // NOTE: don't need to adjust the tooling info since no tooling is used to process initial lots
                // Lambda_id will be -100 in this case
                int simid = machine_sim[machine_id];

                sim_used[simid]--;
            }
            // /---------------------------------------------------------------------------------Now try to build a list according to sim_used[],tooling_used[] and the unassigned lots
            // clear the vector <machine_lambda_benefit>
            for ( int j = 1; j <= ( int ) machine_lambda_benefit.size( ); j++ ) {
                machine_lambda_benefit[j - 1].first = 0.0;
                machine_lambda_benefit[j - 1].second.int_vector.clear( );
            }
            vector < int >affected_dev; // This is actually reduncdant

            // ---------------------------------------------------------------------------------compute the benefit
            // when a machine is idle, its tooling will be detached
            // it is possible that some other machine-tooling combination is benefitial
            // time_used is the time when to resetup the machines (the finished time of the previous setup)
            // if Lambda_id=-100, then machine-id is of type 2
            update_benefit_resetup( machine_id, Lambda_id, time_used, machine_lambda_benefit, lot_remain, production, affected_dev, tooling_used, sim_used, SIM_number, idle_machines );

            // ---------------------------------------------------------------------------------build the CL
            vector < pair < pair < int, int >, double > > CL;

            construct_CL_resetup( CL, machine_lambda_benefit );
            sort( CL.begin( ), CL.end( ), compare_candidates ); // sort the candidate of CL
            // investigate the top element of CL
            bool recover_flag = false;

            if ( ( int ) CL.size( ) == 0 ) {
                recover_flag = true;
                cout << "keep original setup 1" << endl;
            } else {
                if ( CL[0].second < eps ) {
                    recover_flag = true;
                    cout << "keep original setup 2" << endl;
                }
            }
            if ( recover_flag ) { // the setup should be recover (there is no beneficial setup)
                // ----------------------------------------------------------------------reover to the original setup
                // NOTE that in this case not change over time will be induced
                // idle_machines.pop_back();  // remove the last element, which is the machine just added in the current iteration
                // comment out this part, since the machine and tooling will be detached no matter it is beneficial or not
            } else { // in this case, resetting the machine will be beneficial
                // NOTE: It is possible that the current (machine_id,Lamda_id) still can be used to process lots. In that case, keep the original setup
                bool keep_org_setup = false;

                if ( type == 1 ) { // only consider type 1 machine when detecting keep_org_setup since type 2 machine doesn't have setup
                    int pos_org_setup = 0;

                    for ( int i = 1; i <= ( int ) Machine_vector.size( ); i++ ) {
                        bool found_flag = false;
                        for ( int j = 1; j <= ( int ) Lambda_i[i].int_vector.size( ); j++ ) {
                            if ( i == machine_id && Lambda_i[i].int_vector[j - 1] == Lambda_id ) { // found the machine-lambda combination
                                found_flag = true;
                                break;
                            } else {
                                pos_org_setup++;
                            }
                        }
                        if ( found_flag ) {
                            break;
                        }
                    }
                    if ( machine_lambda_benefit[pos_org_setup].first > eps ) {
                        keep_org_setup = true;
                        cout << "keep the original setup" << endl;
                    }
                }

                // --------------------------------------------------------------------------------
                double resetup_time = 0; // NOTE that it is time to consider the change over time. If the the machine keep the original setup

                // there is no change over time. OW,taken into account the change over time
                int machine_selected, Lambda_id_selected;

                if ( keep_org_setup ) {
                    machine_selected = machine_id;
                    Lambda_id_selected = Lambda_id;
                    resetup_time = 0;
                } else {
                    cout << "choose from CL" << endl;
                    machine_selected = CL[0].first.first;
                    Lambda_id_selected = CL[0].first.second;
                    resetup_time = 0;
                    vector < Lambda_item >::iterator pp = Lambda.begin( ) + Lambda_id_selected - 1;
                    for ( int j = 1; j <= ( int ) (*pp).tooling_vec.size( ); j++ ) { // compute the change over time
                        int tf = (*pp).tooling_vec[j - 1];
						
						//Added By Mark G
						int num_hits;
						string current_pkg = "";
						string selected_pkg = "";
						for(int k = 0; k<Lambda.size();k++){
							if(Lambda[k].id == Lambda_id){
								current_pkg = Lambda[k].package;
								num_hits++;
							}
							
							if(Lambda[k].id == Lambda_id_selected){
								selected_pkg = Lambda[k].package;
								num_hits++;
							}
							
							if(num_hits>=2){// goes out of the for loop once both current_pkg and selected_pkg  has value. Else, loop goes until end of Lambda vector.
								break;
							}
						}
						
						if(current_pkg == selected_pkg){ // if no pkg change occured
							resetup_time += Tooling_Setup_Time[tf];//2.5 hrs
						} else {// package change and tooling change
							resetup_time += 8;//8 hrs
						}
						// end
                        
                    }
                }
                cout << "machine_selected=" << machine_selected << ",Lambda_id_selected=" << Lambda_id_selected << ",change over time=" << resetup_time << endl;

                // ------------------------------------------------------need to locate the position in <machine_lambda_benefit>
                int pos = 0;

                for ( int i = 1; i <= ( int ) Machine_vector.size( ); i++ ) {
                    bool found_flag = false;
                    for ( int j = 1; j <= ( int ) Lambda_i[i].int_vector.size( ); j++ ) {
                        if ( i == machine_selected && Lambda_i[i].int_vector[j - 1] == Lambda_id_selected ) { // found the machine-lambda combination
                            found_flag = true;
                            break;
                        } else {
                            pos++;
                        }
                    }
                    if ( found_flag ) {
                        break;
                    }
                }
                cout << "the selected lots are:";
                for ( int j = 1; j <= ( int ) machine_lambda_benefit[pos].second.int_vector.size( ); j++ ) {
                    cout << machine_lambda_benefit[pos].second.int_vector[j - 1] << ",";
                }
                cout << endl;

                // ---------------------------------------------------------Now we know which lots to be assigned
                pair < sub_soln_item, double >one_pair;

                one_pair.second = time_used; // This is the starting time for the new setup (NOT include the resetup time)
                cout << "the starting time is time_used=" << time_used << endl;
                one_pair.first.i = machine_selected;
                one_pair.first.Lambda_id = Lambda_id_selected;
                vii pfind = find( idle_machines.begin( ), idle_machines.end( ), machine_selected );
                if ( pfind == idle_machines.end( ) ) {
                    cout << "Warning message: the selected machine " << machine_selected << " is NOT an idle machine!!!";
                } else {
                    idle_machines.erase( pfind );
                }

                // the lots in machine_lambda_benefit[pos].second.int_vector[] has been sorted according to the benefit in update_benefit()
                one_pair.first.lots.int_vector.resize( ( int ) machine_lambda_benefit[pos].second.int_vector.size( ) );
                copy( machine_lambda_benefit[pos].second.int_vector.begin( ), machine_lambda_benefit[pos].second.int_vector.end( ), one_pair.first.lots.int_vector.begin( ) );

                // ----------------------------------------------------------------time used for the new setup
                double duration = resetup_time; // The change over time should be considered as part of the duration

                for ( int j = 1; j <= ( int ) one_pair.first.lots.int_vector.size( ); j++ ) {
                    int l = one_pair.first.lots.int_vector[j - 1];
                    int s = max_rate_s( one_pair.first.i, l, one_pair.first.Lambda_id );
                    double time_required = n_l_chips[l] / rate[s] + Load_Unload_Time;

                    duration += time_required;
                }
                cout << "duration=" << duration << endl;
                one_pair.first.time_used = duration;
                double new_uptime = one_pair.second + duration; // This is also the completion time

                if ( new_uptime < H[one_pair.first.i] ) { // if there still remainning time when the new lot-assignment is finished
                    next_uptime = make_pair( 1, make_pair( ( int ) enhanced_solution.size( ) + 1, new_uptime ) );
                    uptime.push_back( next_uptime );
                    sort( uptime.begin( ), uptime.end( ), compare_int_int_double );
                    cout << "the resetup machine has been added to the right position " << endl;

                    // this uptime corresponds to the new element to be add to <enhanced_solution>
                    // this uptime is a type 1 machine
                }
                enhanced_solution.push_back( one_pair );

                // ----------------------------------------------------------------need to removed the assigned lots from <lot_remain>
                vector < int >lot_remain_copy;

                for ( int j = 1; j <= ( int ) lot_remain.size( ); j++ ) {
                    int l = lot_remain[j - 1];

                    vii pfind = find( one_pair.first.lots.int_vector.begin( ), one_pair.first.lots.int_vector.end( ), l );
                    if ( pfind == one_pair.first.lots.int_vector.end( ) ) { // the lot is not assigned and should be kept in <lot_remain>
                        lot_remain_copy.push_back( l );
                    }
                }
                lot_remain.clear( );
                lot_remain.resize( ( int ) lot_remain_copy.size( ) );
                copy( lot_remain_copy.begin( ), lot_remain_copy.end( ), lot_remain.begin( ) );

                // ---------------------------------------------------------Also need to update the SIM and tooling info
                vector < Lambda_item >::iterator pL = Lambda.begin( ) + Lambda_id_selected - 1;
                int temperature = (*pL).temperature;

                for ( int j = 1; j <= ( int ) (*pL).tooling_vec.size( ); j++ ) {
                    int tf = (*pL).tooling_vec[j - 1];
                    int b = (*pL).b[j - 1];
                    int pos = (tf - 1) * Num_Temperature + temperature - 1;

                    tooling_used[pos] += b;
                }
                sim_used[machine_sim[machine_selected]]++;

                // ----------------------------------------------------------------need to update the tooling_trace
                double start_time = time_used;
                double end_time = new_uptime;

                for ( int j = 1; j <= ( int ) (*pL).tooling_vec.size( ); j++ ) {
                    int tf = (*pL).tooling_vec[j - 1];
                    int b = (*pL).b[j - 1];
                    int count = 0;

                    for ( int k = 1; k <= ( int ) tooling_trace.size( ); k++ ) {

                        // now pick the b tooling pieces in the family tf. Note that the tooling pieces should be able to work under the temperature
                        int tooling_id = tooling_trace[k - 1].id; // this is the id for the tooling piece

                        if ( tooling_tf[tooling_id] == tf ) {
                            vector < Tooling >::iterator pT = Tooling_vector.begin( ) + tooling_id - 1; // point to the Tooling item
                            vii pfind = find( (*pT).temperature_vector.begin( ), (*pT).temperature_vector.end( ), temperature ); // look for the temperature

                            if ( pfind != (*pT).temperature_vector.end( ) ) {
                                bool flag1 = false, flag2 = false;
                                if ( ( int ) tooling_trace[k - 1].schedule.size( ) < 1 ) {
                                    flag1 = true;
                                }// there is no assignment for the tooling piece
                                else {
                                    int size = ( int ) tooling_trace[k - 1].schedule.size( );
                                    double available_time = tooling_trace[k - 1].schedule[size - 1].second.second; // this is the earliest time the tooling is available

                                    if ( start_time > available_time ) {
                                        flag2 = true;
                                    }
                                }

                                // --now we check if the current tooling piece is assignable
                                if ( flag1 || flag2 ) {
                                    tooling_trace[k - 1].schedule.push_back( make_pair( machine_selected, make_pair( start_time, end_time ) ) );
                                    count++;
                                }
                            }
                        }
                        if ( count >= b ) {
                            break;
                        }
                    }
                }
            }
        }

        // delete the first element in the vector "uptime"
        vector < pair < int, pair < int, double > > >::iterator zhufeng = uptime.begin( );

        uptime.erase( zhufeng );
        cout << "delete the first element" << endl;
    }
    show_enhanced_solution( enhanced_solution );
    cout << "obj = " << compute_obj( enhanced_solution ) << endl;
    fstream fcout( "Output/resultsummery.txt", ios::out | ios::app );
    fcout << "After resetup" << endl;
    fcout << "obj = " << compute_obj( enhanced_solution ) << endl;
    fcout.close( );

    // free the arrays
    delete[]tooling_used;
    delete[]sim_used;
    delete[]SIM_number;
}


/**
 * @brief
 * 
 * @param enhanced_solution
 */
void
AT::show_enhanced_solution( vector < pair < sub_soln_item, double > >&enhanced_solution )
{
    cout << "--------------------------------------------------------------show solution after resetup the idle machines" << endl;
    for ( int id = 1; id <= ( int ) enhanced_solution.size( ); id++ ) {
        struct date_time start = increase_date_time( General_Snapshot_time, enhanced_solution[id - 1].second );
        struct date_time end = increase_date_time( General_Snapshot_time, enhanced_solution[id - 1].second + enhanced_solution[id - 1].first.time_used );

        cout << "Machine " << enhanced_solution[id - 1].first.i
                << " is setup with Lambda " << enhanced_solution[id - 1].first.Lambda_id << ". The starting time is " << start.str << ". The duration is " << enhanced_solution[id - 1].first.time_used << ". The finished time is " << end.str << endl;
    }
}


/**
 * @brief 
 * 
 * @param initial_running_lot
 */
void
AT::show_initial_running_lot( vector < initial_running_lot_item > &initial_running_lot )
{
    cout << "--------------------------------------------------------------show the initial_running_lot" << endl;
    for ( int id = 1; id <= ( int ) initial_running_lot.size( ); id++ ) {
        cout << "Lot " << initial_running_lot[id - 1].lot_name
                << " is initially running on machine "
                << initial_running_lot[id - 1].machine_name << ".The device is "
                << initial_running_lot[id - 1].dev_name
                << ". The starting time is "
                << initial_running_lot[id - 1].Start_time.str
                << ". The current snapshot time is "
                << initial_running_lot[id - 1].Snapshot_time.str
                << ". Thus the lot has been running for "
                << get_date_time_difference( initial_running_lot[id - 1].Snapshot_time, initial_running_lot[id - 1].Start_time ) << " hours."
                << "  The processing rate is " << initial_running_lot[id - 1].rate << " PPH." << "  logpoint = " << initial_running_lot[id - 1].logpoint << "  operation = " << initial_running_lot[id - 1].operation << endl;
    }
}


/**
 * @brief 
 * 
 * @param initial_running_lot
 */
void
AT::extend_initial_lot( vector < initial_running_lot_item > &initial_running_lot )
{
    // This function is called immediately after <initial_running_lot> is ready
    // -------------------------------------------------------------------This is part extend <DEV> <PKG> device_PKG and device_PIN
    for ( int id = 1; id <= ( int ) initial_running_lot.size( ); id++ ) {

        // -----------------------------figure out the device id
        int d = -100;

        for ( int j = 1; j <= ( int ) DEV.size( ); j++ ) {
            if ( !strcmp( DEV[j - 1], initial_running_lot[id - 1].dev_name ) ) {
                d = j;
                break;
            }
        }
        if ( d < 0 ) { // the vector <DEV> does not contain such a device
            cout << "Add device " << initial_running_lot[id - 1].dev_name << " to the set of devices DEV" << endl;
            char *name = new char[50];

            strcpy( name, initial_running_lot[id - 1].dev_name );
            DEV.push_back( name ); // then put the device as a new device into <DEV>
            d = ( int ) DEV.size( );
            Num_Device = ( int ) DEV.size( ); // update the number of devices
        }
        initial_running_lot[id - 1].dev_id = d;

        // -------------------------------figure out the package id
        int pkg = -100;

        for ( int j = 1; j <= ( int ) PKG.size( ); j++ ) {
            if ( !strcmp( PKG[j - 1], initial_running_lot[id - 1].PKG_name ) ) {
                pkg = j;
                break;
            }
        }
        if ( pkg < 0 ) { // the package name is not contained in <PKG>
            cout << " Add package " << initial_running_lot[id - 1].PKG_name << " to the set of packages PKG" << endl;
            char *name = new char[50];

            strcmp( name, initial_running_lot[id - 1].PKG_name );
            PKG.push_back( name );
            pkg = ( int ) PKG.size( );
        }
        initial_running_lot[id - 1].pkg_id = pkg;
        device_PKG[d] = pkg;
        device_PIN[d] = initial_running_lot[id - 1].PIN_num;

        // -------------------------------------------------------------------------------------------------------------------------------------
    }
}


/**
 * @brief 
 * 
 * @param initial_running_lot
 * @param H
 */
void
AT::process_initial_lot( vector < initial_running_lot_item > &initial_running_lot, double *H )
{
    // This fucntion should be called after <initial_running_lot> is ready but should be called before building models

    // This function process the intial lots that are running on some machines at the snapshot time
    // The available machine time H[] is reduced for the machines that running the initial lots
    // However,when computing the total obj,e.g.compute_obj(),the devices contained in the initial lots should be taken into account
    for ( int id = 1; id <= ( int ) initial_running_lot.size( ); id++ ) {
        double time_consumed = get_date_time_difference( initial_running_lot[id - 1].Snapshot_time, initial_running_lot[id - 1].Start_time ); // how much time has been consumed
        int mg = machine_mg[initial_running_lot[id - 1].machine_id]; // get machine group

        // ---------------------------------------------------------------figure out the device id
        int d = -1;

        for ( int j = 1; j <= ( int ) DEV.size( ); j++ ) {
            if ( !strcmp( DEV[j - 1], initial_running_lot[id - 1].dev_name ) ) {
                d = j;
                break;
            }
        }

        // -----------------------------------------------------------------------------------figure out which route is used for the initial lot
        // ---------------------------------------------since the <S> has been clean right after reading the rout.csv file. It is possible that the device has been cleaned.
        // ---------------------------------------------we need to reopen the route.csv file to read the info
        vector < double >PPH;
        char temp[2000], pdes[1000];

        ifstream f_route( "Debug/route.csv" );
        f_route.getline( temp, 1000, '\n' );
        f_route.getline( temp, 1000, '\n' );
        int count = 0;

        while ( !f_route.eof( ) ) {
            int l = 0, k = 0;

            for ( int j = 1; j <= 6; j++ ) { // get the device name
                k = strtok2( pdes, temp, l, ',' );
                l = k;
            }
            trim( pdes );
            if ( !strcmp( initial_running_lot[id - 1].dev_name, pdes ) ) { // if this match processes the device contained in the initial lot
                for ( int j = 1; j <= 6; j++ ) { // get the machine group
                    k = strtok2( pdes, temp, l, ',' );
                    l = k;
                }
                trim( pdes );
                if ( !strcmp( pdes, MF[mg - 1] ) ) { // if we got a match for the machine group too
                    l = 0;
                    k = 0;
                    for ( int j = 1; j <= 2; j++ ) { // get the PPH
                        k = strtok2( pdes, temp, l, ',' );
                        l = k;
                    }
                    trim( pdes );
                    int logpoint = atoi( pdes );

                    if ( logpoint == initial_running_lot[id - 1].logpoint ) {
                        l = 0;
                        k = 0;
                        for ( int j = 1; j <= 3; j++ ) { // get the OPN
                            k = strtok2( pdes, temp, l, ',' );
                            l = k;
                        }
                        trim( pdes );
                        int operation = atoi( pdes );

                        if ( operation == initial_running_lot[id - 1].operation ) {
                            l = 0;
                            for ( int j = 1; j <= 11; j++ ) { // get the PPH
                                k = strtok2( pdes, temp, l, ',' );
                                l = k;
                            }
                            trim( pdes );
                            PPH.push_back( ( double ) atof( pdes ) );
                        }
                    }
                }
            }
            f_route.getline( temp, 1000, '\n' );
        }
        f_route.close( );
        f_route.clear( );

        // --------------------------------------------------------------------------------------------------------
        if ( ( int ) PPH.size( ) == 0 ) {
            cout << "Warnning Message:" << endl;
            cout << "There is no route associated to device " << initial_running_lot[id - 1].dev_name << " and machine group " << MF[mg - 1] << endl;
            cout << "The initial lot will stay in the machine and never be processed!" << endl;

            // abort(); // instead of aborting the process,set H[] to 0 such that the machine is not used at all
            cout << "Set the machine available time H to zero such that this machine is not used at all." << endl;
            H[initial_running_lot[id - 1].machine_id] = 0;
            effective_starting_time[initial_running_lot[id - 1].machine_id] = 1E+06;
            initial_running_lot[id - 1].rate = 1E-07; // When output to long_lot.csv, the condition is if (rate > 1E-06). To avoid changing the output,set rate=1E-07 here.
            initial_running_lot[id - 1].time_remain = 0;
        } else {
            sort( PPH.begin( ), PPH.end( ) ); // This is in ascending order
            double max_rate = PPH[( int ) PPH.size( ) - 1];

            initial_running_lot[id - 1].rate = max_rate; // get the maximum processing rate
            double time_required = initial_running_lot[id - 1].n_l_chips / max_rate + Load_Unload_Time; // compute the total time that required to process the initial lot
            double time_remain = time_required - time_consumed; // compute how much more time need to be used

            initial_running_lot[id - 1].time_remain = time_remain;
            if ( time_remain > 0 ) {
                H[initial_running_lot[id - 1].machine_id] -= time_remain; // reduce the available machine time for the machine
                effective_starting_time[initial_running_lot[id - 1].machine_id] = time_remain;
                if ( H[initial_running_lot[id - 1].machine_id] < 0 ) {
                    cout << "Message: the lot " << initial_running_lot[id - 1].lot_name << " will take another " << time_remain << " hours to finish, which is longer than the time horizon." << endl;
                }
            } else { // else_if time_remain<0, the initial lot is actually finished already. Output this message
                cout << "Warnning Message: the lot " << initial_running_lot[id - 1].lot_name << " has been actually finished on machine " << initial_running_lot[id - 1].machine_id << " and should not be counted as initila lot." << endl;
                effective_starting_time[initial_running_lot[id - 1].machine_id] = 0.0;
            }
        }

        // --------------------------------------------------------------------------------------
    }
    ofstream fdebug( "Debug/debug_updated_H.txt" );
    fdebug << "The updated time horizon for the machines is (subtract the time to process the initial lots)" << endl;
    for ( int i = 1; i <= ( int ) Machine_vector.size( ); i++ ) {
        fdebug << "i=" << i << ",H=" << H[i] << endl;
    }
    fdebug.close( );
    fdebug.clear( );
}


/**
 * @brief This function creats the report files for the whole results after enhancement.
 * 
 * @param initial_running_lot
 * @param enhanced_solution
 */
void
AT::generate_reports( vector < initial_running_lot_item > &initial_running_lot, vector < pair < sub_soln_item, double > >&enhanced_solution )
{
    // This function creats the report files for the whole results after enhancement
    ofstream f_soln( "Output/solution.csv" );

    // add completion time of each lot.
    f_soln << "Machine_Instance,Machine_Family_Name,Lot_Name,Quantity,Lot_Weight,Initial_Lot_Flag,Device_Name,Tooling_Family_Name,Certification,Setup_Time,Completion_Time,Package" << endl;
	
	//Added By Mark G: store 
	double input_pkg_setup_time = 8;
	char *last_initial_package = new char[50];
	last_initial_package ="";
	//end
	
    // first output the initial lots
    for ( int j = 1; j <= ( int ) initial_running_lot.size( ); j++ ) {
        if ( initial_running_lot[j - 1].time_remain > 0 ) { // Only the valid initial lot is output
            // It is okay that the lot will go across the whole horizon. It will still be output but not be counted in the total throughput
            int i = initial_running_lot[j - 1].machine_id;
            int mg = machine_mg[i];
			
			//Added By Mark G
			double pkg_setup_time = 0.0;
			if(j > 1 || j <= initial_running_lot.size()){
				if(initial_running_lot[j-1].PKG_name != initial_running_lot[j-2].PKG_name){
					pkg_setup_time = 8.0;
				}
			}
			//end
			
            struct date_time dt = increase_date_time( General_Snapshot_time, initial_running_lot[j - 1].time_remain + pkg_setup_time);

            output_date_time( dt );

            // Note that there is neither tooling info nor certification info for the initial lots,so leave it blank
            f_soln << initial_running_lot[j - 1].machine_name << ","
                    << MF[mg - 1] << "," << initial_running_lot[j - 1].lot_name
                    << "," << initial_running_lot[j - 1].n_l_chips << "," << initial_running_lot[j - 1].w_l << ",Y," << initial_running_lot[j - 1].dev_name << ",,," << General_Snapshot_time.str << "," << dt.str << "," << initial_running_lot[j - 1].PKG_name << endl;
        }
		
		//Added By Mark G
		last_initial_package = initial_running_lot[j-1].PKG_name;
		//end
    }
	
    // secondary,output the <enhanced_solution>
    for ( int j = 1; j <= ( int ) enhanced_solution.size( ); j++ ) {
        int i = enhanced_solution[j - 1].first.i;
        int mg = machine_mg[i];
        int Lambda_id = enhanced_solution[j - 1].first.Lambda_id;
        double current_time = enhanced_solution[j - 1].second;


        // To test whether there is resetup time.If the end_time of the machine is later than sum of time for all lots in the machine,
        // there must be resetup time. The resetup_time is just the difference of end_time and completion_time of all lots.
        double end_time = current_time + enhanced_solution[j - 1].first.time_used;
        double current_time2 = current_time; // current_time2 is to store the completion time of all lots not including resetup time

        for ( int id = 1; id <= ( int ) enhanced_solution[j - 1].first.lots.int_vector.size( ); id++ ) {
            int l = enhanced_solution[j - 1].first.lots.int_vector[id - 1];
            int d = lots_device[l];
            int s = max_rate_s( i, l, Lambda_id );
            double time_required = n_l_chips[l] / rate[s] + Load_Unload_Time;

            current_time2 += time_required;
        }
        double resetup_time = 0;

        if ( current_time2 < end_time ) {
            resetup_time = end_time - current_time2;
        }
		
		//Added By Mark G
		double package_setup_time=0;
		
		if(last_initial_package != ""){//checks if there are no initial package
			if(last_initial_package != PKG[device_PKG[lots_device[enhanced_solution[j-1].first.lots.int_vector[0]]]]){//checks if the last initial package is equal to the package of the first non-initial lot
				package_setup_time = input_pkg_setup_time; //adds pkg setup time. hard coded for now but will be revised when input.txt is fixed
			}
		}
		//End
		
        if ( current_time + package_setup_time < H[i] ) { // if the starting time is within the planning horizon
            double time_start = enhanced_solution[j - 1].second;

            for ( int id = 1; id <= ( int ) enhanced_solution[j - 1].first.lots.int_vector.size( ); id++ ) {
                int l = enhanced_solution[j - 1].first.lots.int_vector[id - 1];
                int d = lots_device[l];
                int s = max_rate_s( i, l, Lambda_id );
                double time_required = n_l_chips[l] / rate[s] + Load_Unload_Time;

                current_time += time_required;
                if ( id == 1 ) {
                    current_time += resetup_time;
                }
				//Added By Mark G
				if(id > 1){
					if(PKG[d] != PKG[lots_device[enhanced_solution[j-1].first.lots.int_vector[id-2]]]){
						package_setup_time = input_pkg_setup_time; //adds pkg setup time. hard coded for now but will be revised when input.txt is fixed
					}
				}
				//end
                if ( current_time + package_setup_time <= H[i] ) {
                    f_soln << MI[i - 1] << "," << MF[mg - 1] << "," << LOT[l - 1] << "," << n_l_chips[l] << "," << w_l[l] << ",N," << DEV[d - 1] << ",";
                    vector < Lambda_item >::iterator pL = Lambda.begin( ) + Lambda_id - 1;
                    int tf = (*pL).tooling_vec[0];

                    if ( tf > 0 ) {

                        // dt is the start time of the lot
                        struct date_time dt = increase_date_time( General_Snapshot_time, enhanced_solution[j - 1].second );

                        output_date_time( dt );

                        // dt2 is the completion time of the lot
                        struct date_time dt2 = increase_date_time( General_Snapshot_time, current_time + package_setup_time);

                        output_date_time( dt2 );
                        f_soln << TF[tf - 1] << "," << (*pL).temperature << "," << dt.str << "," << dt2.str << "," << (*pL).package << endl;
                    } else {
                        struct date_time dt = increase_date_time( General_Snapshot_time, enhanced_solution[j - 1].second );

                        output_date_time( dt );
                        struct date_time dt2 = increase_date_time( General_Snapshot_time, current_time + package_setup_time);

                        output_date_time( dt2 );
                        f_soln << ",," << (*pL).temperature << "," << dt.str << "," << dt2.str << "," << (*pL).package << endl;
                    }
                    if ( (*pL).tooling_vec.size( ) >= 2 ) {
                        for ( int k = 2; k <= ( int ) (*pL).tooling_vec.size( ); k++ ) { // for each tooling family
                            int tf = (*pL).tooling_vec[k - 1];
                            struct date_time dt = increase_date_time( General_Snapshot_time, enhanced_solution[j - 1].second );

                            output_date_time( dt );
                            struct date_time dt2 = increase_date_time( General_Snapshot_time, current_time + package_setup_time);

                            output_date_time( dt2 );
                            f_soln << ",,,,,,," << TF[tf - 1] << "," << (*pL).temperature << "," << dt.str << "," << dt2.str << "," << (*pL).package << endl;
                        }
                    }
                } else {
                    f_soln << "l=" << l << ",time_required=" << time_required << ",current_time=" << current_time << ",machine=" << i << ",H=" << H[i] << endl;
                }
            }
        }
    }
    f_soln.close( );

    // --------------------------------------------------------------output the reports for key devices
    // ---------------------------------------------------------------------get the production for the devices
    vector < int >production( Num_Device, 0 );

    for ( int j = 1; j <= ( int ) enhanced_solution.size( ); j++ ) { // compute the total lot weights
        double current_time = enhanced_solution[j - 1].second;
        int i = enhanced_solution[j - 1].first.i;
        int Lambda_id = enhanced_solution[j - 1].first.Lambda_id;

        if ( current_time < H[i] ) {
            for ( int id = 1; id <= ( int ) enhanced_solution[j - 1].first.lots.int_vector.size( ); id++ ) {
                int l = enhanced_solution[j - 1].first.lots.int_vector[id - 1]; // lot
                int s = max_rate_s( i, l, Lambda_id );
                double time_required = n_l_chips[l] / rate[s] + Load_Unload_Time;

                current_time += time_required;
                if ( current_time <= H[i] ) { // only count the lots that are finished within the horizon (ACTION 2)
                    int d = lots_device[l];

                    production[d - 1] += n_l_chips[l]; // update the device production
                } else {
                    break; // the next lots also exceed the horizon
                }
            }
        }
    }

    // ---------------------------------------Still need to add the initial lot to the production
    for ( int id = 1; id <= ( int ) initial_running_lot.size( ); id++ ) {
        if ( initial_running_lot[id - 1].time_remain > 0 && H[initial_running_lot[id - 1].machine_id] > 0 ) {

            // NOTE That H[] has been updated in process_initial_lot()
            // This means that the initial lot can be finished within the horizon (it is possible that some LONG lot can not be done withn a horizon)
            // This also excludes the lots that are setup as initial lot but has already finished before Snapshot_time (pretended to be an initial lot)
            int d = initial_running_lot[id - 1].dev_id;

            production[d - 1] += initial_running_lot[id - 1].n_l_chips;
        }
    }
    // ------------------------------------------------------------------------------
    ofstream f_keydevice( "Output/keydevice_production.csv" );
    f_keydevice << "Device,Target amount,Finished amount,Shortage" << endl;
    for ( int j = 1; j <= ( int ) Key_Devices.size( ); j++ ) {
        int d = Key_Devices[j - 1];

        f_keydevice << DEV[d - 1] << "," << n_k_minchips[d] << "," << production[d - 1] << "," << n_k_minchips[d] - production[d - 1] << endl;
    }
    f_keydevice.close( );

    // ----------------------------------------------------compute the production of PKG and PIN_PKG
    vector < int >PKG_production( ( int ) PKG.size( ), 0 );
    vector < int >PIN_PKG_production( ( int ) PKG.size( ) * ( int ) PIN_order.size( ) + 1, 0 );

    for ( int j = 1; j <= ( int ) enhanced_solution.size( ); j++ ) { // --------------get the production of KP and KPP
        double current_time = enhanced_solution[j - 1].second; // the starting time
        int i = enhanced_solution[j - 1].first.i;
        int Lambda_id = enhanced_solution[j - 1].first.Lambda_id;

        vii p_lot = enhanced_solution[j - 1].first.lots.int_vector.begin( );
        if ( current_time < H[i] ) {
            while ( p_lot != enhanced_solution[j - 1].first.lots.int_vector.end( ) ) {
                int l = (*p_lot);
                int s = max_rate_s( i, l, Lambda_id );
                double time_required = n_l_chips[l] / rate[s] + Load_Unload_Time;

                current_time += time_required;
                if ( current_time <= H[i] ) {
                    int d = lots_device[l];
                    int pkg_id = device_PKG[d];
                    int pin_num = device_PIN[d];

                    vii pfind = find( PIN_order.begin( ), PIN_order.end( ), pin_num );
                    int pin_order = pfind - PIN_order.begin( ) + 1;

                    PKG_production[pkg_id - 1] += n_l_chips[l];
                    int index = (pkg_id - 1) * ( int ) PIN_order.size( ) + pin_order - 1;

                    PIN_PKG_production[index] += n_l_chips[l];
                } else {
                    break;
                }
                p_lot++;
            }
        }
    }

    // -----------------------------------------------------------------------------
    // --------------------------------------------------------------------------------
    ofstream f_kp( "Output/key_package_production.csv" );
    f_kp << "Key_Package_Name,Target_amount,Finished_amount,Shortage" << endl;
    for ( int kp = 1; kp <= ( int ) Key_PKG.size( ); kp++ ) {
        int pkg_id = Key_PKG[kp - 1];
        int diff = n_kp_minchips[pkg_id] - PKG_production[pkg_id - 1];

        f_kp << PKG[pkg_id - 1] << "," << n_kp_minchips[pkg_id] << "," << PKG_production[pkg_id - 1] << "," << diff << endl;
    }
    f_kp.close( );

    // --------------------------------------------------------------------------
    ofstream f_kpp( "Output/key_pin_package_production.csv" );
    f_kpp << "Package_Name,Pin,Target_amount,Finished_amount,Shortage" << endl;
    for ( int kpp = 1; kpp <= ( int ) Key_PIN_PKG.size( ); kpp++ ) {
        int pkg_id = Key_PIN_PKG[kpp - 1].first.second;
        int pin_num = Key_PIN_PKG[kpp - 1].first.first;
        int target = Key_PIN_PKG[kpp - 1].second;

        vii pfind = find( PIN_order.begin( ), PIN_order.end( ), pin_num );
        int pin_order = pfind - PIN_order.begin( ) + 1;
        int index = (pkg_id - 1) * ( int ) PIN_order.size( ) + pin_order - 1;
        int diff = target - PIN_PKG_production[index];

        f_kpp << PKG[pkg_id - 1] << "," << pin_num << "," << target << "," << PIN_PKG_production[index] << "," << diff << endl;
    }
    f_kpp.close( );

    // --------------------------------------------------------------------
    vector < pair < int, double > > mach_time; // this vector is used to store the makespan for each machine within a horizon

    for ( int j = 1; j <= ( int ) enhanced_solution.size( ); j++ ) {
        int i = enhanced_solution[j - 1].first.i;
        int Lambda_id = enhanced_solution[j - 1].first.Lambda_id;
        double time = enhanced_solution[j - 1].second + enhanced_solution[j - 1].first.time_used; // time is the total completion time
        bool exist_flag = false;


        // It is likely that there are duplicate machines in the <enhanced_solution> b/c of the resetup
        // Thus need to check if the machine is already there in <mach_time>
        for ( int id = 1; id <= ( int ) mach_time.size( ); id++ ) {
            if ( mach_time[id - 1].first == i ) {
                exist_flag = true;
                if ( time > mach_time[id - 1].second && time <= H[i] ) { // the machine must be resetup and the completion time is within horizon
                    mach_time[id - 1].second = time;
                } else if ( enhanced_solution[j - 1].second < H[i] && time > H[i] ) { // some lots run across the horizon
                    // the completion time will go across the time horizon if all the lots are processed
                    // thus only pick up the lots that can be processed within the time horizon
                    double completion_time = enhanced_solution[j - 1].second; // the starting time

                    for ( int k = 1; k <= ( int ) enhanced_solution[j - 1].first.lots.int_vector.size( ); k++ ) {
                        int l = enhanced_solution[j - 1].first.lots.int_vector[k - 1];
                        int d = lots_device[l];
                        int s = max_rate_s( i, l, Lambda_id );
                        double time_required = n_l_chips[l] / rate[s];

                        if ( completion_time + time_required <= H[i] ) {
                            completion_time += time_required;
                        } else {
                            break;
                        }
                    }

                    // now we get the completion time
                    mach_time[id - 1].second = completion_time;
                }
                break;
            }
        }
        if ( !exist_flag && time <= H[i] ) {
            mach_time.push_back( make_pair( i, time ) );
        }
    }

    // there still something missing here. We only consider the <enhanced_solution> so far.
    // there are some machine that is type 2. That is, not used in <enhanced_solution> but used to process initial lots.
    // these machine should also be counted here.
    for ( int j = 1; j <= ( int ) initial_running_lot.size( ); j++ ) {
        int i = initial_running_lot[j - 1].machine_id;

        bool found_flag = false;
        for ( int id = 1; id <= ( int ) mach_time.size( ); id++ ) {
            if ( mach_time[id - 1].first == i ) { // if we found a match of machine,then the machine is already used in <enhanced_solution>
                // however, still want to check it
                if ( effective_starting_time[i] <= H[i] && effective_starting_time[i] > mach_time[id - 1].second ) {

                    // the machine is used before finishing the process of initial lot
                    // if effective_starting_time>H (for example 1E+06),then the machine is not used in <enhanced_solution>
                    cout << "Eerror message: the machine " << i << " is used before finishing the process of initial lot" << ". effective_starting_time=" << effective_starting_time[i] << ", mach_time=" << mach_time[id - 1].second << endl;
                }
                found_flag = true;
                break;
            }
        }
        if ( !found_flag ) {

            // the machine is not used in <enhanced_solution> but used to process the initial lot
            mach_time.push_back( make_pair( i, effective_starting_time[i] ) );

            // it is possible effective_starting_time=1E+06 b/c the initial lot cannot be processed by the machine
        }
    }

    // it is still possible some machine is never used
    for ( int j = 1; j <= Num_Machine; j++ ) {
        bool found_flag = false;
        for ( int id = 1; id <= ( int ) mach_time.size( ); id++ ) {
            if ( mach_time[id - 1].first == j ) {
                found_flag = true;
                break;
            }
        }
        if ( !found_flag ) {
            mach_time.push_back( make_pair( j, 0 ) );
        }
    }

    // at this point, all the machines should appear in <mach_time>
    for ( int j = 1; j <= ( int ) mach_time.size( ); j++ ) {
        cout << "j=" << j << ",mach=" << mach_time[j - 1].first << ",time=" << mach_time[j - 1].second << endl;
    }
    ofstream f_time( "Output/time.csv" );
    f_time << "Machine,Time" << endl;
    for ( int i = 1; i <= Num_Machine; i++ ) {
        int pos = -1;

        for ( int j = 1; j <= ( int ) mach_time.size( ); j++ ) {
            if ( mach_time[j - 1].first == i ) {
                pos = j;
                break;
            }
        }
        if ( pos > 0 ) {
            if ( mach_time[pos - 1].second < 10000 ) {

                // it is possible some initial lot cannot be tested by the given machine and results in 1E+06 running time
                f_time << MI[i - 1] << "," << mach_time[pos - 1].second << endl;
            } else {
                f_time << MI[i - 1] << "," << "N/A" << endl;
            }
        } else {
            cout << "Warnning message: some machine is not include in the file time.csv" << endl;
        }
    }
    f_time.close( );

    // ------------------------------------------------------------------------
    ofstream f_longlot( "Output/long_lot.csv" );
    f_longlot << "Lot Name,Device,Key Device,Key Package,Key Pin Package,Num of Device,Estimated Time Required" << endl;
    for ( int l = 1; l <= Num_Lot; l++ ) { // Num_Lot is the number of regular lots (not initial lot)
        int d = lots_device[l];


        // ------------------------------------------------get the highest processing rate for the lot
        double max_rate = -1000;

        vii pM = M_l[l].int_vector.begin( );
        int count = 0;

        while ( pM != M_l[l].int_vector.end( ) ) {
            int i = (*pM);
            int sim = machine_sim[i];
            int index = index_S_sim_l( sim, l );

            vii p_s = S_sim_l[index].second.int_vector.begin( );
            while ( p_s != S_sim_l[index].second.int_vector.end( ) ) {
                int s = (*p_s);

                if ( rate[s] > max_rate ) {
                    max_rate = rate[s];
                }
                p_s++;
            }
            pM++;
            count++;
        }

        // ------------------------------------------------
        if ( count < 1 ) {

            // This means count=0. There are two possible reasons.
            // (1) there is no available machine associated to the device in the lot.
            // (2) there is no available tooling associated to the device in the lot.
            int type = is_KD_PD( d );

            bool is_kp = is_Key_PKG( d );
            bool is_kpp = is_Key_PIN_PKG( d );
            f_longlot << LOT[l - 1] << "," << DEV[d - 1] << ",";
            if ( type ) {
                f_longlot << "Y,";
            } else {
                f_longlot << "N,";
            }
            if ( is_kp ) {
                f_longlot << "Y,";
            } else {
                f_longlot << "N,";
            }
            if ( is_kpp ) {
                f_longlot << "Y,";
            } else {
                f_longlot << "N,";
            }
            f_longlot << n_l_chips[l] << "," << "cannot be processed due to two possible reasons" << "(1) lack of machine or tooling" << "(2) the device is not contained in route.csv" << endl;
        }
        if ( max_rate > 1E-06 ) {
            double time_required = n_l_chips[l] / max_rate;

            if ( time_required > H[M_l[l].int_vector[0]] ) { // Assumption: all the machines have the same time horizon
                // this is a long lot
                int type = is_KD_PD( d );

                bool is_kp = is_Key_PKG( d );
                bool is_kpp = is_Key_PIN_PKG( d );
                f_longlot << LOT[l - 1] << "," << DEV[d - 1] << ",";
                if ( type ) {
                    f_longlot << "Y,";
                } else {
                    f_longlot << "N,";
                }
                if ( is_kp ) {
                    f_longlot << "Y,";
                } else {
                    f_longlot << "N,";
                }
                if ( is_kpp ) {
                    f_longlot << "Y,";
                } else {
                    f_longlot << "N,";
                }
                f_longlot << n_l_chips[l] << "," << time_required << endl;
            }
        }
    }
    for ( int id = 1; id <= ( int ) initial_running_lot.size( ); id++ ) {
        int d = initial_running_lot[id - 1].dev_id;
        int type = is_KD_PD( d );

        bool is_kp = is_Key_PKG( d );
        bool is_kpp = is_Key_PIN_PKG( d );
        if ( initial_running_lot[id - 1].rate > 1E-06 ) {
            double time_required = initial_running_lot[id - 1].n_l_chips / initial_running_lot[id - 1].rate;

            if ( time_required > H[initial_running_lot[id - 1].machine_id] ) {
                f_longlot << initial_running_lot[id - 1].lot_name << "," << initial_running_lot[id - 1].dev_name << ",";
                if ( type ) {
                    f_longlot << "Y,";
                } else {
                    f_longlot << "N,";
                }
                if ( is_kp ) {
                    f_longlot << "Y,";
                } else {
                    f_longlot << "N,";
                }
                if ( is_kpp ) {
                    f_longlot << "Y,";
                } else {
                    f_longlot << "N,";
                }
                f_longlot << initial_running_lot[id - 1].n_l_chips << "," << time_required << endl;
            }
        } else {
            f_longlot << initial_running_lot[id - 1].lot_name << "," << initial_running_lot[id - 1].dev_name << ",";
            if ( type ) {
                f_longlot << "Y,";
            } else {
                f_longlot << "N,";
            }
            if ( is_kp ) {
                f_longlot << "Y,";
            } else {
                f_longlot << "N,";
            }
            if ( is_kpp ) {
                f_longlot << "Y,";
            } else {
                f_longlot << "N,";
            }
            f_longlot << initial_running_lot[id - 1].n_l_chips << "," << "cannot be processed due to two possible reasons" << "(1) lack of machine or tooling" << "(2) the device is not contained in route.csv" << endl;
        }
    }
    f_longlot.close( );
}


/**
 * @brief 
 * 
 * @param ch
 * @param dt
 */
void
AT::str_to_date_time( char *ch, struct date_time &dt )
{
    strcpy( dt.str, ch ); // copy the string
    char pdes[50];
    int k = 0, l = 0;

    trim( dt.str );
    k = strtok2( pdes, dt.str, l, '/' ); // get MM
    trim( pdes );
    dt.MM = atoi( pdes );
    l = k;
    k = strtok2( pdes, dt.str, l, '/' ); // get DD
    trim( pdes );
    dt.DD = atoi( pdes );
    l = k;
    k = strtok2( pdes, dt.str, l, ' ', '/' ); // get YY
    trim( pdes );
    dt.YY = atoi( pdes );
    l = k;
    k = strtok2( pdes, dt.str, l, ':' ); // get hh
    trim( pdes );
    dt.hh = atoi( pdes );
    l = k;
    k = strtok2( pdes, dt.str, l, ':' ); // get mm
    trim( pdes );
    dt.mm = atoi( pdes );
    l = k;
    k = strtok2( pdes, dt.str, l, ' ' ); // get ss
    trim( pdes );
    dt.ss = atoi( pdes );
}


/**
 * @brief return a-b in hours
 * 
 * @param a
 * @param b
 * 
 * @return a-b in hours
 */
double
AT::get_date_time_difference( const struct date_time &a, const struct date_time &b )
{
    // return a-b in hours
    int dMM = a.MM - b.MM;
    int dDD = a.DD - b.DD;
    int dYY = a.YY - b.YY;
    int dhh = a.hh - b.hh;
    int dmm = a.mm - b.mm;
    int dss = a.ss - b.ss;
    double diff = dYY * 365 * 24 + dDD * 24 + dMM * 30 * 24 + dhh + dmm / 60.0 + dss / 3600.0;

    return diff;
}


/**
 * @brief update the dt by increasing "increment_hr" hours
 * 
 * @param org_dt
 * @param increment_hr
 * 
 * @return 
 */
struct date_time
AT::increase_date_time( const struct date_time &org_dt, double increment_hr )
{
    // update the dt by increasing "increment_hr" hours
    struct date_time dt = org_dt;
    int ss = increment_hr * 3600; // transform to seconds

    ss += dt.ss;
    int mm = ( int ) ss / 60.0;

    dt.ss = ss - mm * 60;
    mm += dt.mm;
    int hh = ( int ) mm / 60.0;

    dt.mm = mm - hh * 60;
    hh += dt.hh;
    int DD = ( int ) hh / 24.0;

    dt.hh = hh - DD * 24;
    DD += dt.DD;
    int num_date[12] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
    int MM = dt.MM;

    if ( DD > num_date[MM] ) {
        DD = DD - num_date[MM];
        MM++;
    }
    dt.DD = DD;
    int YY = ( int ) MM / 12.0;

    dt.MM = MM - YY * 12;
    YY += dt.YY;
    dt.YY = YY;
    stringstream ssss;
    ssss << dt.MM << "/" << dt.DD << "/" << dt.YY << " " << dt.hh << ":" << dt.mm << ":" << dt.ss;
    strcpy( dt.str, (ssss.str( )).c_str( ) );
    return dt;
}


/**
 * @brief 
 * 
 * @param dt
 */
void
AT::output_date_time( struct date_time &dt )
{
    stringstream ss;
    if ( dt.MM <= 9 ) {
        ss << "0";
    }
    ss << dt.MM << "/";
    if ( dt.DD <= 9 ) {
        ss << "0";
    }
    ss << dt.DD << "/";
    if ( dt.YY <= 9 ) {
        ss << "0";
    }
    ss << dt.YY << " ";
    if ( dt.hh <= 9 ) {
        ss << "0";
    }
    ss << dt.hh << ":";
    if ( dt.mm <= 9 ) {
        ss << "0";
    }
    ss << dt.mm << ":";
    if ( dt.ss <= 9 ) {
        ss << "0";
    }
    ss << dt.ss;
    strcpy( dt.str, (ss.str( )).c_str( ) );
}


/**
 * @brief initialize the vector \<tooling_trace> according to the GRASP best solution
 * 
 * @param best_soln
 * @param tooling_trace
 */
void
AT::initialize_tooling_trace( struct soln_pool_item &best_soln, vector < tooling_trace_item > &tooling_trace )
{
    // this function initialize the vector <tooling_trace> according to the GRASP best solution
    // initially, the vector <tooling_trace> is empty
    tooling_trace.resize( ( int ) Tooling_vector.size( ) );
    for ( int j = 1; j <= ( int ) tooling_trace.size( ); j++ ) {
        tooling_trace[j - 1].id = j;
    }
    // Now we are going to investigate the tooling usage in the GRASP solution
    for ( int j = 1; j <= ( int ) best_soln.sub_soln.size( ); j++ ) {
        int i = best_soln.sub_soln[j - 1].i;
        int Lambda_id = best_soln.sub_soln[j - 1].Lambda_id;
        double time_used = best_soln.sub_soln[j - 1].time_used;
        double start_time = effective_starting_time[i];
        double end_time = start_time + time_used;

        if ( Lambda_id >= 1 && time_used > 0 ) {

            // only consider the machines that are actually running
            vector < Lambda_item >::iterator pL = Lambda.begin( ) + Lambda_id - 1;
            int temperature = (*pL).temperature;

            for ( int id = 1; id <= ( int ) (*pL).tooling_vec.size( ); id++ ) {
                int tf = (*pL).tooling_vec[id - 1];
                int b = (*pL).b[id - 1];
                int count = 0;

                for ( int k = 1; k <= ( int ) tooling_trace.size( ); k++ ) {

                    // now pick the b tooling pieces in the family tf. Note that the tooling pieces should be able to work under the temperature
                    int tooling_id = tooling_trace[k - 1].id; // this is the id for the tooling piece

                    if ( tooling_tf[tooling_id] == tf ) {
                        vector < Tooling >::iterator pT = Tooling_vector.begin( ) + tooling_id - 1; // point to the Tooling item
                        vii pfind = find( (*pT).temperature_vector.begin( ), (*pT).temperature_vector.end( ), temperature ); // look for the temperature

                        if ( pfind != (*pT).temperature_vector.end( ) ) {
                            bool flag1 = false, flag2 = false;
                            if ( ( int ) tooling_trace[k - 1].schedule.size( ) < 1 ) {
                                flag1 = true;
                            }// there is no assignment for the tooling piece
                            else {
                                int size = ( int ) tooling_trace[k - 1].schedule.size( );
                                double available_time = tooling_trace[k - 1].schedule[size - 1].second.second; // this is the earliest time the tooling is available

                                if ( start_time > available_time ) {
                                    flag2 = true;
                                }
                            }

                            // --now we check if the current tooling piece is assignable
                            if ( flag1 || flag2 ) {
                                tooling_trace[k - 1].schedule.push_back( make_pair( i, make_pair( start_time, end_time ) ) );
                                count++;
                            }
                        }
                    }
                    if ( count >= b ) {
                        break;
                    }
                }
            }
        }
    }
}


/**
 * @brief 
 * 
 * @param tooling_trace
 */
void
AT::show_tooling_trace( vector < tooling_trace_item > &tooling_trace )
{
    ofstream fdebug( "Debug/debug_tooling_trace.txt" );
    for ( int k = 1; k <= ( int ) tooling_trace.size( ); k++ ) {
        vector < Tooling >::iterator pT = Tooling_vector.begin( ) + tooling_trace[k - 1].id - 1;
        fdebug << "id=" << tooling_trace[k - 1].id << ",name=" << (*pT).name << ",tf=" << (*pT).tf << ",family=" << TF[(*pT).tf - 1] << ",schedule=";
        for ( int id = 1; id <= ( int ) tooling_trace[k - 1].schedule.size( ); id++ ) {
            double start_time = tooling_trace[k - 1].schedule[id - 1].second.first;
            double end_time = tooling_trace[k - 1].schedule[id - 1].second.second;
            double machine_id = tooling_trace[k - 1].schedule[id - 1].first;

            fdebug << "(" << start_time << "," << end_time << ")";
            fdebug << "to machine " << machine_id << ",name=" << MI[machine_id - 1];
        }
        fdebug << endl;
    }
    fdebug.close( );
    fdebug.clear( );
}

// __END__
