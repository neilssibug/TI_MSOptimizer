// __START__

#include "BCP_parameters.hpp"
#include "AT_lp_param.hpp"
using std::make_pair;

/*-----------------------------------------------------------------*/
template<>
void BCP_parameter_set<AT_lp_par>::create_keyword_list( ) {
    // Int Parameter
    keys.push_back( make_pair( BCP_string( "AT_StrongBranch_Can" ), BCP_parameter( BCP_IntPar, AT_StrongBranch_Can ) ) );
}

/*-----------------------------------------------------------------*/
template<>
void BCP_parameter_set<AT_lp_par>::set_default_entries( ) {
    set_entry( AT_StrongBranch_Can, 5 );
}

// __END__
