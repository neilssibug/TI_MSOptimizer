// __START__

#ifndef __AT_LP_PARAM_HPP__
#define __AT_LP_PARAM_HPP__

/*
 AAP_StrongBranch_Can : number of candidates to select for strong branching
 */

/*-----------------------------------------------------------------*/
struct AT_lp_par {

    enum chr_params {
        char_dummy, end_of_chr_params
    };

    enum int_params {
        AT_StrongBranch_Can, end_of_int_params
    };

    enum dbl_params {
        dbl_dummy, end_of_dbl_params
    };

    enum str_params {
        str_dummy, end_of_str_params
    };

    enum str_array_params {
        str_array_dummy, end_of_str_array_params
    };
};

#endif

// __END__
