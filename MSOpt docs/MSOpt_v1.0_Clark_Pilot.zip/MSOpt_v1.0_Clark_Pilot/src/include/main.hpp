//  __START__

#ifndef __MAIN_HPP__
#define __MAIN_HPP__

#include "AT_init.hpp"
#include "BCP_USER.hpp"

USER_initialize * BCP_user_init();
int main(int argc, char* argv[]);

#endif

// __END__