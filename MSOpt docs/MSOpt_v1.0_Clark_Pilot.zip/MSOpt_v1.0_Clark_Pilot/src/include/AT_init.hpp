// __START__

#ifndef __AT_INIT_HPP__
#define __AT_INIT_HPP__

#include "BCP_USER.hpp"

/**
 * Class for the user-defined USER interface to BCP which
 * initializes each process. In this case, just TM and LP.
 */
class AT_init : public USER_initialize {
public:
    BCP_tm_user * tm_init(BCP_tm_prob& p, const int argnum,
                          const char * const * arglist);
    BCP_lp_user * lp_init(BCP_lp_prob& p);
};

#endif

// __END__