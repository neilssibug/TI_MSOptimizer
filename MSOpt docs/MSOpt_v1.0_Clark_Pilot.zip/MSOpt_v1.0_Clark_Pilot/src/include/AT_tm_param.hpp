// __START__

#ifndef __AT_TM_PARAM_HPP__
#define __AT_TM_PARAM_HPP__

/*
 AAP_datafile  : data file
 */

/*-----------------------------------------------------------------*/
struct AT_tm_par {

    enum chr_params {
        char_dummy, end_of_chr_params
    };

    enum int_params {
        int_dummy, end_of_int_params
    };

    enum dbl_params {
        dbl_dummy, end_of_dbl_params
    };

    enum str_params {
        AT_input,
        AT_device,
        AT_key,
        AT_package,
        AT_lot,
        AT_machine_hours,
        AT_machine_mapping,
        AT_machines,
        AT_tooling,
        AT_tooling_mapping,
        AT_tooling_family,
        AT_wip,
        end_of_str_params
    };

    enum str_array_params {
        str_array_dummy, end_of_str_array_params
    };
};

#endif

// __END__
