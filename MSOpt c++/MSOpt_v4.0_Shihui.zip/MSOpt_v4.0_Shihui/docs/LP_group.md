<!-- @defgroup LP LP Group -->
LP group

lorem ipsum
