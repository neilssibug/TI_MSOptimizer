<!-- @defgroup main Main Group -->
Main group

lorem ipsum
