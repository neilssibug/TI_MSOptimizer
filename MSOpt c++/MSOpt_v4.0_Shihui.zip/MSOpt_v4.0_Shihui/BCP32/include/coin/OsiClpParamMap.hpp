// Copyright (C) 2000, International Business Machines
// Corporation and others.  All Rights Reserved.

#ifndef OsiClpParamMap_hpp
#define OsiClpParamMap_hpp

static ClpIntParam intParamMap[OsiLastIntParam] =


#endif
